﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using JDA.ITG.DataAbstraction.Workday.WorkdayHumanResources;

namespace JDA.ITG.WorkdaySimulator
{
	[ServiceBehavior(AddressFilterMode = AddressFilterMode.Any)]
	public class WorkdayService : JDA.ITG.DataAbstraction.Workday.WorkdayHumanResources.Human_ResourcesPort
	{
		#region Human_ResourcesPort Members

		public DataAbstraction.Workday.WorkdayHumanResources.Put_LocationOutput Put_Location( DataAbstraction.Workday.WorkdayHumanResources.Put_LocationInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_LocationOutput> Put_LocationAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_LocationInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_Business_SiteOutput Find_Business_Site( DataAbstraction.Workday.WorkdayHumanResources.Find_Business_SiteInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_Business_SiteOutput> Find_Business_SiteAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_Business_SiteInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationOutput Get_Organization( DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationOutput> Get_OrganizationAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Add_Update_OrganizationOutput Add_Update_Organization( DataAbstraction.Workday.WorkdayHumanResources.Add_Update_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Add_Update_OrganizationOutput> Add_Update_OrganizationAsync( DataAbstraction.Workday.WorkdayHumanResources.Add_Update_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Personal_InfoOutput Get_Employee_Personal_Info( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Personal_InfoOutput> Get_Employee_Personal_InfoAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Contract_InfoOutput Get_Contingent_Worker_Contract_Info( DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Contract_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Contract_InfoOutput> Get_Contingent_Worker_Contract_InfoAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Contract_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_ProfileOutput Get_Worker_Profile( DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_ProfileOutput> Get_Worker_ProfileAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Previous_System_Job_HistoryOutput Put_Previous_System_Job_History( DataAbstraction.Workday.WorkdayHumanResources.Put_Previous_System_Job_HistoryInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Previous_System_Job_HistoryOutput> Put_Previous_System_Job_HistoryAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Previous_System_Job_HistoryInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_EmployeeOutput Find_Employee( DataAbstraction.Workday.WorkdayHumanResources.Find_EmployeeInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_EmployeeOutput> Find_EmployeeAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_EmployeeInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Dissolve_Organization_StructureOutput Dissolve_Organization_Structure( DataAbstraction.Workday.WorkdayHumanResources.Dissolve_Organization_StructureInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Dissolve_Organization_StructureOutput> Dissolve_Organization_StructureAsync( DataAbstraction.Workday.WorkdayHumanResources.Dissolve_Organization_StructureInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_OrganizationOutput Find_Organization( DataAbstraction.Workday.WorkdayHumanResources.Find_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_OrganizationOutput> Find_OrganizationAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_Personal_InfoOutput Update_Employee_Personal_Info( DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_Personal_InfoOutput> Update_Employee_Personal_InfoAsync( DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Business_SiteOutput Get_Business_Site( DataAbstraction.Workday.WorkdayHumanResources.Get_Business_SiteInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Business_SiteOutput> Get_Business_SiteAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Business_SiteInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_Contingent_WorkerOutput Find_Contingent_Worker( DataAbstraction.Workday.WorkdayHumanResources.Find_Contingent_WorkerInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_Contingent_WorkerOutput> Find_Contingent_WorkerAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_Contingent_WorkerInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Employment_InfoOutput Get_Employee_Employment_Info( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Employment_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Employment_InfoOutput> Get_Employee_Employment_InfoAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Employment_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Personal_InfoOutput Get_Contingent_Worker_Personal_Info( DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Personal_InfoOutput> Get_Contingent_Worker_Personal_InfoAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_Worker_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Update_Contingent_Worker_Personal_InfoOutput Update_Contingent_Worker_Personal_Info( DataAbstraction.Workday.WorkdayHumanResources.Update_Contingent_Worker_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Update_Contingent_Worker_Personal_InfoOutput> Update_Contingent_Worker_Personal_InfoAsync( DataAbstraction.Workday.WorkdayHumanResources.Update_Contingent_Worker_Personal_InfoInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Inactivate_OrganizationOutput Inactivate_Organization( DataAbstraction.Workday.WorkdayHumanResources.Inactivate_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Inactivate_OrganizationOutput> Inactivate_OrganizationAsync( DataAbstraction.Workday.WorkdayHumanResources.Inactivate_OrganizationInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfileOutput Get_Job_Profile( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfileOutput> Get_Job_ProfileAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_Job_ProfileOutput Find_Job_Profile( DataAbstraction.Workday.WorkdayHumanResources.Find_Job_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_Job_ProfileOutput> Find_Job_ProfileAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_Job_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupOutput Get_Job_Family_Group( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupOutput> Get_Job_Family_GroupAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Family_GroupOutput Find_Job_Family_Group( DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Family_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Family_GroupOutput> Find_Job_Family_GroupAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Family_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupOutput Get_Job_Classification_Group( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupOutput> Get_Job_Classification_GroupAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Classification_GroupOutput Find_Job_Classification_Group( DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Classification_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Classification_GroupOutput> Find_Job_Classification_GroupAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_Job_Classification_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Related_PersonsOutput Get_Employee_Related_Persons( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Related_PersonsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Related_PersonsOutput> Get_Employee_Related_PersonsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_Related_PersonsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_LocationsOutput Get_Locations( DataAbstraction.Workday.WorkdayHumanResources.Get_LocationsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_LocationsOutput> Get_LocationsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_LocationsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Previous_System_Job_HistoryOutput Get_Previous_System_Job_History( DataAbstraction.Workday.WorkdayHumanResources.Get_Previous_System_Job_HistoryInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Previous_System_Job_HistoryOutput> Get_Previous_System_Job_HistoryAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Previous_System_Job_HistoryInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Server_TimestampOutput Get_Server_Timestamp( DataAbstraction.Workday.WorkdayHumanResources.Get_Server_TimestampInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Server_TimestampOutput> Get_Server_TimestampAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Server_TimestampInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Find_WorkerOutput Find_Worker( DataAbstraction.Workday.WorkdayHumanResources.Find_WorkerInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Find_WorkerOutput> Find_WorkerAsync( DataAbstraction.Workday.WorkdayHumanResources.Find_WorkerInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_ImageOutput Update_Employee_Image( DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_ImageInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_ImageOutput> Update_Employee_ImageAsync( DataAbstraction.Workday.WorkdayHumanResources.Update_Employee_ImageInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_EmployeeOutput Get_Employee( DataAbstraction.Workday.WorkdayHumanResources.Get_EmployeeInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_EmployeeOutput> Get_EmployeeAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_EmployeeInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_WorkerOutput Get_Contingent_Worker( DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_WorkerInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_WorkerOutput> Get_Contingent_WorkerAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Contingent_WorkerInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_Event_HistoryOutput Get_Worker_Event_History( DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_Event_HistoryInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_Event_HistoryOutput> Get_Worker_Event_HistoryAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Worker_Event_HistoryInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Update_Workday_AccountOutput Update_Workday_Account( DataAbstraction.Workday.WorkdayHumanResources.Update_Workday_AccountInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Update_Workday_AccountOutput> Update_Workday_AccountAsync( DataAbstraction.Workday.WorkdayHumanResources.Update_Workday_AccountInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Add_Workday_AccountOutput Add_Workday_Account( DataAbstraction.Workday.WorkdayHumanResources.Add_Workday_AccountInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Add_Workday_AccountOutput> Add_Workday_AccountAsync( DataAbstraction.Workday.WorkdayHumanResources.Add_Workday_AccountInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Insider_TypeOutput Put_Company_Insider_Type( DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Insider_TypeInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Insider_TypeOutput> Put_Company_Insider_TypeAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Insider_TypeInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Insider_TypesOutput Get_Company_Insider_Types( DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Insider_TypesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Insider_TypesOutput> Get_Company_Insider_TypesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Insider_TypesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_ImageOutput Get_Employee_Image( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_ImageInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_ImageOutput> Get_Employee_ImageAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Employee_ImageInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Add_Update_Company_Tax_IDOutput Add_Update_Company_Tax_ID( DataAbstraction.Workday.WorkdayHumanResources.Add_Update_Company_Tax_IDInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Add_Update_Company_Tax_IDOutput> Add_Update_Company_Tax_IDAsync( DataAbstraction.Workday.WorkdayHumanResources.Add_Update_Company_Tax_IDInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDOutput Get_Company_Tax_ID( DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDOutput> Get_Company_Tax_IDAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Work_ShiftOutput Put_Work_Shift( DataAbstraction.Workday.WorkdayHumanResources.Put_Work_ShiftInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Work_ShiftOutput> Put_Work_ShiftAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Work_ShiftInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Work_ShiftsOutput Get_Work_Shifts( DataAbstraction.Workday.WorkdayHumanResources.Get_Work_ShiftsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Work_ShiftsOutput> Get_Work_ShiftsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Work_ShiftsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Job_CategoryOutput Put_Job_Category( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_CategoryInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Job_CategoryOutput> Put_Job_CategoryAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_CategoryInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_CategoriesOutput Get_Job_Categories( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_CategoriesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_CategoriesOutput> Get_Job_CategoriesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_CategoriesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_WorkersOutput Get_Workers( DataAbstraction.Workday.WorkdayHumanResources.Get_WorkersInput request )
		{
			//this function should be written to call a separate class that contains either a) predefined responses or b) calls a database

			//request.Get_Workers_Request.Response_Filter.

			List<WorkerType> data = new List<WorkerType>();

			data.Add( new WorkerType()
			{
				Worker_Reference = new WorkerObjectType() { ID = new WorkerObjectIDType[] { new WorkerObjectIDType() { type = "test", Value = "test" } }, Descriptor = "whatever" },
				Worker_Data = new Worker_DataType()
				{
					Worker_ID = "123456",
					User_ID = "JonnyMackDaddy",
					Employment_Data = new Worker_Employment_Information_DataType()
					{
						Worker_Status_Data = new Worker_Status_Detail_DataType()
						{
							Active = true,
							ActiveSpecified = true,
							Hire_Date = DateTime.Now,
							Hire_DateSpecified = true
						},
						Position_Data = new Position_Detail_DataType()
						{
							Business_Title = "Boss",
							Start_Date = DateTime.Now,
							Effective_Date = DateTime.Now,
							Position_Title = "CEO",
						},
					},
					Personal_Data = new Personal_Information_DataType()
					{
						Name_Data = new Person_Name_DataType()
						{
							Legal_Name_Data = new Legal_Name_DataType()
							{
								Name_Detail_Data = new Person_Name_Detail_DataType()
								{
									First_Name = "Jonathan",
									Last_Name = "Tester",
									Middle_Name = "The",
									Local_Name_Detail_Data = new Local_Person_Name_Detail_DataType()
									{
										First_Name = "Jonathan",
										Last_Name = "Tester",
										Middle_Name = "The",
									},
									Formatted_Name = "Jonathan The Tester",
									Reporting_Name = "Jonathan The Tester"
								}
							},
							Preferred_Name_Data = new Preferred_Name_DataType()
							{
								Name_Detail_Data = new Person_Name_Detail_DataType()
								{
									First_Name = "John",
									Last_Name = "Tester",
									Formatted_Name = "John Tester"
								}
							},
						},
						Birth_Date = new DateTime( 1954, 3, 21 ),
						Birth_DateSpecified = true,
						Contact_Data = new Contact_Information_DataType()
						{
							Address_Data = new Address_Information_DataType[] 
							{
								new Address_Information_DataType()
								{									
									Country_Reference = new CountryObjectType(){ ID = new CountryObjectIDType[]{ new CountryObjectIDType(){ Value = "USA", type = "tbd" }}},
									Address_Line_Data = new Address_Line_Information_DataType[]{
										new Address_Line_Information_DataType()
										{
											Type = "ADDRESS_LINE_1",
											Value = "123 Anywhere Street"
										},
										new Address_Line_Information_DataType()
										{
											Type = "ADDRESS_LINE_2",
											Value = ""
										},
									},
									Municipality_Local  = "Scottsdale",
									Country_Region_Reference = new Country_RegionObjectType()
									{
										ID = new Country_RegionObjectIDType[]{
											new Country_RegionObjectIDType()
											{ 
												type = "STATE",
												Value = "AZ",
											}
										}
									},
									Postal_Code = "12345"
								}							
							}
						}
					}
				}
			} );

			int count = data != null ? data.Count : 0;

			return new Get_WorkersOutput()
			{
				Get_Workers_Response = new Get_Workers_ResponseType()
				{
					Request_Criteria = request.Get_Workers_Request.Request_Criteria,
					Request_References = request.Get_Workers_Request.Request_References,
					version = request.Get_Workers_Request.version,
					Response_Filter = request.Get_Workers_Request.Response_Filter,
					Response_Group = request.Get_Workers_Request.Response_Group,
					Response_Results = new Response_ResultsType()
					{
						Page = 1,
						Page_Results = 1,
						Page_ResultsSpecified = true,
						PageSpecified = true,
						Total_Pages = count == 0 ? 0 : ( count <= 100 ? 1 : count / 100 ),
						Total_PagesSpecified = true,
						Total_Results = data.Count,
						Total_ResultsSpecified = true
					},
					Response_Data = data.ToArray(),
				}
			};
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_WorkersOutput> Get_WorkersAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_WorkersInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_DependentOutput Put_Dependent( DataAbstraction.Workday.WorkdayHumanResources.Put_DependentInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_DependentOutput> Put_DependentAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_DependentInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationsOutput Get_Organizations( DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationsOutput> Get_OrganizationsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_OrganizationsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Workers_Compensation_CodeOutput Put_Workers_Compensation_Code( DataAbstraction.Workday.WorkdayHumanResources.Put_Workers_Compensation_CodeInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Workers_Compensation_CodeOutput> Put_Workers_Compensation_CodeAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Workers_Compensation_CodeInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Workers_Compensation_CodesOutput Get_Workers_Compensation_Codes( DataAbstraction.Workday.WorkdayHumanResources.Get_Workers_Compensation_CodesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Workers_Compensation_CodesOutput> Get_Workers_Compensation_CodesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Workers_Compensation_CodesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDsOutput Get_Company_Tax_IDs( DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDsOutput> Get_Company_Tax_IDsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Company_Tax_IDsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Tax_IDOutput Put_Company_Tax_ID( DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Tax_IDInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Tax_IDOutput> Put_Company_Tax_IDAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Company_Tax_IDInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_FrequenciesOutput Get_Frequencies( DataAbstraction.Workday.WorkdayHumanResources.Get_FrequenciesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_FrequenciesOutput> Get_FrequenciesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_FrequenciesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_FrequencyOutput Put_Frequency( DataAbstraction.Workday.WorkdayHumanResources.Put_FrequencyInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_FrequencyOutput> Put_FrequencyAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_FrequencyInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_DisabilitiesOutput Get_Disabilities( DataAbstraction.Workday.WorkdayHumanResources.Get_DisabilitiesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_DisabilitiesOutput> Get_DisabilitiesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_DisabilitiesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_DisabilityOutput Put_Disability( DataAbstraction.Workday.WorkdayHumanResources.Put_DisabilityInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_DisabilityOutput> Put_DisabilityAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_DisabilityInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Job_ProfileOutput Put_Job_Profile( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Job_ProfileOutput> Put_Job_ProfileAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_ProfileInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfilesOutput Get_Job_Profiles( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfilesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfilesOutput> Get_Job_ProfilesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_ProfilesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_EthnicitiesOutput Get_Ethnicities( DataAbstraction.Workday.WorkdayHumanResources.Get_EthnicitiesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_EthnicitiesOutput> Get_EthnicitiesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_EthnicitiesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_EthnicityOutput Put_Ethnicity( DataAbstraction.Workday.WorkdayHumanResources.Put_EthnicityInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_EthnicityOutput> Put_EthnicityAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_EthnicityInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Training_TypesOutput Get_Training_Types( DataAbstraction.Workday.WorkdayHumanResources.Get_Training_TypesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Training_TypesOutput> Get_Training_TypesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Training_TypesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Training_TypeOutput Put_Training_Type( DataAbstraction.Workday.WorkdayHumanResources.Put_Training_TypeInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Training_TypeOutput> Put_Training_TypeAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Training_TypeInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupsOutput Get_Job_Classification_Groups( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupsOutput> Get_Job_Classification_GroupsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Classification_GroupsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Classification_GroupOutput Put_Job_Classification_Group( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Classification_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Classification_GroupOutput> Put_Job_Classification_GroupAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Classification_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_FamiliesOutput Get_Job_Families( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_FamiliesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_FamiliesOutput> Get_Job_FamiliesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_FamiliesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Job_FamilyOutput Put_Job_Family( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_FamilyInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Job_FamilyOutput> Put_Job_FamilyAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_FamilyInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupsOutput Get_Job_Family_Groups( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupsOutput> Get_Job_Family_GroupsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Job_Family_GroupsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Family_GroupOutput Put_Job_Family_Group( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Family_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Family_GroupOutput> Put_Job_Family_GroupAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Job_Family_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Difficulty_to_FillOutput Get_Difficulty_to_Fill( DataAbstraction.Workday.WorkdayHumanResources.Get_Difficulty_to_FillInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Difficulty_to_FillOutput> Get_Difficulty_to_FillAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Difficulty_to_FillInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Difficulty_to_FillOutput Put_Difficulty_to_Fill( DataAbstraction.Workday.WorkdayHumanResources.Put_Difficulty_to_FillInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Difficulty_to_FillOutput> Put_Difficulty_to_FillAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Difficulty_to_FillInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Manage_Union_MembershipOutput Manage_Union_Membership( DataAbstraction.Workday.WorkdayHumanResources.Manage_Union_MembershipInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Manage_Union_MembershipOutput> Manage_Union_MembershipAsync( DataAbstraction.Workday.WorkdayHumanResources.Manage_Union_MembershipInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentOutput End_Academic_Appointment( DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentOutput> End_Academic_AppointmentAsync( DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_GroupsOutput Get_Provisioning_Groups( DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_GroupsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_GroupsOutput> Get_Provisioning_GroupsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_GroupsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentOutput Add_Academic_Appointment( DataAbstraction.Workday.WorkdayHumanResources.Add_Academic_AppointmentInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentOutput> Add_Academic_AppointmentAsync( DataAbstraction.Workday.WorkdayHumanResources.Add_Academic_AppointmentInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentOutput Update_Academic_Appointment( DataAbstraction.Workday.WorkdayHumanResources.Update_Academic_AppointmentInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.End_Academic_AppointmentOutput> Update_Academic_AppointmentAsync( DataAbstraction.Workday.WorkdayHumanResources.Update_Academic_AppointmentInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_GroupOutput Put_Provisioning_Group( DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_GroupOutput> Put_Provisioning_GroupAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_GroupInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_Group_AssignmentsOutput Get_Provisioning_Group_Assignments( DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_Group_AssignmentsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_Group_AssignmentsOutput> Get_Provisioning_Group_AssignmentsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Provisioning_Group_AssignmentsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_Group_AssignmentOutput Put_Provisioning_Group_Assignment( DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_Group_AssignmentInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_Group_AssignmentOutput> Put_Provisioning_Group_AssignmentAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Provisioning_Group_AssignmentInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Search_SettingsOutput Get_Search_Settings( DataAbstraction.Workday.WorkdayHumanResources.Get_Search_SettingsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Search_SettingsOutput> Get_Search_SettingsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Search_SettingsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Search_SettingsOutput Put_Search_Settings( DataAbstraction.Workday.WorkdayHumanResources.Put_Search_SettingsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Search_SettingsOutput> Put_Search_SettingsAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Search_SettingsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Addresses_for_Country_Format_ExtensionOutput Put_Addresses_for_Country_Format_Extension( DataAbstraction.Workday.WorkdayHumanResources.Put_Addresses_for_Country_Format_ExtensionInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Addresses_for_Country_Format_ExtensionOutput> Put_Addresses_for_Country_Format_ExtensionAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Addresses_for_Country_Format_ExtensionInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Maintain_Contact_InformationOutput Maintain_Contact_Information( DataAbstraction.Workday.WorkdayHumanResources.Maintain_Contact_InformationInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Maintain_Contact_InformationOutput> Maintain_Contact_InformationAsync( DataAbstraction.Workday.WorkdayHumanResources.Maintain_Contact_InformationInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Change_Background_Check_StatusOutput Change_Background_Check_Status( DataAbstraction.Workday.WorkdayHumanResources.Change_Background_Check_StatusInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Change_Background_Check_StatusOutput> Change_Background_Check_StatusAsync( DataAbstraction.Workday.WorkdayHumanResources.Change_Background_Check_StatusInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_UnitsOutput Get_Academic_Units( DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_UnitsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_UnitsOutput> Get_Academic_UnitsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_UnitsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_UnitOutput Put_Academic_Unit( DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_UnitInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_UnitOutput> Put_Academic_UnitAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_UnitInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_Unit_HierarchiesOutput Get_Academic_Unit_Hierarchies( DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_Unit_HierarchiesInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_Unit_HierarchiesOutput> Get_Academic_Unit_HierarchiesAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Academic_Unit_HierarchiesInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_Unit_HierarchyOutput Put_Academic_Unit_Hierarchy( DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_Unit_HierarchyInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_Unit_HierarchyOutput> Put_Academic_Unit_HierarchyAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Academic_Unit_HierarchyInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Get_Political_AffiliationsOutput Get_Political_Affiliations( DataAbstraction.Workday.WorkdayHumanResources.Get_Political_AffiliationsInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Get_Political_AffiliationsOutput> Get_Political_AffiliationsAsync( DataAbstraction.Workday.WorkdayHumanResources.Get_Political_AffiliationsInput request )
		{
			throw new NotImplementedException();
		}

		public DataAbstraction.Workday.WorkdayHumanResources.Put_Political_AffiliationOutput Put_Political_Affiliation( DataAbstraction.Workday.WorkdayHumanResources.Put_Political_AffiliationInput request )
		{
			throw new NotImplementedException();
		}

		public System.Threading.Tasks.Task<DataAbstraction.Workday.WorkdayHumanResources.Put_Political_AffiliationOutput> Put_Political_AffiliationAsync( DataAbstraction.Workday.WorkdayHumanResources.Put_Political_AffiliationInput request )
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}
