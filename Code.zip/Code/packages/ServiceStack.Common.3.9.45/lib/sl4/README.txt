ServiceStack Client builds for Silverlight.

Due to restrictions in Silverlight only the Async operations are supported.