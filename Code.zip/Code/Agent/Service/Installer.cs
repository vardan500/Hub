/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration.Install;
using System.ServiceProcess;
using System.ComponentModel;

namespace JDA.ITG.Flow.Agent.Service
{
	[RunInstallerAttribute( true )]
	internal class SvrInstall : Installer
	{

		#region Constructor									|

		public SvrInstall()
		{
			// Instantiate installers for process and services.
			_processInstaller = new ServiceProcessInstaller();
			_serviceInstaller = new ServiceInstaller();

			// The services run under the system account.
			_processInstaller.Account = ServiceAccount.LocalSystem;

			// The services are started manually.
			_serviceInstaller.StartType        = ServiceStartMode.Automatic;
			_serviceInstaller.DelayedAutoStart = SvrBase.ServiceDelayedStart;
			_serviceInstaller.ServiceName      = SvrBase.ServiceName;
			_serviceInstaller.DisplayName      = SvrBase.ServiceName;
			_serviceInstaller.Description      = SvrBase.ServiceDesc; 

			// Add installers to collection. Order is not important.
			Installers.Add( _serviceInstaller );
			Installers.Add( _processInstaller );
		}

		#endregion

		#region Data Members									|

		private ServiceInstaller        _serviceInstaller = null;
		private ServiceProcessInstaller _processInstaller = null;

		#endregion

		#region Uninstall										|

		public override void Uninstall( IDictionary savedState )
		{
			try
			{
				_serviceInstaller.ServiceName = SvrBase.ServiceName;
				_serviceInstaller.DisplayName = SvrBase.ServiceName;
			}
			catch( Exception e )
			{
				System.Diagnostics.Debug.WriteLine( e.Message );
			}

			base.Uninstall( savedState );
		}

		#endregion

		#region Install								|

		public override void Install( IDictionary stateSaver )
		{
			try
			{
				_serviceInstaller.ServiceName = SvrBase.ServiceName;
				_serviceInstaller.DisplayName = SvrBase.ServiceName;
			}
			catch( Exception e )
			{
				System.Diagnostics.Debug.WriteLine( e.Message );
			}

			base.Install( stateSaver );
		}

		#endregion

	}
}
