﻿/************************************************************************* 
*  
* NETPAYMENT CONFIDENTIAL
*  
*  [2009] - NetPayment Corp.
*  All Rights Reserved. 
*  
* NOTICE:  All information contained herein is, and remains 
* the property of NetPayment Corp. and its suppliers, 
* if any.  The intellectual and technical concepts contained 
* herein are proprietary to NetPayment Corp. 
* and its suppliers and may be covered by U.S. and Foreign Patents, 
* patents in process, and are protected by trade secret or copyright law. 
* Dissemination of this information or reproduction of this material 
* is strictly forbidden unless prior written permission is obtained 
* from NetPayment Corp.
*
*
*************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace JDA.ITG.Flow.Agent.Service
{
	public class ServiceManager : IServiceObject
	{

		#region Data Members

		private const string SERVICE = "Service Manager";

		#endregion

		#region Properties								|

		public static object HostMgr { get; set; }

		#endregion

		#region Start/Shutdown							|

		public void Start()
		{
			Log.Info( ()=> "Service Manager Starting" );

			//Start the configuration
			//MX.Context.Configuration.Startup();

			//Startup the DO's
			//MX.Objects.Factory.ServiceStartup();

			if ( HostMgr != null && HostMgr is HostManager )
				( HostMgr as HostManager ).Startup();
			//Start host manager
			//HostManager.Startup();

			Log.Info( ()=> "Service Manager Started" );
		}

		public void Shutdown()
		{
			Log.Info( ()=> "Service Manager Stopping" );

			//Stop host manager
			if ( HostMgr != null && HostMgr is HostManager )
				( HostMgr as HostManager ).Shutdown();

			//Shutdown the DO's
			//MX.Objects.Factory.ServiceShutdown();

			//Stop the configuration
			//MX.Context.Configuration.Shutdown();

			Log.Info( ()=> "Service Manager Stopped" );
		}

		#endregion

	}
}
