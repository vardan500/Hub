/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration.Install;
using System.ServiceProcess;
using System.Threading;
using System.ComponentModel;
using System.Reflection;
using JDA.ITG;

namespace JDA.ITG.Flow.Agent.Service
{
	internal delegate void PrintHelpHandler();

	internal class SvrBase : ServiceBase
	{

		#region Constructor

		public SvrBase()
		{
			Log.Debug( 0, "Initializing SrvBase" );
		}

		static SvrBase()
		{
			StartedAt = DateTime.MinValue;

			//FullExecutableName = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase+System.AppDomain.CurrentDomain.SetupInformation.ApplicationName;
			ExecutableName     = System.AppDomain.CurrentDomain.FriendlyName;

			ResetParse();
		}

		#endregion

		#region Data Members

		//private static IServiceObject            _invoker     = new ServiceManager();
		//private static Thread                    _thread      = null;
		private static Dictionary<string,string> _commandLine = new Dictionary<string,string>( StringComparer.CurrentCultureIgnoreCase );
		private static bool                      _terConsole  = false;

		public static string ExecutableName = System.AppDomain.CurrentDomain.FriendlyName;
		public static string ExecutablePath = System.IO.Path.GetDirectoryName( Assembly.GetExecutingAssembly().Location ) + "\\";

		public delegate void ServiceStartupCallback();

		#endregion

		#region Properties

		public new static String ServiceName
		{
			get
			{
				return System.Configuration.ConfigurationManager.AppSettings["ServiceName"] ?? "Registered Service Name";
			}
		}

		public static String ServiceDesc 
		{
			get
			{
				return System.Configuration.ConfigurationManager.AppSettings["ServiceDesc"] ?? "Default Service Description";
			}
		}

		public static ServiceStartMode ServiceStartMode
		{
			get
			{
				string temp = System.Configuration.ConfigurationManager.AppSettings["ServiceStartMode"] ?? "Automatic";

				ServiceStartMode mode = System.ServiceProcess.ServiceStartMode.Automatic;
				if( !Enum.TryParse<ServiceStartMode>( temp, true, out mode ))
					mode = System.ServiceProcess.ServiceStartMode.Automatic;

				return mode;
			}
		}

		public static bool ServiceDelayedStart
		{
			get
			{
				bool b;
				bool.TryParse( System.Configuration.ConfigurationManager.AppSettings["ServiceDelayedStart"], out b );
				return b;
			}
		}

		internal ServiceStartupCallback ServiceStartup { get; set; }

		internal static bool OutputConsoleInReleaseMode { get; private set; }
		internal static bool IsConsoleMode { get; private set; }
		internal static bool IsHelp { get; private set; }
		internal static DateTime StartedAt { get; private set; }
		internal static bool IsRunning { get{ return( ServiceStatus.IsRunning );	} }
		internal static PrintHelpHandler PrintHelp { get; set; }

		#endregion

		#region Console Mode								|

		protected virtual void ConsoleModeStart()
		{
			try
			{
				//If we have a service startup method
				if( ServiceStartup != null )
					ServiceStartup();

				IsConsoleMode = true;

				HostManager.Startup();
				////Start processor thread
				//_thread = new Thread( new ThreadStart( _invoker.Start ) );
				//_thread.Start();

				StartedAt = DateTime.UtcNow;

				Log.Info( 0, ServiceName + " Started" );
			}
			catch {}
		}

		protected virtual void ConsoleModeStop()
		{
			try
			{
				HostManager.Shutdown();

				////Stop the processor thread
				//_invoker.Shutdown();

				////Wait
				//_thread.Join( 20000 );
			}
			catch {}

			Log.Info( 0, ServiceName + " Stopped" );
		}

		#endregion

		#region Service Mode								|

		protected override void OnStart( string[] args )
		{
			try
			{
				//If we have a service startup method
				if( ServiceStartup != null )
					ServiceStartup();

				HostManager.Startup();

				////Start processor thread
				//_thread = new Thread( new ThreadStart( _invoker.Start ) );
				//_thread.Start();

				//Call base
				base.OnStart( args );
				StartedAt = DateTime.Now;
			}
			catch {}
		}

		protected override void OnStop()
		{
			try
			{
				HostManager.Shutdown();

				//_invoker.Shutdown();

				//_thread.Join( 20000 );
			}
			catch {}

			base.OnStop();
		}

		#endregion

		#region Print Help									|

		public static void PrintHelpMessage()
		{
			try
			{
				Console.WriteLine();
				Console.WriteLine();
				Console.WriteLine( "*************** SERVICE HELP ***************" );
				Console.WriteLine( "Usage : " + ExecutableName + " [ [-i | -install] | [-u | -uninstall]]" );
				Console.WriteLine();
				Console.WriteLine( " RULE #1: parameters are case-sensitive, and must be lowercase" );
				Console.WriteLine();
				Console.WriteLine( " -i or -install   => create the service" );
				Console.WriteLine( " -u or -uninstall => uninstalls the service (if present)" );
				Console.WriteLine( " -h or -help or ? => display the help information" );
				Console.WriteLine();
				Console.WriteLine( " -c => console mode" );
				Console.WriteLine( " -f => winform mode (no console write)" );

				if( PrintHelp != null )
					PrintHelp();
				
				Console.WriteLine();
				Console.WriteLine();
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "", "NPC.Hosting.SvrBase.PrintHelpMessage" );
			}
		}

		#endregion

		#region Parse Command Line										|

		public static void TerminateConsole()
		{
			_terConsole = true;
		}

		public static bool ParameterExists( string key )
		{
			return( _commandLine.ContainsKey( key ) );
		}

		public static bool Parameter( string key, out string value )
		{
			value = string.Empty;

			if( _commandLine.ContainsKey( key ))
			{
				value = _commandLine[key];

				return( true );
			}

			return( false );
		}

		private static void ResetParse()
		{
			ServiceStatus.IsInstalling   = false;
			ServiceStatus.IsUninstalling = false;
			IsHelp                       = false;
			IsConsoleMode                = false;

			_commandLine.Clear();
		}

		public static void PreParseCommandLine( string[] args )
		{
			ResetParse();

			const string METHOD = "NPC.Hosting.SrvBase.PreParseCommandLine";

			try
			{
				string myOption;

				try
				{
					for( int i = 0; i < args.Length; i++ )
					{
						string argument = args[i].Trim();

						// Process the arguments.
						if( argument.StartsWith( "/" ) || argument.StartsWith( "-" ) )
						{
							myOption = argument.Substring( 1 );

#if !DEBUG
							////if this is in release mode and you want to see the 
							//if( String.Compare( myOption, "funny", true ) == 0 )
							//{
							//  SvrBase.OutputConsoleInReleaseMode = true;
							//  continue;
							//}
#endif

							////if they want to run in console mode, pass in the /c
							//if( string.Compare( myOption, "http", true ) == 0 )
							//{
							//  ServiceStatus.ViewHttp = true;
							//  continue;
							//}

							//if they want to run in console mode, pass in the /c
							if( string.Compare( myOption, "c", true ) == 0 )
							{
								IsConsoleMode = true;

								Log.Debug( 0, "Service is in console mode" );

								continue;
							}

							// Determine whether the option is to 'install' an assembly.
							if( ( string.Compare( myOption, "i", true ) == 0 ) || ( string.Compare( myOption, "install", true ) == 0 ) )
							{
								ServiceStatus.IsInstalling = true;

								Log.Debug( 0, "Service is in installation mode" );

								continue;
							}

							// Determine whether the option is to 'uninstall' an assembly.
							if( ( string.Compare( myOption, "u", true ) == 0 ) || ( string.Compare( myOption, "uninstall", true ) == 0 ) )
							{
								ServiceStatus.IsUninstalling = true;

								Log.Debug( 0, "Service is in uninstallation mode" );

								continue;
							}

							// Determine whether the option is for printing help information.
							if( ( string.Compare( myOption, "?", true ) == 0 ) || ( string.Compare( myOption, "help", true ) == 0 ) || ( string.Compare( myOption, "h", true ) == 0 ) )
							{
								IsHelp = true;
								continue;
							}

							//Check for other commandline options
							if( !_commandLine.ContainsKey( myOption ))
							{
								string myData = string.Empty;

								if( i+1 < args.Length )
								{
									string next = args[i+1].Trim();

									//Next arg is not a command, so add this one without data
									if( !( next.StartsWith( "/" ) || next.StartsWith( "-" ) ))
									{
										myData = next;

										 i++;
									}
								}

								_commandLine.Add( myOption, myData );

								continue;
							}
							else
							{
								Log.Error( 0, string.Format( "Duplicate command-line argument: {0}", myOption ));

								continue;
							}
						}
					}  //end of for
				}
				catch( Exception e )
				{
					Log.Exception( 0, e, "Preparse command line failed", METHOD, args );
				}
			}
			catch( Exception e )
			{
				Log.Exception( 0, e, "Preparse command line failed", METHOD, args );
			}
		}

		public virtual void ParseCommandLine( string[] args )
		{
			ResetParse();

			try
			{
				ArrayList           options               = new ArrayList();
				bool                toConsole             = false;
				TransactedInstaller myTransactedInstaller = new TransactedInstaller();

				string            myOption;
				AssemblyInstaller myAssemblyInstaller;
				InstallContext    myInstallContext;

				try
				{
					for( int i = 0; i < args.Length; i++ )
					{
						string argument = args[i].Trim();

						// Process the arguments.
						if( argument.StartsWith( "/" ) || argument.StartsWith( "-" ) )
						{
							myOption = argument.Substring( 1 );

#if !DEBUG
							////if this is in release mode and you want to see the 
							//if( String.Compare( myOption, "funny", true ) == 0 )
							//{
							//  SvrBase.OutputConsoleInReleaseMode = true;
							//  continue;
							//}
#endif

							//if they want to run in console mode, pass in the /c
							//if( string.Compare( myOption, "http", true ) == 0 )
							//{
							//  ServiceStatus.ViewHttp = true;
							//  continue;
							//}

							//if they want to run in console mode, pass in the /c
							if( string.Compare( myOption, "c", true ) == 0 )
							{
								toConsole = true;

								Log.Debug( 0, "Service is in console mode" );

								continue;
							}

							// Determine whether the option is to 'install' an assembly.
							if( ( string.Compare( myOption, "i", true ) == 0 ) || ( string.Compare( myOption, "install", true ) == 0 ) )
							{
								ServiceStatus.IsInstalling = true;

								Log.Debug( 0, "Service is in installation mode" );

								options.Add( myOption );

								continue;
							}

							// Determine whether the option is to 'uninstall' an assembly.
							if( ( string.Compare( myOption, "u", true ) == 0 ) || ( string.Compare( myOption, "uninstall", true ) == 0 ) )
							{
								ServiceStatus.IsUninstalling = true;

								Log.Debug( 0, "Service is in uninstallation mode" );

								options.Add( myOption );

								continue;
							}

							// Determine whether the option is for printing help information.
							if( ( string.Compare( myOption, "?", true ) == 0 ) || ( string.Compare( myOption, "help", true ) == 0 ) || ( string.Compare( myOption, "h", true ) == 0 ) )
							{
								IsHelp = true;

								break;
							}

							//Check for other commandline options
							if( !_commandLine.ContainsKey( myOption ))
							{
								string myData = string.Empty;

								if( i+1 < args.Length )
								{
									string next = args[i+1].Trim();

									//Next arg is not a command, so add this one without data
									if( !( next.StartsWith( "/" ) || next.StartsWith( "-" ) ))
									{
										myData = next;

										 i++;
									}
								}

								_commandLine.Add( myOption, myData );

								continue;
							}
							else
							{
								Log.Error( 0, string.Format( "Duplicate command-line argument: {0}", myOption ));

								continue;
							}
						}
					} //end of for

					// If user requested help or didn't provide any assemblies to install then print help message.
					if( IsHelp )
					{
						PrintHelpMessage();
						return;
					}

					//****************************************************************************
					//****************************************************************************
					//GO CONSOLE MODE BABY!!! - call the 2 methods defined at the top
					if( toConsole )
					{
						//Make sure these are reset
						ServiceStatus.IsInstalling   = false;
						ServiceStatus.IsUninstalling = false;

						ConsoleModeStart();
						Console.WriteLine( "Press enter key to exit" );

						while( !_terConsole )
						{
							while( !Console.KeyAvailable && !_terConsole )
								Thread.Sleep( 250 );

							if( Console.KeyAvailable )
							{
								ConsoleKeyInfo cki = Console.ReadKey();
								if( cki.Key == ConsoleKey.Enter )
									break;
							}
						} //end of while

						ConsoleModeStop();
						Console.WriteLine( "Application Terminated" );

						return;
					}

					// IF THE above statement is true, the rest of this will never happen
					// Create an instance of 'AssemblyInstaller' that installs the given assembly.
					string[] parameters = (string[])options.ToArray( typeof( string ) );

					myAssemblyInstaller = new AssemblyInstaller( ExecutableName, parameters );
					// Add the instance of 'AssemblyInstaller' to the 'TransactedInstaller'.
					myTransactedInstaller.Installers.Add( myAssemblyInstaller );

					// Create an instance of 'InstallContext' with the options specified.
					myInstallContext              = new InstallContext( "Install.log", parameters );
					myTransactedInstaller.Context = myInstallContext;

					// Install or Uninstall an assembly depending on the option provided.
					if( ( ServiceStatus.IsInstalling && ServiceStatus.IsUninstalling ) )
					{
						System.Diagnostics.EventLog.WriteEntry( SvrBase.ServiceName, "CANNOT DO BOTH INSTALL AND UNINSTALL." );
					}
					else
					{
						if( ServiceStatus.IsInstalling )
						{
							System.Diagnostics.EventLog.WriteEntry( SvrBase.ServiceName, "Installing service ("+ExecutableName+")" );
							myTransactedInstaller.Install( new Hashtable() );
						}

						if( ServiceStatus.IsUninstalling )
						{
							System.Diagnostics.EventLog.WriteEntry( SvrBase.ServiceName, "Uninstalling service ("+ExecutableName+")" );
							myTransactedInstaller.Uninstall( null );
						}
					}
				}
				catch( Exception e )
				{
					Log.Exception( 0, e, "Parse command line failed", "ParseCommandLine", args );
				}
			}
			catch( Exception e )
			{
				Log.Exception( 0, e, "Parse command line failed", "ParseCommandLine", args );
			}
		}

		#endregion

		#region Run										|

		public void Run( string[] args )
		{
			//no args, just run the service
			if( args.Length == 0 )									
			{
				Log.Debug( 0, "Running as a service" );

				ServiceBase.Run( this );
			}
			//guess we're installing or uninstalling
			else
			{
				Log.Debug( 0, "Running as a console" );

				this.ParseCommandLine( args );
			}
		}

		#endregion

		#region Stop

		public new void Stop()
		{
			base.Stop();
		}

		#endregion
	}

	internal static class ServiceStatus
	{

		#region Constructor								|

		static ServiceStatus()
		{
			IsInstalling   = false;
			IsUninstalling = false;
			ViewHttp       = false;
		}

		#endregion

		#region Properties									|

		public static bool ViewHttp { get; set; }
		public static bool IsInstalling { get; set; }
		public static bool IsUninstalling { get; set; }
		public static bool IsRunning { get{ return( !IsInstalling && !IsUninstalling );	} }

		#endregion

	}

}