﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace JDA.ITG.Flow
{
	/// <summary>
	/// Class responsible for coordinating background thread startup and shutdown
	/// </summary>
	internal class HostManager
	{
		#region Data Members

		private static bool _OK = true;

		private static BlockingCollection<Thread> _threads = new BlockingCollection<Thread>();
		private static BlockingCollection<IServiceObject> _processes = new BlockingCollection<IServiceObject>();

		#endregion

		#region Properties

		public static int ProcessCount { get { return ( _processes.Count ); } }

		#endregion

		#region Startup/Shutdown

		public static void Startup()
		{
			Log.Info( 0, "HostManager startup" );

			try
			{
				if ( _OK )
				{
					Type[] types = System.Reflection.Assembly.GetExecutingAssembly().GetTypes().ToArray();

					foreach ( Type t in types )
					{
						if ( t.GetInterfaces().Count( c => c == typeof( IServiceObject ) ) > 0 )
						{
							if ( t.IsAbstract || t.IsInterface )
							{
								//can't startup these types..
							}
							else
							{
								IServiceObject process = (IServiceObject)Activator.CreateInstance( t );
								_processes.Add( process );

								Thread thread = new Thread( new ThreadStart( process.Start ) ) { Name = t.FullName, IsBackground = true };

								_threads.Add( thread );
							}
						}
					}

					foreach ( Thread t in _threads )
					{
						try
						{
							t.Start();
						}
						catch ( Exception ex )
						{
							Log.Exception( 0, ex, "Hosting startup thread failed", "Startup", "StartupThreads" );
						}
					} //end of for
				}
			}
			catch ( Exception ex )
			{
				_OK = false;

				Log.Exception( 0, ex, "Hosting startup step failed", "StartupStep" );
			}
		}

		public static void Shutdown()
		{
			Log.Info( 0, "HostManager shutdown" );

			//Signal the global shutdown event.
			QuitEvent.Set();

			foreach ( IServiceObject process in _processes )
			{
				try
				{
					process.Shutdown();
				}
				catch { }
			} //end of for

			foreach ( Thread thread in _threads )
			{
				try
				{
					thread.Join( 10 * 1000 );
				}
				catch { }
			} //end of for
		}

		#endregion

	}
}
