﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using Newtonsoft.Json.Linq;

namespace JDA.ITG.Flow
{
	public enum LoggingLevel
	{
		NONE = 0,
		FATAL = 5,
		EXCEPTION = 10,
		ERROR = 25,
		WARN = 40,
		INFO = 50,
		DEBUG = 100
	}

	//This class is associated in the Log4net xml file as a specific type.
	public class DefaultLog { }

	internal class AlertHistory
	{
		public DateTime Sent { get; set; }
	}

	internal enum EmailFormatType
	{
		UNASSIGNED = 0,
		TEXT = 1,
		HTML = 2,
	}

	internal class EmailRequest
	{
		public EmailFormatType Format { get; set; }
		public string Recipient { get; set; }
		public string Subject { get; set; }
		public string Body { get; set; }
	}
}