﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace JDA.ITG.Flow
{
	#region Serializer

	public static class Serializer
	{
		static JsonSerializerSettings settings = new JsonSerializerSettings()
		{
			//NullValueHandling = NullValueHandling.Ignore,
			Converters = new List<JsonConverter>() { new Newtonsoft.Json.Converters.IsoDateTimeConverter() }
		};

		#region Serialize 

		public static string Serialize( object obj, bool indent = false )
		{
			if ( obj != null )
			{
				try
				{
					return Newtonsoft.Json.JsonConvert.SerializeObject( obj, indent ? Newtonsoft.Json.Formatting.Indented : Formatting.None, settings );
				}
				catch ( Exception ex )
				{
					Log.Exception( 0, ex, "Error attempting to serialize a json object", "Intercomm.Serialize", obj );
				}
			}

			return string.Empty;
		}

		#endregion

		#region ToJObject 

		public static JObject ToJObject( object obj )
		{
			if ( obj != null )
			{
				try
				{
					return Newtonsoft.Json.Linq.JObject.FromObject( obj );
				}
				catch ( Exception ex )
				{
					Log.Exception( 0, ex, "Error attempting to serialize a json object", "Intercomm.Serialize", obj );
				}
			}

			return null;
		}

		#endregion

		#region Deserialize

		public static T Deserialize<T>( string json )
		{
			T result = default( T );

			if ( string.IsNullOrEmpty( json ) == false )
			{
				object obj = Deserialize( typeof( T ), json );
				if ( obj != null )
					result = (T)obj;
			}

			return result;
		}


		public static object Deserialize( Type type, string json )
		{
			object result = null;

			if ( string.IsNullOrEmpty( json ) )
				return result;

			try
			{
				List<string> errors = new List<string>();

				var jset = new Newtonsoft.Json.JsonSerializerSettings()
				{
					Error = delegate( object sender, Newtonsoft.Json.Serialization.ErrorEventArgs args )
					{
						errors.Add( ( args.ErrorContext.Member != null ? args.ErrorContext.Member.ToString() : "" ) + " " + ( args.ErrorContext.Error.Message ?? string.Empty ) );
						args.ErrorContext.Handled = true;
					},
					Converters = { new Newtonsoft.Json.Converters.IsoDateTimeConverter() }
				};

				object deserialized = Newtonsoft.Json.JsonConvert.DeserializeObject( json, type, jset );

				if ( errors.Count > 0 )
				{
					Log.Error( 0, string.Format( "Error attempting to deserialize object type '{0}', data = '{1}'", type.FullName, json ) );
				}
				else if ( deserialized != null )
					result = deserialized;
			}
			catch ( Exception ex )
			{
				Log.Exception( 0, ex, "Error attempting to deserialize a json object", "Intercomm.Deserialize", json );
			}

			return result;

		}

		#endregion
	}

	#endregion

}
