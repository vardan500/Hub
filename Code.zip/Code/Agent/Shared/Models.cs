﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace JDA.ITG.Flow
{
	//this file should be shared by the agent and hub
	
	// The classes here represents the data structures supported between the agent and the hub.
	// These classes don't need to be TRULY shared, as the hub might add properties before all the agents need them.

	#region Enumerations

	internal enum CommandError
	{
		None = 0,

		InvalidParameters = 1,

		AgentNotPermittedToSubmitObjectName = 2,

		JsonSerializationError = 10,


		UnhandledCommandException = 250,

		NullCommandResponse = 252,

		/// <summary>
		/// (252) There was an error trying to connect to the network participant
		/// </summary>
		InternalCommunicationError = 252,

		/// <summary>
		/// (253) The request isn't supported by the participant at this time
		/// </summary>
		NotSupported = 253,

		/// <summary>
		/// (254) An internal error occurred processing this transaction
		/// </summary>
		SystemError = 254,
	}

	#region AgentStatus

	/// <summary>
	///	Indicates both the Agent's current status and a forced status from the Hub
	/// </summary>
	internal enum AgentStatus 
	{ 
		None = 0, 
		Startup = 1,
 		Ready = 2,
		Paused = 3,
		Shutdown = 4 
	}

	#endregion

	#region AgentAlert

	/// <summary>
	///	Indicates something happened at the agent that the Hub needs to know about asap
	/// </summary>
	internal enum AgentAlert
	{ 
		None = 0, 
		/// <summary>
		/// Indicates the agent received an error from the hub when trying to write its work update. The 
		/// Agent is requesting an immediate status change to Paused. If the Hub don't acknowledge this change,
		/// the Agent change its local status to Paused.
		/// </summary>
		ErrorPostingUpdatedWork = 1,
	}

	#endregion

	#region AgentIntervalMode

	/// <summary>
	///	Indicates if the Agent's polling thread fires based on a schedule or an interval
	/// </summary>
	internal enum AgentIntervalMode 
	{ 
		CycleEveryNSeconds = 0, 
		DailyAtSpecificTimes = 1 
	}

	#endregion

	#region AgentMode

	[Flags]
	internal enum AgentMode
	{
		None = 0,
		/// <summary>
		/// Publishers don't get work data and update it, they push in new data only 
		/// </summary>
		Publisher = 1,
		/// <summary>
		/// Subscribers get work, process it, update the status, and can push in new work
		/// </summary>
		Subscriber = 2
	}

	#endregion

	#endregion

	#region RequestAttribute

	[AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false )]
	internal class RequestAttribute : Attribute
	{
		internal readonly static List<RequestAttribute> Paths = new List<RequestAttribute>();

		static RequestAttribute()
		{
			var types = System.Reflection.Assembly.GetAssembly( typeof( RequestBase ) ).GetTypes().Where( c => c.IsSubclassOf( typeof( RequestBase ) ) );
				
			foreach ( Type type in types )
			{
				RequestAttribute attr = (RequestAttribute)type.GetCustomAttributes( typeof( RequestAttribute ), false ).FirstOrDefault();
				if ( attr == null )
					continue;

				attr.RequestType = type;

				RequestAttribute.Paths.Add( attr );
			}
		}

		internal RequestAttribute( string path )
		{
			this.Path = path.ToLower();
		}

		internal string Path { get; set; }
		internal Type RequestType { get; set; }

		static internal string GetPathFor<T>() where T : RequestBase
		{
			return RequestAttribute.Paths.FirstOrDefault( c => c.RequestType == typeof( T ) ).Path;
		}
	}

	#endregion

	#region AgentSchedule

	/// <summary>
	/// Instructs the Agent's polling thread on when to execute
	/// </summary>
	internal class AgentSchedule
	{
		public AgentIntervalMode Mode { get; set; }
		public int CycleEveryNSeconds { get; set; }
		public string DaysOfWeek { get; set; }
		public List<TimeSpan> Intervals { get; set; }
	}

	#endregion

	#region Objects that move inside the Requests and Responses

	#region Work

	/// <summary>
	/// Agent's update back to the Hub 
	/// </summary>
	public class AgentWorkItem
	{
		public string ObjectName { get; set; }
		public string ObjectKey { get; set; }
		/// <summary>
		/// If this value is assigned, it will be treated as a new document,
		/// otherwise this value will be ignored and the Successful flag will be respected
		/// </summary>
		public string Document { get; set; }
		/// <summary>
		/// If the Document property is set to a non-null value, this property
		/// will be ignored.
		/// </summary>
		public bool Successful {get;set;}
		/// <summary>
		/// If the Document property is set to a non-null value, this property
		/// will be ignored.
		/// </summary>
		public string Error {get;set;}
	}

	/// <summary>
	/// A collection of WorkedRecord objects
	/// </summary>
	public class AgentWork : List<AgentWorkItem>
	{
		public AgentWork()
		{
		}

		public AgentWork( IEnumerable<AgentWorkItem> work )
		{
			if ( work == null || work.Count() == 0 )
				return;

			foreach ( var item in work )
				this.Add( item );
		}

		public new void Add( AgentWorkItem work )
		{
			if ( work == null )
				return;

			if ( this.Exists( c => c.ObjectName == work.ObjectName && c.ObjectKey == work.ObjectKey ) == false )
				base.Add( work );
		}
	}

	#endregion

	#region VolatileItems

	public class AgentData : Dictionary<string,string>
	{
		private object _lock = new object();

		public AgentData() { }

		public AgentData( Dictionary<string,string> items ) 
		{
			foreach ( var item in items )
				base.Add( item.Key, item.Value );
		}

		public new string this[string key]
		{
			get
			{
				if ( string.IsNullOrEmpty( key ) )
					return string.Empty;

				string value = string.Empty;

				key = key.ToUpper();

				lock ( _lock )
				{
					base.TryGetValue( key, out value );
				}

				return value ?? string.Empty;
			}
			
			set
			{
				if ( string.IsNullOrEmpty( key ) )
					return;

				if ( value == null )
					return;

				key = key.ToUpper();

				lock ( _lock )
				{
					if ( this.ContainsKey( key ) )
						base[key] = value;
					else
						base.Add( key, value );
				}
			}
		}
	}

	#endregion

	#region LogEntry

	/// <summary>
	/// Logging information to be sent to the Hub for centralized storage
	/// </summary>
	public class LogEntry
	{
		[Newtonsoft.Json.JsonProperty( "ID" )]
		public long AgentId { get; set; }

		[Newtonsoft.Json.JsonProperty( "IP" )]
		public string ServerIp { get; set; }

		[Newtonsoft.Json.JsonProperty( "NM" )]
		public string ServerName { get; set; }
	
		[Newtonsoft.Json.JsonProperty( "DT" )]
		public DateTime Date { get; set; }
		
		[Newtonsoft.Json.JsonProperty( "LE" )]
		public int Level { get; set; }
		
		[Newtonsoft.Json.JsonProperty( "ME" )]
		public string Method { get; set; }
		
		[Newtonsoft.Json.JsonProperty( "ER" )]
		public string Error { get; set; }
		
		[Newtonsoft.Json.JsonProperty( "EX" )]
		public string Exception { get; set; }
		
		[Newtonsoft.Json.JsonProperty( "IE" )]
		public string InnerException { get; set; }
		
		[Newtonsoft.Json.JsonProperty( "ST" )]
		public string StackTrace { get; set; }
	}

	#endregion

	#endregion

	#region RequestBase / ResponseBase

	internal class RequestBase
	{
		public long AgentId { get; set; }
		public string Username { get; set; }
		public string Password { get; set; }

		/// <summary>
		/// Indicates whether or not multiple requests can be posted to the hub at the same time.
		/// Should be false for all commands other than logs
		/// </summary>
		internal virtual bool CanDoMultiple { get { return false; } }
	}

	internal class ResponseBase
	{
		string _message = null;
		public CommandError Error { get; set; }
		public string Message 
		{
			get { return _message ?? string.Empty; }
			set { _message = value; } 
		}
	}

	#endregion

	#region Requests and Responses

	#region Test (allows for simple calls to work to see if the system is operational)

	[Request( "test" )]
	internal class TestRequest : RequestBase { }

	/// <summary>
	/// Contains instructions and configuration for the Agent
	/// </summary>
	internal class TestResponse : ResponseBase
	{
		public bool Success { get; set; }
	}

	#endregion

	#region Heartbeat

	/// <summary>
	/// A REST call sent from the Agent to the Hub, indicating both it's current status and expects
	/// a HeartbeatResponse from the Hub with the latest instructions, etc.
	/// </summary>

	[Request( "heartbeat" )]
	internal class HeartbeatRequest : RequestBase
	{
		public string ServerIp { get; set; }
		public string ServerName { get; set; }
		public AgentStatus Status { get; set; }
	}

	/// <summary>
	/// Contains instructions and configuration for the Agent
	/// </summary>
	internal class HeartbeatResponse : ResponseBase
	{
		public bool Enabled { get; set; }
		public AgentSchedule Schedule { get; set; }
		public Dictionary<string, string> Settings { get; set; }
	}

	#endregion

	#region AgentAlert

	/// <summary>
	/// A REST call sent from the Agent to the Hub, indicating both it's current status and expects
	/// a HeartbeatResponse from the Hub with the latest instructions, etc.
	/// </summary>

	[Request( "agent-alert" )]
	internal class AgentAlertRequest : RequestBase
	{
		public AgentAlert Alert { get; set; }
	}

	#endregion

	#region WorkGet

	/// <summary>
	/// A REST call sent from the Agent to the Hub, indicating both it's current status and expects
	/// a HeartbeatResponse from the Hub with the latest instructions, etc.
	/// </summary>
	[Request( "work-get" )]
	internal class WorkGetRequest : RequestBase { }

	/// <summary>
	/// Contains instructions and configuration for the Agent
	/// </summary>
	internal class WorkGetResponse : ResponseBase
	{
		public AgentWork Work { get; set; }
	}

	#endregion
	
	#region WorkUpdate 

	/// <summary>
	/// Send back the results of work done to the Hub. If the hub doesn't 
	/// respond, persist it and just keep trying until it accepts?
	/// </summary>
	[Request( "work-update" )]
	internal class WorkUpdateRequest : RequestBase
	{
		public AgentWork Work { get; set; }
	}

	/// <summary>
	/// Notifies the Agent the Hub received the results. Anything 
	/// other than a true condition means the agent needs to save it's data and keepy trying
	/// </summary>
	internal class WorkUpdateResponse : ResponseBase { }

	#endregion
	
	#region AgentDataGet

	/// <summary>
	/// Update the agent's data store. Allows the agent to track it's own data
	/// </summary>
	[Request( "agentdata-get" )]
	internal class AgentDataGetRequest : RequestBase 
	{
		public List<string> Keys { get; set; }
	}

	/// <summary>
	/// The items requested from the Agent Data call
	/// </summary>
	internal class AgentDataGetResponse : ResponseBase 
	{ 
		public AgentData Items { get; set; }
	}

	#endregion
		
	#region AgentDataUpdate

	/// <summary>
	/// Update the agent's volatile data store. Allows the agent to track it's own data
	/// </summary>
	[Request( "agentdata-update" )]
	internal class AgentDataUpdateRequest : RequestBase
	{
		public AgentData Items { get; set; }
	}

	internal class AgentDataUpdateResponse : ResponseBase { }

	#endregion
		
	#region AgentDataDelete

	/// <summary>
	/// Update the agent's volatile data store. Allows the agent to track it's own data
	/// </summary>
	[Request( "agentdata-delete" )]
	internal class AgentDataDeleteRequest : RequestBase
	{
		public AgentData Items { get; set; }
	}

	internal class AgentDataDeleteResponse : ResponseBase { }

	#endregion

	#region LogRequest

	/// <summary>
	/// All relevant logging is done on the Hub, so the agent
	/// uses this request to send log information back to the hub.
	/// (We could go straight to SQL, but the Hub is the Hub for a reason
	/// </summary>
	[Request( "log" )]
	internal class LogRequest : RequestBase
	{
		internal override bool CanDoMultiple { get { return true; } }
		public List<LogEntry> Logs { get; set; }
	}

	#endregion

	#endregion
}
