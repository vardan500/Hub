﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using Newtonsoft.Json.Linq;
using JDA.ITG.Flow.Agent;

namespace JDA.ITG.Flow
{
	internal static class Log
	{
		#region Data Members

		//these variables are used to avoid blasting out repeated alerts...
		private static object _emergencyLock = new object();
		private static ConcurrentDictionary<string, AlertHistory> _alertHistory = new ConcurrentDictionary<string, AlertHistory>( StringComparer.CurrentCultureIgnoreCase );

		#endregion

		#region Properties

		private static bool EmergencyAlertFlag = false;
		private static ServiceStack.Logging.ILog LOG = null;

		internal static Exception InitializeException { get; private set; }
		internal static Exception AdoException { get; private set; }

		internal static string Application { get { return System.AppDomain.CurrentDomain.FriendlyName; } }
		internal static bool IsDebugEnabled { get { return Config.LoggingLevel >= LoggingLevel.DEBUG; } }
		internal static bool IsInfoEnabled { get { return Config.LoggingLevel >= LoggingLevel.INFO; } }
		internal static bool IsWarnEnabled { get { return Config.LoggingLevel >= LoggingLevel.WARN; } }
		internal static bool IsExceptionEnabled { get { return Config.LoggingLevel >= LoggingLevel.EXCEPTION; } }
		internal static bool IsErrorEnabled { get { return Config.LoggingLevel >= LoggingLevel.ERROR; } }


		#endregion

		#region Initialize

		internal static void Initialize()
		{
			string path = System.Configuration.ConfigurationManager.AppSettings.Get( "log4net" );
			try
			{

				if ( string.IsNullOrEmpty( path ) == false && System.IO.File.Exists( path ) )
				{
					ServiceStack.Logging.Log4Net.Log4NetFactory factory = new ServiceStack.Logging.Log4Net.Log4NetFactory( path ); //Also runs log4net.Config.XmlConfigurator.Configure()
					LOG = factory.GetLogger( typeof( DefaultLog ) );
				}
			}
			catch
			{
				throw;
			}
		}

		#endregion

		#region Exception

		internal static void Exception( long agentId, Exception e, string error, string method, params object[] parameters )
		{
			Exception( agentId, e, error, method );
		}

		private static void Exception( long agentId, Exception e, string error, string method )
		{
			try
			{
				if ( IsExceptionEnabled )
				{
					LogEntry( 
						agentId, 
						LoggingLevel.ERROR,
						method,
						error,
						e.Message,
						e.InnerException != null ? e.InnerException.Message : string.Empty,
						e.StackTrace != null ? ( e.StackTrace ?? string.Empty ).Replace( System.Environment.NewLine, "" ) : string.Empty );
				}
			}
			catch { }
		}

		#endregion

		#region Error

		internal static void Error( long agentId, string error )
		{
			if ( IsErrorEnabled )
				LogEntry( agentId, LoggingLevel.ERROR, string.Empty, error );
		}

		#endregion

		#region Debug

		internal static void Debug( long agentId, string msg )
		{
			if ( IsDebugEnabled )
				LogEntry( agentId, LoggingLevel.DEBUG, string.Empty, msg, string.Empty, string.Empty, string.Empty );
		}

		#endregion

		#region Info

		internal static void Info( long agentId, string msg )
		{
			if ( IsInfoEnabled )
				LogEntry( agentId, LoggingLevel.INFO, string.Empty, msg );
		}

		#endregion

		#region EmergencyAlert

		/*
		 * CRITICAL UNDERSTANDING OF THE Emergency Alert errors
		 * Since the emergency alert message is called when there are ADO errors we have to setup
		 * a thread context flag while we are processing the emergency alert.  
		 * (EmergencyAlertFlag) is the property that maintains this information.  We are using the
		 * Log4Net ThreadContext container to maintain this information
		 */


		internal static void EmergencyAlert( string format, params object[] arguments )
		{
			EmergencyAlert( true, format, arguments );
		}

		internal static void EmergencyAlert( bool logError, string format, params object[] arguments )
		{
			const string METHOD = "Shared.Log.EmergencyAlert";

			try
			{
				string msg = format;
				AlertHistory oldAlert = null;

				lock ( _emergencyLock )
				{
					//If this thread already in an emergency alert, then get out
					if ( EmergencyAlertFlag )
					{
						//We shouldn't ever see this.
						return;
					}

					//Flag we are in the emergency alert method
					EmergencyAlertFlag = true;
				}

				//Parse arguments
				if ( arguments != null && arguments.Length > 0 )
				{
					try
					{
						msg = string.Format( format, arguments );
					}
					catch
					{
						msg = "Error parsing format. format: " + format + ", Args: " + string.Join( " -- ", arguments );
					}
				}

				//Always log as error so we capture the alert also.
				if ( logError )
					Log.Error( 0, string.Format( "Emergency Alert: {0}", msg ) );


				if ( Config.SmtpInfo.Enabled == false )
					return;

				EmailRequest email = null;
				//SMSRequest   sms   = null;

				//Build the email request
				email = new EmailRequest()
				{
					Recipient = Config.SmtpInfo.Recipients,
					Subject = "System Error",
					Body = msg,
					Format = EmailFormatType.TEXT
				};

				//If we have data.
				if ( email != null )
				{
					//We have a delay setup
					if ( Config.SmtpInfo.Delay > 0 )
					{
						//--------------------------
						//First check to see if this exact alert has been fired recently
						if ( _alertHistory.TryGetValue( msg, out oldAlert ) )
						{
							lock ( oldAlert )
							{
								//If expired, then update time
								if ( oldAlert.Sent.AddSeconds( Config.SmtpInfo.Delay ) <= DateTime.UtcNow )
									oldAlert.Sent = DateTime.UtcNow;
								//Otherwise get out, since we sent this one recently.
								else
									return;
							}
						}
						else
						{
							oldAlert = new AlertHistory() { Sent = DateTime.UtcNow };
							_alertHistory.AddOrUpdate( msg, oldAlert, ( k, v ) => oldAlert );
						}
					}

					//Invoke the event
					System.Net.Mail.MailMessage mailMsg = new MailMessage()
					{
						Subject = "Online Payments ACH - Emergency Alert",
						Body = msg,
						SubjectEncoding = System.Text.Encoding.UTF8,
						BodyEncoding = System.Text.Encoding.UTF8,
						From = new MailAddress( Config.SmtpInfo.From, Config.SmtpInfo.From, System.Text.Encoding.UTF8 ),
						IsBodyHtml = false,
						Sender = new MailAddress( Config.SmtpInfo.From ),
					};

					mailMsg.To.Add( Config.SmtpInfo.Recipients );

					System.Net.Mail.SmtpClient client = new SmtpClient()
					{
						Credentials = new System.Net.NetworkCredential( Config.SmtpInfo.Username, Config.SmtpInfo.Password ),
						EnableSsl = Config.SmtpInfo.UseSSL,
						Host = Config.SmtpInfo.Host,
						Port = Config.SmtpInfo.Port,
						Timeout = Config.SmtpInfo.Timeout * 1000,
					};

					try
					{
						client.Send( mailMsg );
					}
					catch ( Exception ex )
					{
						_alertHistory.TryRemove( msg, out oldAlert );
						Error( 0, "Failure transmitting mail via SMTP: " + ex.Message + ": " + ( ex.StackTrace ?? string.Empty ) );
					}

				}
			}
			catch ( Exception ex )
			{
				if ( logError )
					Log.Exception( 0, ex, "Sending email failed", METHOD, format, arguments );
			}
			finally
			{
				//Flag we are out of the emergency alert method
				EmergencyAlertFlag = false;
			}
		}

		internal static void SendEmail( string subject, string body, bool isHtml = false )
		{
			//Invoke the event
			System.Net.Mail.MailMessage mailMsg = new MailMessage()
			{
				Subject = subject,
				Body = body,
				SubjectEncoding = System.Text.Encoding.UTF8,
				BodyEncoding = System.Text.Encoding.UTF8,
				From = new MailAddress( Config.SmtpInfo.From, Config.SmtpInfo.From, System.Text.Encoding.UTF8 ),
				IsBodyHtml = isHtml,
				Sender = new MailAddress( Config.SmtpInfo.From ),
			};

			mailMsg.To.Add( Config.SmtpInfo.Recipients );

			System.Net.Mail.SmtpClient client = new SmtpClient()
			{
				Credentials = new System.Net.NetworkCredential( Config.SmtpInfo.Username, Config.SmtpInfo.Password ),
				EnableSsl = Config.SmtpInfo.UseSSL,
				Host = Config.SmtpInfo.Host,
				Port = Config.SmtpInfo.Port,
				Timeout = Config.SmtpInfo.Timeout * 1000,
			};

			try
			{
				client.Send( mailMsg );
			}
			catch ( Exception ex )
			{
				Error( 0, "Failure transmitting mail via SMTP: " + ex.Message + ": " + ( ex.StackTrace ?? string.Empty ) );
			}
		}

		#endregion

		#region LogEntry

		internal static void LogEntry( long agentId, LoggingLevel level, string method, string error, string exception = null, string innerException = null, string stackTrace = null )
		{
			try
			{
				if ( string.IsNullOrEmpty( error ) )
					return;

				//we can send this out whenever we get it, or we can send it out in batches..
				//batches are more efficient, but risk being lost.
				//per-item is faster, but if the hub is down then it doesn't matter.

				LogEntry le = new LogEntry()
				{
					AgentId = agentId,
					Date = DateTime.UtcNow,
					Error = error ?? string.Empty,
					Exception = exception ?? string.Empty,
					InnerException = innerException ?? string.Empty,
					Level = (int)level,
					Method = method ?? string.Empty,
					ServerIp = Config.IPAddress,
					ServerName = Config.MachineName,
					StackTrace = stackTrace ?? string.Empty
				};

				Log.ErrorReceived( le );

				bool logToDisk = false;

				//spit out if in console mode
				Console.WriteLine( le.ToJson() );

				if ( Config.ServerUp == false )
					logToDisk = true;
				else
				{

					string[] creds = Config.GetAgentCredentials( 0 ).Split( ":".ToCharArray() );

					LogRequest logRecord = new LogRequest()
					{
						AgentId = 0, //setting this agentid to zero as it will be sent by the "Default Agent"
						Username = creds.First(),
						Password = creds.Last(),
						Logs = new List<LogEntry>() { le }
					};

					//send it to the hub. If the send fails, logToDisk will set to true
					logToDisk = Intercomm.TryLog( logRecord ).Result != IntercommResult.Success;
				}

				if ( logToDisk )
				{
					//don't log to disk if the Log4Net wrapper didn't load properly
					if ( LOG == null )
						return;

					try
					{
						string entry = Serializer.Serialize( le );

						switch ( level )
						{
							case LoggingLevel.DEBUG:
								LOG.Debug( entry );
								break;
							case LoggingLevel.ERROR:
							case LoggingLevel.EXCEPTION:
								LOG.Error( entry );
								break;
							case LoggingLevel.FATAL:
								LOG.Fatal( entry );
								break;
							case LoggingLevel.INFO:
								LOG.Info( entry );
								break;
							case LoggingLevel.WARN:
								LOG.Warn( entry );
								break;
						}
					}
					catch 
					{ 
						//don't do anything with errors here. We can't handle errors if our error handling doesn't work 
					}
				}
			}
			catch 
			{ 
				//don't do anything with errors here. We can't handle errors if our error handling doesn't work 
			}
		}

		#endregion


		#region Events

		//public static event ReceiveHeartbeatDelegate ReceiveHeartbeatEvent = null;
		/// <summary>
		/// Allows custom code to hook into error events. One example for this use is via a GUI App-based Agent
		/// </summary>
		public static event ReceiveLastErrorDelegate ReceiveLastErrorEvent = null;

		#endregion


		#region Last Error Registration

		/// <summary>
		/// Allows external code to register to receive Error logs
		/// </summary>
		/// <param name="registered"></param>
		public static void RegisterForLastError( ReceiveLastErrorDelegate registered )
		{
			AgentManager.ReceiveLastErrorEvent += registered;
		}

		/// <summary>
		/// Removes the registered events from receiving error logs
		/// </summary>
		public static void ClearErrorRegistration()
		{
			Log.ReceiveLastErrorEvent = null;
		}

		/// <summary>
		/// The method that fires the Events when error logs occur
		/// </summary>
		/// <param name="logEntry"></param>
		public static void ErrorReceived( LogEntry logEntry )
		{
			if ( Log.ReceiveLastErrorEvent != null )
				Log.ReceiveLastErrorEvent( logEntry );
		}

		#endregion
	}
}