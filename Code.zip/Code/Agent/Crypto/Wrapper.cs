﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace JDA.ITG.Flow
{
	class Wrapper
	{
		#region variables

		//the default is here as a fallback only
		private static byte[] _seedV1 = null;
		private CipherV1 cipherV1 = null;

		#endregion

		#region constructor

		static Wrapper()
		{
			//DO NOT read this from the Config.GetAppSetting. That would allow someone to overwrite the encryption
			//by putting this in the database. This value must be set on the local server is the goal is to separate responsibilities.
			string configBytes = System.Configuration.ConfigurationManager.AppSettings.Get( "Encryption.Seed" );
			if ( string.IsNullOrEmpty( configBytes ) == false )
			{
				byte[] bytes = null;
				try
				{
					bytes = configBytes.Split( ",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries ).Select( c => Convert.ToByte( c ) ).ToArray();
				}
				catch
				{
				}

				if ( bytes != null && bytes.Length == 16 )
					_seedV1 = bytes;
				else
					_seedV1 = new byte[] { 32, 78, 63, 89, 84, 26, 38, 105, 33, 28, 123, 02, 21, 56, 40, 8, 51, 77, 96, 15, 79, 42, 11, 76,  };

				//an attempt to obfuscate the seed a little to avoid production staff from trying to take the seed and run...
				for ( int i = 0; i < _seedV1.Length; i++ )
				{
					if ( i % 2 > 0 )
					{
						if ( _seedV1[i] < 254 )
						{
							_seedV1[i]++;
						}
						else
						{
							_seedV1[i] = Convert.ToByte( Convert.ToInt32( _seedV1[i] ) - ( 10 + i ) );
						}
					}
					else
					{
						if ( _seedV1[i] > 1 )
						{
							_seedV1[i]--;
						}
						else
						{
							_seedV1[i] = Convert.ToByte( Convert.ToInt32( _seedV1[i] ) + ( 8 + i ) );
						}
					}
				}



			}
		}

		#endregion

		#region Initialize

		private void Initialize()
		{
			if( cipherV1 == null )
				cipherV1 = new CipherV1( _seedV1 );
		}


		#endregion

		#region DB

		public string Encrypt( string data )
		{
			Initialize();

			return( cipherV1.Encryption( data ) );
		}

		public byte[] Encrypt( byte[] data )
		{
			Initialize();

			return( cipherV1.Encryption( data ) );
		}

		public string Decrypt( string data )
		{
			Initialize();

			return( cipherV1.Decryption( data ) );
		}

		public byte[] Decrypt( byte[] data )
		{
			Initialize();

			return( cipherV1.Decryption( data ) );
		}

		public List<string> Encrypt( List<string> datas )
		{
			Initialize();

			return( cipherV1.Encryption( datas ) );
		}

		public List<string> Decrypt( List<string> datas )
		{
			Initialize();

			return( cipherV1.Decryption( datas ) );
		}

		#endregion


	}
}
