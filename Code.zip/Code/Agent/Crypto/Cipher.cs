﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using System.Security.Cryptography;

namespace JDA.ITG.Flow
{
	class Cipher
	{

		#region Constructor

		protected Cipher()
		{
		}

		protected Cipher( byte[] seed )
		{
		  this.GenerateKeys( seed );
		}

		#endregion

		#region Data Members

		protected byte[] RIJNDEALPRIVATEKEY = null;
		protected byte[] RIJNDEALVECTORKEY  = null;

		private ConcurrentDictionary<int,Rijndael> _RIJNDEALEncrypt = new ConcurrentDictionary<int,Rijndael>();
		private ConcurrentDictionary<int,Rijndael> _RIJNDEALDecrypt = new ConcurrentDictionary<int,Rijndael>();

		#endregion

		#region Generated Key

		protected virtual void GenerateKeys( byte[] seed )
		{
		}

		#endregion

		#region Encryption/Decryption

		public byte[] Encryption( byte[] data )
		{
			return( RijndealEncryption( data ) );
		}

		public string Encryption( string data )
		{
			return( Encryption( data, true ) );
		}

		public string Encryption( string data, bool toBase64 )
		{
			string result = string.Empty;

			if( !string.IsNullOrEmpty( data ) )
			{
				try
				{
					//Get the data.
					byte[] byEncrypt = RijndealEncryption( System.Text.Encoding.UTF8.GetBytes( data ) );

					//Got data bach, then convert
					if ( byEncrypt != null )
					{
						if( toBase64 )
							result = Convert.ToBase64String( byEncrypt );
						else
							result = System.Text.Encoding.UTF8.GetString( byEncrypt );
					}
				}
				catch 
				{
					result = data;
				}
			}

			return( result );
		}

		public byte[] Decryption( byte[] data )
		{
			return( RijndealDecryption( data ) );
		}

		public string Decryption( string data )
		{
			return( Decryption( data, true ) );
		}

		public string Decryption( string data, bool fromBase64 )
		{
			string result = string.Empty;

			if( !string.IsNullOrEmpty( data ) )
			{
				try
				{
					//Decrypt the data.
					byte[] byDecrypt = null;
					
					if( fromBase64 )
						byDecrypt = RijndealDecryption( Convert.FromBase64CharArray( data.ToCharArray(), 0, data.Length ) );
					else
						byDecrypt = System.Text.Encoding.UTF8.GetBytes( data );

					//Got data bach, then convert
					if ( byDecrypt != null )
						result = System.Text.Encoding.UTF8.GetString( byDecrypt ).TrimEnd( '\0' );
					else
						result = data;
				}
				catch 
				{
					result = data;
				}
			}

			return( result );
		}

		public List<string> Encryption( List<string> datas )
		{
			List<string> results = new List<string>();

			if( RIJNDEALPRIVATEKEY == null )
				throw( new InvalidOperationException( "Encryption key has not been defined" ) );

			Rijndael obj;
			int      id = System.Threading.Thread.CurrentThread.ManagedThreadId;
			if ( !_RIJNDEALEncrypt.TryGetValue( id, out obj ) )
			{
				obj = System.Security.Cryptography.Rijndael.Create();
				_RIJNDEALEncrypt.TryAdd( id, obj );
			}

			if ( obj != null )
			{
				try
				{
					foreach ( string data in datas )
					{
						string result = string.Empty;
						if ( data != null && data.Length > 0 )
						{
							try
							{
								byte[] buffer = System.Text.Encoding.UTF8.GetBytes( data );

								using ( System.Security.Cryptography.ICryptoTransform encrypt = obj.CreateEncryptor( RIJNDEALPRIVATEKEY, RIJNDEALVECTORKEY ) )
								{
									buffer = encrypt.TransformFinalBlock( buffer, 0, data.Length );
								}

								if ( buffer != null && buffer.Length > 0 )
									result = Convert.ToBase64String( buffer );
							}
							catch
							{
							}
						}

						if ( result == null )
							result = data;

						results.Add( result );
					}
				}
				catch { }
			}
			return results;
		}

		public List<string> Decryption( List<string> datas )
		{
			List<string> results = new List<string>();

			if( RIJNDEALPRIVATEKEY == null )
				throw( new InvalidOperationException( "Encryption key has not been defined" ) );

			Rijndael obj;
			int      id = System.Threading.Thread.CurrentThread.ManagedThreadId;
			if ( !_RIJNDEALDecrypt.TryGetValue( id, out obj ) )
			{
				obj = System.Security.Cryptography.Rijndael.Create();
				_RIJNDEALDecrypt.TryAdd( id, obj );
			}

			if( obj != null )
			{
				try
				{
					foreach ( string data in datas )
					{
						string result = string.Empty;
						if ( data != null && data.Length > 0 )
						{
							try
							{
								//Decrypt the data.
								byte[] buffer = Convert.FromBase64CharArray( data.ToCharArray(), 0, data.Length );

								//Got data bach, then convert
								if ( buffer != null )
								{
									using ( System.Security.Cryptography.ICryptoTransform encrypt = obj.CreateDecryptor( RIJNDEALPRIVATEKEY, RIJNDEALVECTORKEY ) )
									{
										buffer = encrypt.TransformFinalBlock( buffer, 0, data.Length );
									}

									result = System.Text.Encoding.UTF8.GetString( buffer ).TrimEnd( '\0' );
								}
							}
							catch
							{
							}
						}

						if ( string.IsNullOrEmpty( result ) )
							result = data;

						results.Add( result );
					} //end of for
				}
				catch { }
			}
			return results;
		}

		#endregion

		#region Rijndeal Encrytion/Decryption

		private byte[] RijndealEncryption( byte[] data )
		{
			byte[] result = null;

			if( RIJNDEALPRIVATEKEY == null )
				throw( new InvalidOperationException( "Encryption key has not been defined" ) );

			if( data != null && data.Length > 0 )
			{
				try
				{
					Rijndael obj;
					int     id = System.Threading.Thread.CurrentThread.ManagedThreadId;
					if ( !_RIJNDEALEncrypt.TryGetValue( id, out obj ) )
					{
						obj = System.Security.Cryptography.Rijndael.Create();
						_RIJNDEALEncrypt.TryAdd( id, obj );
					}

					if ( obj != null )
					{
						try
						{
							using ( System.Security.Cryptography.ICryptoTransform encrypt = obj.CreateEncryptor( RIJNDEALPRIVATEKEY, RIJNDEALVECTORKEY ) )
							{
								result = encrypt.TransformFinalBlock( data, 0, data.Length );
							}
						}
						catch { }
					}
				}
				catch { }
			}

			return( result );
		}

		private byte[] RijndealDecryption( byte[] data )
		{
			byte[] result = null;

			if( RIJNDEALPRIVATEKEY == null )
				throw( new InvalidOperationException( "Encryption key has not been defined" ) );

			if( data != null && data.Length > 0 )
			{
				try
				{
					Rijndael obj;
					int      id = System.Threading.Thread.CurrentThread.ManagedThreadId;
					if ( !_RIJNDEALDecrypt.TryGetValue( id, out obj ) )
					{
						obj = System.Security.Cryptography.Rijndael.Create();
						_RIJNDEALDecrypt.TryAdd( id, obj );
					}

					if ( obj != null )
					{
						try
						{
							using ( System.Security.Cryptography.ICryptoTransform encrypt = obj.CreateDecryptor( RIJNDEALPRIVATEKEY, RIJNDEALVECTORKEY ) )
							{
								result = encrypt.TransformFinalBlock( data, 0, data.Length );
							}
						}
						catch { }
					}
				}
				catch { }
			}

			return( result );
		}

		#endregion

	}

	class CipherV1 : Cipher
	{

		#region Constructor|

		private CipherV1()
		{
		}

		public CipherV1( byte[] seed ) : base( seed )
		{
		}

		#endregion

		#region Generated Key

		protected override void GenerateKeys( byte[] seed )
		{
			if( seed.Length != 24 )
				throw( new Exception( "Invalid encryption/decryption key specified.  Key must contain 24 entries["+seed+"]" ) );

			System.Security.Cryptography.Rijndael rijndeal = System.Security.Cryptography.Rijndael.Create();
			byte[]                                bigkey   = null;

			// Perform a hash operation using the phrase. This will generate a unique 32 byte (256-bit) value to be used as the key.      
			using( SHA256Managed sha256 = new SHA256Managed() )
			{
				sha256.ComputeHash( seed );
				bigkey = sha256.Hash;
			}

			//Build private key
			RIJNDEALPRIVATEKEY = new Byte[rijndeal.KeySize / 8];
			Array.Copy( bigkey, 0, RIJNDEALPRIVATEKEY, 0, RIJNDEALPRIVATEKEY.Length );

			//Build vectory key
			RIJNDEALVECTORKEY = new Byte[rijndeal.IV.Length];
			Array.Copy( bigkey, RIJNDEALPRIVATEKEY.Length / 2, RIJNDEALVECTORKEY, 0, RIJNDEALVECTORKEY.Length );
		}

		#endregion

	}

	class CipherV2 : Cipher
	{

		#region Constructor

		private CipherV2()
		{
		}

		public CipherV2( byte[] seed ) : base( seed )
		{
		}

		#endregion

		#region Generated Key

		protected override void GenerateKeys( byte[] seed )
		{
			if( seed.Length != 24 )
				throw( new Exception( "Invalid encryption/decryption key specified.  Key must contain 24 entries["+seed+"]" ) );

			System.Security.Cryptography.Rijndael rijndeal = System.Security.Cryptography.Rijndael.Create();
			byte[]                                bigkey   = null;

			// Perform a hash operation using the phrase. This will generate a unique 32 byte (256-bit) value to be used as the key.      
			using( SHA512Managed sha = new SHA512Managed() )
			{
				sha.ComputeHash( seed );

				bigkey = sha.Hash;
			}

			//Build private key
			RIJNDEALPRIVATEKEY = new Byte[rijndeal.KeySize / 8];
			Array.Copy( bigkey, 0, RIJNDEALPRIVATEKEY, 0, RIJNDEALPRIVATEKEY.Length );

			//Build vectory key
			RIJNDEALVECTORKEY = new Byte[rijndeal.IV.Length];
			Array.Copy( bigkey, RIJNDEALPRIVATEKEY.Length, RIJNDEALVECTORKEY, 0, RIJNDEALVECTORKEY.Length );
		}

		#endregion

	}

}
