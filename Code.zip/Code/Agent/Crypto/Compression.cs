﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using System.IO.Compression;

namespace JDA.ITG.Flow
{
	public class Compression
	{

		#region Compress										|

		public static byte[] Compress( byte[] text )
		{
			byte[] buffer = null;

			try
			{
			  using ( MemoryStream msout = new MemoryStream() )
			  {
			    using ( MemoryStream msin = new MemoryStream( text ) )
			    {
			      msin.Position = 0;

			      using ( GZipStream zip = new GZipStream( msout, CompressionMode.Compress, true ) )
			      {
			        msin.CopyTo( zip );
			      }
			    }

			    buffer = msout.ToArray();
			  }
			}
			catch ( Exception ex )
			{
			  Log.Exception( 0, ex, "Compress failed", "Shared.Global.Compress", text );
			}

			return( buffer );
		}

		public static string CompressToBase64( string text )
		{
			byte[] buffer = Encoding.UTF8.GetBytes( text ?? string.Empty );

			try
			{
			  using ( MemoryStream msout = new MemoryStream() )
			  {
			    using ( MemoryStream msin = new MemoryStream( buffer ) )
			    {
			      msin.Position = 0;

			      using ( GZipStream zip = new GZipStream( msout, CompressionMode.Compress, true ) )
			      {
			        msin.CopyTo( zip );
			      }
			    }

			    buffer = msout.ToArray();
			  }
			}
			catch ( Exception ex )
			{
			  Log.Exception( 0, ex, "Compress to base64 failed", "Shared.Global.CompressToBase64", text );
			}

			return( Convert.ToBase64String( buffer ) );
		}

		#endregion

		#region Decompress										|

		public static byte[] Decompress( byte[] compressedText )
		{
			byte[] buffer = null;

			try
			{
				using ( MemoryStream msout = new MemoryStream() )
				{
					using( MemoryStream msin = new MemoryStream( compressedText ) )
					{
						msin.Position = 0;

						using ( GZipStream zip = new GZipStream( msin, CompressionMode.Decompress ) )
						{
							zip.CopyTo( msout );
						}
					}

					buffer = msout.ToArray();
				}
			}
			catch ( Exception ex )
			{
			  Log.Exception( 0, ex, "Decompress failed", "Shared.Global.Decompress", compressedText );
			}

			return( buffer );
		}

		public static string DecompressFromBase64( string compressedText )
		{
			string result = string.Empty;

			try
			{
				byte[] buffer = Convert.FromBase64String( compressedText ?? string.Empty );
				int    len    = buffer.Length;

				using ( System.IO.MemoryStream msout = new MemoryStream() )
				{
					using( MemoryStream msin = new MemoryStream( buffer ) )
					{
						using ( GZipStream zip = new GZipStream( msin, CompressionMode.Decompress ) )
						{
							zip.CopyTo( msout );
						}
					}

					buffer = msout.ToArray();
				}

				result = Encoding.UTF8.GetString( buffer );
			}
			catch ( Exception ex )
			{
			  Log.Exception( 0, ex, "Decompress from base64 failed", "Shared.Global.DecompressFromBase64", compressedText );
			}

			return result;
		}

		#endregion

	}
}