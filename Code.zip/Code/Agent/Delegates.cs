﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow.Agent;
using JDA.ITG.Flow.Agent.Service;

namespace JDA.ITG.Flow
{
	/// <summary>
	/// Used by the Log and AgentManager classes to propagate errors up to custom code for hooking into the error pipe
	/// </summary>
	/// <param name="logEntry"></param>
	public delegate void ReceiveLastErrorDelegate( LogEntry logEntry );
}
