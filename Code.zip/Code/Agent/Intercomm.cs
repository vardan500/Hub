﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDA.ITG.Flow.Agent
{
	#region Intercomm 

	/// <summary>
	/// Core class that handles all communication from the Agent to the Hub
	/// </summary>
	internal static class Intercomm
	{
		#region private variables

		//the code at one point was using raw sockets. That's been changed to using the standard HttpClient. the connect timeout no longer applies
		const int DEFAULT_CONNECT_TIMEOUT = 60;
		const int DEFAULT_COMMAND_TIMEOUT = 60;

		//a list of active commands. Due to the design of the FetchWorker and AgentManager classes, multiple agents 
		//will not fire concurrently. The dictionary below ensures that only one command type can run at a time, so
		//if the code in fetchworkers is changed to support concurrency (by firing the publish/subscribe as async or tasks),
		//this would need to be changed to ConcurrentDictionary<Type, ConcurrentDictionary<long,bool>>
		static ConcurrentDictionary<Type, bool> _runningCommands = new ConcurrentDictionary<Type, bool>();

		//this is used when logging to ensure logging to the hub is serialized. We don't want to flood the hub with a lot of concurrent requests
		static object _loglock = new object();

		#endregion

		#region Commands

		#region TryHeartbeat

		/// <summary>
		/// Send a Heartbeat to the Hub and get back the latest config and agent details
		/// </summary>
		/// <param name="agentId">The AgentId the heartbeat is for. Must be a valid AgentId or 0</param>
		/// <param name="rs">The Hearbeat response from the hub</param>
		/// <returns></returns>
		internal static IntercommOutcome TryHeartbeat( long agentId, out HeartbeatResponse rs )
		{
			rs = null;
			IntercommOutcome outcome = new IntercommOutcome();

			if ( Config.StandaloneTesting.Enabled )
			{
				//if we're in standalone mode, use the heartbeat defined in the file. Each agent used in standalone mode MUST be defined in the file
				try
				{
					HeartbeatResponses heartbeats = null;

					//load the file
					using ( System.IO.StreamReader reader = new System.IO.StreamReader( Config.StandaloneTesting.HeartbeatFile ) )
					{
						//deserialize the JSON into the Heartbeats dictionary
						heartbeats = Serializer.Deserialize<HeartbeatResponses>( reader.ReadToEnd() );
					}

					//make sure we found the one we're looking for
					if ( heartbeats.TryGetValue( agentId, out rs ) == false )
					{
						outcome = new IntercommOutcome( IntercommResult.Error, string.Format( "Unable to find heartbeat in StandaloneTesting.HeartbeatFile for AgentId: {0}", agentId ) );
					}
				}
				catch ( Exception ex )
				{
					outcome = new IntercommOutcome( IntercommResult.Error, string.Format( "Error reading StandaloneTesting.HeartbeatFile: {0}, Stack: {1}", ex.Message, ex.StackTrace ) );
				}
			}
			else
			{
				//go to the hub
				HeartbeatRequest rq = new HeartbeatRequest()
				{
					AgentId = agentId,
					ServerIp = Config.IPAddress,
					ServerName = Config.MachineName,
					Status = Config.GetAgentStatus( agentId ),
				};

				outcome = IntercommProcessor<HeartbeatRequest, HeartbeatResponse>( rq, out rs );
			}

			return outcome;
		}

		#endregion

		#region TryAgentAlert

		/// <summary>
		/// Special message from the Agent to the Hub indicating something (bad) happened that may require further action
		/// </summary>
		/// <param name="agentId"></param>
		/// <param name="alert"></param>
		/// <param name="rs"></param>
		/// <returns></returns>
		internal static IntercommOutcome TryAgentAlert( long agentId, AgentAlert alert, out ResponseBase rs )
		{
			rs = null;
			IntercommOutcome outcome = new IntercommOutcome();

			if ( Config.StandaloneTesting.Enabled )
			{
				//nothing to do here.
				rs = new ResponseBase(){ Error = CommandError.None, Message = string.Empty };
			}
			else
			{
				AgentAlertRequest rq = new AgentAlertRequest()
				{
					AgentId = agentId,
					Alert = alert
				};

				outcome = IntercommProcessor<AgentAlertRequest, ResponseBase>( rq, out rs );
			}

			return outcome;
		}

		#endregion

		#region TryGetWork

		/// <summary>
		/// Called by FetchWorker, this method asks the Hub for work to do. "Work" is defined as data records that are accessible to this Agent Id
		/// but haven't been "worked" by the Agent yet.
		/// </summary>
		/// <param name="agentId"></param>
		/// <param name="rs"></param>
		/// <returns></returns>
		internal static IntercommOutcome TryGetWork( long agentId, out WorkGetResponse rs )
		{
			IntercommOutcome outcome = null;
			rs = null;

			WorkGetRequest rq = new WorkGetRequest() { AgentId = agentId };

			if ( Config.StandaloneTesting.Enabled )
			{
				outcome = StandaloneWorkRecords.Get( rq, out rs );
			}
			else
			{
				outcome = IntercommProcessor<WorkGetRequest,WorkGetResponse>( rq, out rs );
			}

			return outcome;
		}

		#endregion

		#region TryUpdateWork
		
		/// <summary>
		/// Sends back new data, or status updates for existing data just worked by the agent
		/// </summary>
		/// <param name="rq"></param>
		/// <param name="rs"></param>
		/// <returns></returns>
		internal static IntercommOutcome TryUpdateWork( WorkUpdateRequest rq, out WorkUpdateResponse rs )
		{
			rs = null;
			IntercommOutcome outcome = null;

			if ( Config.StandaloneTesting.Enabled )
			{
				outcome = StandaloneWorkRecords.Update( rq, out rs );
			}
			else
			{
				outcome = IntercommProcessor<WorkUpdateRequest,WorkUpdateResponse>( rq, out rs );
			}

			return outcome;		
		}

		#endregion

		#region TryGetAgentData
		
		/// <summary>
		/// Fetches agent-specific data based on a list of keys sent to the hub. Allows for an agent to be targeted/specific
		/// with the data it wants. An agent could store thousands of specific records, but only need one at a time depending on its work
		/// </summary>
		/// <param name="rq"></param>
		/// <param name="rs"></param>
		/// <returns></returns>
		internal static IntercommOutcome TryGetAgentData( AgentDataGetRequest rq, out AgentDataGetResponse rs )
		{
			rs = null;
			IntercommOutcome outcome = null;

			if ( Config.StandaloneTesting.Enabled )
			{
				outcome = StandaloneVolatileItems.Get( new AgentDataGetRequest(), out rs );
			}
			else
			{
				outcome = IntercommProcessor<AgentDataGetRequest,AgentDataGetResponse>( rq, out rs );
			}

			return outcome;
		}

		#endregion

		#region TryUpdateAgentData
		
		/// <summary>
		/// Updates/Sets values for keys the agent wants to store
		/// </summary>
		/// <param name="rq"></param>
		/// <param name="rs"></param>
		/// <returns></returns>
		internal static IntercommOutcome TryUpdateAgentData( AgentDataUpdateRequest rq, out AgentDataUpdateResponse rs )
		{
			IntercommOutcome outcome = new IntercommOutcome();
			rs = null;

			if ( Config.StandaloneTesting.Enabled )
			{
				outcome = StandaloneVolatileItems.Update( rq, out rs );
			}
			else
			{
				outcome = IntercommProcessor<AgentDataUpdateRequest, AgentDataUpdateResponse>( rq, out rs );
			}

			return outcome;
		}

		#endregion

		#region TryDeleteAgentData
		
		/// <summary>
		/// Deletes one or more keys at the hub for the agent
		/// </summary>
		/// <param name="rq"></param>
		/// <param name="rs"></param>
		/// <returns></returns>
		internal static IntercommOutcome TryDeleteAgentData( AgentDataDeleteRequest rq, out AgentDataDeleteResponse rs )
		{
			IntercommOutcome outcome = new IntercommOutcome();
			rs = null;

			if ( Config.StandaloneTesting.Enabled )
			{
				outcome = StandaloneVolatileItems.Delete( rq, out rs );
			}
			else
			{
				outcome = IntercommProcessor<AgentDataDeleteRequest, AgentDataDeleteResponse>( rq, out rs );
			}

			return outcome;
		}

		#endregion

		#region TryLog
	
		/// <summary>
		/// Sends logging information to the Hub from the Agent for centralized storage
		/// </summary>
		/// <param name="rq"></param>
		/// <returns></returns>
		internal static IntercommOutcome TryLog( LogRequest rq )
		{
			ResponseBase rs = null;

			if ( Config.StandaloneTesting.Enabled )
			{
				//safety first
				lock ( _loglock )
				{
					try
					{
						using ( System.IO.StreamWriter writer = new System.IO.StreamWriter( Config.StandaloneTesting.LogFile, true ) )
						{
							foreach ( var item in rq.Logs )
							{
								writer.WriteLine( "AgentId: " + rq.AgentId.ToString() + "\t" + Serializer.Serialize( item ) );
								writer.Flush();
							}
						}
					}
					catch ( Exception ex )
					{
						Log.Exception( 0, ex, "Error calling TryLog", "TryLog" );
					}
				}
			}
			else
			{
				Task.Factory.StartNew( () => IntercommProcessor<LogRequest, ResponseBase>( rq, out rs ) );
			}

			return new IntercommOutcome();
		}

		#endregion

		#endregion

		#region Helper Methods

		#region IntercommSerializer

		/// <summary>
		/// Helper method to make sure all the nitty gritty fields are set before serializing the command request into a string
		/// </summary>
		/// <param name="request"></param>
		/// <returns></returns>
		internal static string IntercommSerializer( RequestBase request )
		{
			AgentConfig config = Config.GetAgent( request.AgentId );
			string[] creds = Config.GetAgentCredentials( request.AgentId ).Split( ":".ToCharArray() );
			request.Username = creds.First();
			request.Password = creds.Last();
			return Serializer.Serialize( request );
		}
		#endregion

		#region IntercommProcessor

		/// <summary>
		/// Handles the physical communication between the Agent and the Hub. 
		/// </summary>
		/// <typeparam name="Rq"></typeparam>
		/// <typeparam name="Rs"></typeparam>
		/// <param name="rq"></param>
		/// <param name="rs"></param>
		/// <returns></returns>
		internal static IntercommOutcome IntercommProcessor<Rq, Rs>( Rq rq, out Rs rs ) where Rq : RequestBase where Rs : ResponseBase
		{
			rs = default( Rs );

			if ( rq == null )
				return new IntercommOutcome( IntercommResult.Failure, "rq is null for type: " + typeof( Rq ).FullName );

			//abort if the command is already in process
			if ( DoCommand<Rq>() == false )
				return new IntercommOutcome( IntercommResult.AlreadyRunning );

			IntercommOutcome outcome = new IntercommOutcome();


			int timeout = Config.GetAppSettingAsInt( Config.CONFIG_REST_COMMAND_TIMEOUT, DEFAULT_COMMAND_TIMEOUT );			

			try
			{
				//RESTClient is a socket pool. RESTClient2 is a standard HttpClient, and will suffice for the needs of this system
				Communication.RESTClient2 client = new Communication.RESTClient2( timeout );
				//get the URL to send to 
				string uri = Intercomm.HubUrlBuilder( RequestAttribute.GetPathFor<Rq>() );
				//prep the payload for the http post
				string json = IntercommSerializer( rq );
				//send the request, expecting back a specific response object
				rs = client.Post<Rs>( uri, json );

				//a response of OK will ALWAYS return a body. If it doesn't, the Hub is broken or there is a bug
				if ( client.ResponseStatusCode == System.Net.HttpStatusCode.OK )
				{
					if ( rs != null )
						outcome.Result = IntercommResult.Success;
					else
					{
						outcome.Result = IntercommResult.Failure;
						outcome.Error = "Successful HTTP Response, but expected to receive an " + typeof( Rs ).Name + " object (which is null). Please check the Hub ASAP";
					}
				}
				else
				{
					//there are a couple of specific HTTP Status Codes that we care about
					switch ( client.ResponseStatusCode )
					{
						case System.Net.HttpStatusCode.Unauthorized:
							outcome.Result = IntercommResult.Failure;
							outcome.Error = string.Format( "Agent {0} unauthorized. Invalid credentials or credentials not on the server", rq.AgentId );
							break;
						case System.Net.HttpStatusCode.PreconditionFailed:
							outcome.Result = IntercommResult.Failure;
							outcome.Error = client.ResponseStatusDescription;
							break;
						default:
							outcome.Result = IntercommResult.Failure;
							outcome.Error = client.ResponseError ?? client.ResponseBody;
							break;
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ( rq != null ? rq.AgentId : 0 ), ex, "", "IntercommProcessor" );
				outcome.Result = IntercommResult.Error;
			}

			//free up the command for the next caller
			ReleaseCommand<Rq>();

			return outcome;
		}

		#endregion

		#region HubUrlBuilder

		static string HubUrlBuilder( string command, Dictionary<string,string> parameters = null )
		{
			if ( string.IsNullOrEmpty( Config.DataHubBaseUrl ) || string.IsNullOrEmpty( command ) )
				return string.Empty;

			System.Text.StringBuilder sb = new System.Text.StringBuilder();

			if(Config.DataHubBaseUrl.EndsWith("/"))
				sb.Append( Config.DataHubBaseUrl + command );
			else
				sb.Append( Config.DataHubBaseUrl + "/" + command );

			if ( parameters != null )
			{
				sb.Append("?");
				foreach ( var item in parameters )
					sb.Append( item.Key + "=" + item.Value );
			}
			return sb.ToString();
		}

		#endregion

		#region lock-safe methods allowing commands to be started/stoppped

		/*
		 * Notes about this code:
		 * 
		 * It's possible that the background thread that invokes the Heartbeat and Fetch calls could be modified
		 * to go async or fire-and-forget these commands. If that happens, a slow response or down hub would result
		 * in multiple Heartbeats or Fetch calls being executed. We don't want that to happen for a number of reasons.
		 * 
		 */

		internal static bool DoCommand<T>()
		{
			return _runningCommands.TryAdd( typeof(T), true );
		}

		internal static void ReleaseCommand<T>()
		{
			bool b;
			_runningCommands.TryRemove( typeof(T), out b );
		}

		#endregion

		#endregion

	}

	#endregion
}

