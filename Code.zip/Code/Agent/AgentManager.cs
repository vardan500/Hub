﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow.Agent;
using JDA.ITG.Flow.Agent.Service;

namespace JDA.ITG.Flow
{
	#region AgentManager

	/// <summary>
	/// Controls Agent class registration and work assignment/completion
	/// </summary>
	public static class AgentManager
	{
		#region private variables

		//used to reference the Windows service manager
		static SvrBase _service = null;

		//the Agent's class Type defined in the EXE to execute
		//Tuple = Type, IsPublisher, IsSubscriber
		static readonly Dictionary<long,AgentInfo> _agents = new Dictionary<long,AgentInfo>();
		static readonly Dictionary<Type,long> _agentsReverseLookup = new Dictionary<Type,long>();

		#endregion

		#region Properties

		//quick cheat to see what an agent is
		internal static bool IsPublisher( long agentId ) { return _agents[agentId].IsPublisher; }
		internal static bool IsSubscriber( long agentId ) { return _agents[agentId].IsSubscriber; }
		
		//immutable copy
		internal static Dictionary<long, AgentInfo> Agents { get { return _agents.ToDictionary( c => c.Key, c => c.Value ); } }

		#endregion

		#region Events

		/// <summary>
		/// Allows custom code to hook into error events. One example for this use is via a GUI App-based Agent
		/// </summary>
		public static event ReceiveLastErrorDelegate ReceiveLastErrorEvent = null;

		#endregion

		#region Shutdown

		/// <summary>
		/// Flags the DLL to shut down all background threads (the system is stopping)
		/// </summary>
		public static void Shutdown()
		{
			AgentManager.ClearErrorRegistration();
			
			QuitEvent.Set();

			if ( _service != null )
				_service.Stop();
			else
				HostManager.Shutdown();
				//SvrBase.TerminateConsole();
		}

		#endregion

		#region Intialize

		/// <summary>
		/// For use in winforms or web sites. NEVER use this if using the Agent exe pattern
		/// </summary>
		/// <param name="agentTypes"></param>
		public static void Intialize( params Type[] agentTypes )
		{
			Intialize( null, true, agentTypes );
		}

		/// <summary>
		/// The primary method for controlling an Agent service, including Agent class registration, startup, and shutdown
		/// </summary>
		/// <param name="args"></param>
		/// <param name="agentTypes">Array of IAgent class types to initialize</param>
		public static void Intialize( string[] args, params Type[] agentTypes )
		{
			Intialize( args, false, agentTypes );
		}

		/// <summary>
		/// The primary method for controlling an Agent service, including Agent class registration, startup, and shutdown
		/// </summary>
		/// <param name="args"></param>
		/// <param name="inlineMode">Indicates this dll is hosted in a winform or a web site</param>
		/// <param name="agentTypes">Array of IAgent class types to initialize</param>
		public static void Intialize( string[] args, bool inlineMode, params Type[] agentTypes )
		{
			if ( args == null )
				args = new string[] { };

			bool abort = false;

			//don't do ANYTHING if we don't have agents...
			if ( agentTypes == null || agentTypes.Length == 0 )
			{
				AgentManager.Console( "It might be useful if you put at least one Class in this exe that inherits from IPublisher or ISubscriber...No?" );
				abort = true;
			}
			else
			{
				#region Verify and assign the Agent class that will be doing the work

				//walk through the agents passed into this method and make sure they are valid and ready
				foreach ( Type t in agentTypes )
				{
					if ( abort )
						break;

					try
					{
						//get all the interfaces this class derives from (this predates the base class implementation, so it could be removed and just done via the base class checks below
						List<Type> interfaces = t.GetInterfaces().ToList();

						if ( interfaces.Contains( typeof( IAgent ) ) == false )
						{
							AgentManager.Console( "Type passed into AgentManager.Initialize doesn't derive from IAgent. Type = " + t.FullName );
							abort = true;
						}
						else
						{
							//create an instance of the Agent. This is done for 2 reasons: 
							//  1. Make sure the Agent class CAN be instanciated, and 
							//  2. Get the AgentId (Could be done via an attribute, but this suffices)

							object obj = Activator.CreateInstance( t );

							if ( obj != null )
							{
								bool isPublisher = interfaces.Contains( typeof( IPublisher ) );
								bool isSubscriber = interfaces.Contains( typeof( ISubscriber ) );

								if ( isPublisher == false && isSubscriber == false )
								{
									AgentManager.Console( "The Agent implements IAgent, but not IPublisher or ISubscriber. shutting down." );
									abort = true;
								}
								else if ( isPublisher && ( t.IsSubclassOf( typeof( PublisherBase ) ) == false && t.IsSubclassOf( typeof( PubSubBase ) ) == false ))
								{
									AgentManager.Console( "The Agent implements IPublisher, but doesn't derive from PublisherBase. shutting down." );
									abort = true;
								}
								else if ( isSubscriber && ( t.IsSubclassOf( typeof( SubscriberBase ) ) == false && t.IsSubclassOf( typeof( PubSubBase ) ) == false ))
								{
									AgentManager.Console( "The Agent implements ISubscriber, but doesn't derive from SubscriberBase. shutting down." );
									abort = true;
								}
								else
								{
									//we've got our agent!
									IAgent agent = (IAgent)obj;
									long agentId = agent.AgentId;

									//see if we've already placed it inside our dictionary of agent ids and types
									if ( _agents.ContainsKey( agentId ) )
									{
										AgentManager.Console( string.Format( "There are 2 agents assigned AgentId {0}. {1} and {2}. shutting down.", agentId, _agents[agentId].AgentType.FullName, t.FullName ) );
										abort = true;
									}
									else
									{
										//sometimes we need to get the agent id from the agent type. This is faster than iterating the values in the other collection
										_agentsReverseLookup.Add( t, agentId );
										//save the agent id, type, and some useful info about the agent in the dictionary for future activation/use
										_agents.Add( agentId, new AgentInfo() { AgentId = agentId, AgentName = agent.AgentName, AgentType = t, IsPublisher = isPublisher, IsSubscriber = isSubscriber } );
									}
								}
							}
							else
							{
								AgentManager.Console( "Unable to create an instance of the Agent class to process in Registration.RegisterOneAgentOnly. Type = " + t.FullName );
								abort = true;
							}
						}
					}
					catch ( Exception ex )
					{
						AgentManager.Console( "Unable to create an instance of the Agent class to process. Class = {0}, Error = {1}", t.FullName, ex.Message + ":" + ex.StackTrace ?? string.Empty );
						abort = true;
					}
				}

				#endregion
			}
			

			//we're here because something failed above...
			if ( abort )
			{
				//gives the developer a chance to figure out what's going wrong before the debugger aborts...
				System.Threading.Thread.Sleep( 5 * 1000 );
				return;
			}


			//We're good to go. Let's start up the DLL, first by loading configuration data and the Log.cs static class
			try
			{
				//gotta have config
				Config.Load();

				//start logging
				Log.Initialize();

				if ( Config.ProperlyConfigured == false )
				{
					//obviously this only works if in console mode..but that's how it'll need to be confirmed if we can't even initialize properly..
					foreach ( string s in Config.ConfigurationErrors )
						AgentManager.Console( s );
					return;
				}
			}
			catch ( Exception ex )
			{
				//obviously this only works if in console mode..
				AgentManager.Console( ex.Message + ": " + ex.StackTrace ?? string.Empty );
				// nothing to log here..
			}


			//The rest of the code will control the operation of the Agent Service

			//inline mode means they're running this in a GUI app or web site. If we're in that mode, there is no console to display or service to start
			if ( inlineMode )
			{
				//startup the background threads SANS service or console display
				HostManager.Startup();
			}
			else
			{
				//we're in console mode or service mode

				try
				{
					//Preparse the command line
					SvrBase.PreParseCommandLine( args );

					//Create the windows service manager (and start the service up)
					//this also runs the HostManager
					_service = new SvrBase();
					_service.Run( args );

				}
				catch ( Exception e )
				{
					Log.Exception( 0, e, "Program Main() failed", "Main" );
				}

				//Final shutdown
				Log.Info( 0, "Shutdown Application" );

			}

		}

		#endregion

		#region GiveWorkToAgent

		/// <summary>
		/// Method that passes work into the Agent class type that was initialized on startup
		/// </summary>
		/// <param name="work"></param>
		internal static void GiveWorkToAgent( long agentId, AgentWork work = null )
		{
			//useful to have the console print information when you're running in developer mode or debugging on a live box in console mode ( [agent].exe -c )
			AgentManager.Console( "Giving Work to Agent {0}, Work Count: {1}", agentId, work != null ? work.Count : 0 );

			//  1. Creates an instance of the agent class from the calling EXE, 
			IAgent agent = (IAgent)Activator.CreateInstance( _agents[agentId].AgentType );

			//if it's a publisher, invoke it so it can do it's thing
			if ( AgentManager.IsPublisher( agentId ) )
			{
				//separate lines to make it nice and readable
				IPublisher pub = (IPublisher)agent;
				pub.Publish();
			}

			//only give work to a subscriber if a) it IS a subscriber and b) there is work to do
			if ( AgentManager.IsSubscriber( agentId ) && work != null && work.Count > 0 )
			{
				//separate lines to make it nice and readable
				ISubscriber sub = (ISubscriber)agent;
				sub.Subscribe( work );
			}
		}

		#endregion

		#region ReturnWork

		/// <summary>
		/// Callback method used to send data back to the hub
		/// </summary>
		/// <param name="results"></param>
		internal static bool ReturnWork( long agentId, AgentWork work )
		{
			bool ok = false;

			//make sure we've got work to do first
			if(work == null || work.Count == 0 )
			{
				Log.Error( agentId, "AgentWorkManager.ReturnWork() received a null or zero count AgentWork object (or all properties are null). Please ensure this method is invoked properly by: " + Log.Application );
				return ok;
			}

			//if this is worked data (Successful == true ), strip off the document. we don't want to send it back, we just want to indicate it was successfully worked
			foreach ( var item in work )
			{
				if ( item.Successful || string.IsNullOrEmpty( item.Error ) == false )
					item.Document = null;
			}

			AgentManager.Console( "Returning Work from Agent {0}, Work Count: {1}", agentId, work != null ? work.Count : 0 );

			//prepare the request container to send to the hub
			WorkUpdateRequest inboundWork = new WorkUpdateRequest() { AgentId = agentId, Work = work };

			WorkUpdateResponse response;

			//call the hub
			IntercommOutcome outcome = Intercomm.TryUpdateWork( inboundWork, out response );

			//see what the outcome was
			ok = outcome.Result == IntercommResult.Success && response.Error == CommandError.None;

			//if it failed to post, that means the agent cannot communicate with the hub or the hub is down.
			if ( ok == false )
			{
				ResponseBase rb;
				bool shutdown = false;

				Log.Error( agentId, string.Format( "AgentId {0} couldn't report its work to the hub. Reporting an emergency alert", agentId ) );

				//later we can add code to save the work to disk and keep trying to push it back up (in the heartbeat thread)
				//for now the work will be considered "gone", as the agent.dll could be loaded in IIS or someplace where there 
				//is no ability to write to disk

				//immediately disable the agent until we can resolve the problem
				Config.DisableAgent( agentId );

				//try to notify the hub that the agent can't report it's work product
				outcome = Intercomm.TryAgentAlert( agentId, AgentAlert.ErrorPostingUpdatedWork, out rb );

				//if the alert notification succeeded, we dont' need to tak more drastic measures
				shutdown = outcome.Result != IntercommResult.Success || ( rb != null && rb.Error != CommandError.None );

				if( shutdown )
				{
					//immediately log an error, shut down the agent process, and get out...
					System.Text.StringBuilder sb = new StringBuilder( "An error occurred while Agent " + agentId.ToString() + " attempted to record the outcome of work, then the Hub gave us a bad response when we attempted to notify it we're going dark.");
					if ( outcome.Result != IntercommResult.Success )
						sb.AppendLine( "IntercommOutcome.Result = " + outcome.Result.ToString() + ": " + outcome.Error ?? string.Empty );
					else if( response.Error != CommandError.None )
						sb.AppendLine( "response.Error = " + response.Error.ToString() + ": " + response.Message ?? string.Empty );

					sb.AppendLine( "Changing Agent Status to Disabled" );

					string err = sb.ToString();
					//log (it'll likely log locally since it can't reach the hub)
					Log.Error( agentId, err );
					//send off an email alert
					Log.EmergencyAlert( err );
					Shutdown();
				}
			}

			return ok;
		}

		#endregion

		#region Last Error Registration

		/// <summary>
		/// Allows external code to register to receive Error logs
		/// </summary>
		/// <param name="registered"></param>
		public static void RegisterForLastError( ReceiveLastErrorDelegate registered )
		{
			if ( AgentManager.ReceiveLastErrorEvent == null )
			{
				//register to receive log events
				Log.RegisterForLastError( AgentManager.ErrorReceived );
			}

			AgentManager.ReceiveLastErrorEvent += registered;
		}

		/// <summary>
		/// Removes the registered events from receiving error logs
		/// </summary>
		public static void ClearErrorRegistration()
		{
			AgentManager.ReceiveLastErrorEvent = null;
			Log.ClearErrorRegistration();
		}

		/// <summary>
		/// The method that fires the Events when error logs occur
		/// </summary>
		/// <param name="logEntry"></param>
		public static void ErrorReceived( LogEntry logEntry )
		{
			//fire this on a separate thread. Yeah, it's kind of 
			if ( AgentManager.ReceiveLastErrorEvent != null )
				Task.Run( () => AgentManager.ReceiveLastErrorEvent( logEntry ) );
		}

		#endregion

		#region Console

		/// <summary>
		/// Writes information to the Console, if it's available
		/// </summary>
		/// <param name="format"></param>
		/// <param name="parameters"></param>
		static void Console( string format, params object[] parameters )
		{
			if ( SvrBase.IsConsoleMode )
			{
				try
				{
					System.Console.WriteLine( string.Format( format, parameters ) );
				}
				catch { }
			}
		}

		#endregion
	}

	#endregion

	#region AgentInfo

	/// <summary>
	/// A wrapper class containing "crib sheet" info about the Agent classes/Types it will invoke
	/// </summary>
	internal class AgentInfo
	{
		public long AgentId { get; set; }
		public Type AgentType { get; set; }
		public string AgentName { get; set; }
		public bool IsSubscriber { get; set; }
		public bool IsPublisher { get; set; }
	}

	#endregion

}
