﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow.Agent;
using JDA.ITG.Flow.Agent.Service;

namespace JDA.ITG.Flow
{
	#region AgentBase 

	/// <summary>
	/// This class contains the methods and properties necessary for custom agents to interface with the Agent DLL and Hub
	/// </summary>
	public abstract class AgentBase : IAgent
	{
		#region ------------------------------- Private Variables -------------------------------

		#endregion

		#region ------------------------------- Abstract Properties -------------------------------

		/// <summary>
		/// Every agent class must have an AgentId defined in their agent class AND in the Hub database.
		/// </summary>
		/// <remarks>
		/// The AgentId must be a bit flag (e.g. 1 | 2 | 4 | 8 | 16, etc.) Yes, there can only be 63 unique agents..
		/// </remarks>
		public abstract long AgentId { get; }

		/// <summary>
		/// The agent name is primarily for descriptive purposes. The value here should also be entered in the Hub database
		/// </summary>
		public abstract string AgentName { get; }

		#endregion

		#region ------------------------------- Send Work back to the Hub -------------------------------

		/// <summary>
		/// This method must be invoked by the Agent code. If a large number of records are being updated or saved, 
		/// the agent should call this repeatedly with smaller batch sizes (depending on the size of the data being sent)
		/// </summary>
		/// <param name="work"></param>
		/// <param name="batches"></param>
		public bool Send( AgentWork work, int batches = 0 )
		{
			if ( work == null || work.Count == 0 )
				return true;

			if ( batches <= 0 )
			{
				//call the corresponding methin in the AgentManager
				return AgentManager.ReturnWork( this.AgentId, work );
			}

			AgentWork transitWorker = new AgentWork();

			//loop through the passed-in work
			for ( int i = 0; i < work.Count; i++ )
			{
				//add the passed-in work to the transit worker (the one we'll send to the Hub)
				transitWorker.Add( work[i] );

				//if we've got 20 records (or we're done looping), send the batch
				if ( transitWorker.Count == 20 || i == transitWorker.Count - 1 )
				{
					//try to send the data to the Hub
					if ( Send( work ) == false )
					{
						//we've got a serious problem and couldn't send the data base. abort and hope someone checks the logs
						Log.EmergencyAlert( "Send() returned false when trying to post Associates from the WorkdayFetchAgent. Checks Logs and fix asap" );

						//don't both updating the LastRunTime - we need to do this over again
						return false;
					}

					//clear the items we just sent and prepare for the next 20..
					transitWorker.Clear();
				}
			}

			return true;
		}

		/// <summary>
		/// This method must be invoked by the Agent code. If a large number of records are being updated or saved, 
		/// the agent should call this repeatedly with smaller batch sizes (depending on the size of the data being sent)
		/// </summary>
		/// <param name="work"></param>
		/// <returns></returns>
		public bool Send( params AgentWorkItem[] work )
		{
			AgentWork aw = new AgentWork();
			aw.AddRange( work );
			return AgentManager.ReturnWork( this.AgentId, aw );
		}

		#endregion

		#region ------------------------------- AgentData Methods -------------------------------

		#region AgentDataGet Methods

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <returns>A string (empty or with value)</returns>
		public string AgentDataGet( string key )
		{
			if ( string.IsNullOrEmpty( key ) )
				return string.Empty;

			key = key.ToUpper();

			AgentDataGetResponse response;
			if ( Intercomm.TryGetAgentData( new AgentDataGetRequest() { AgentId = this.AgentId, Keys = new List<string>(){ key } }, out response ).Result == IntercommResult.Success )
			{
				if(response.Items.ContainsKey( key ) )
					return response.Items[key];
			}

			return string.Empty;
		}

		/// <summary>
		/// Requests one or more values from the Hub for the key(s) specified
		/// </summary>
		/// <param name="keys">An array of keys to retrieve from the Hub</param>
		/// <returns></returns>
		public AgentData AgentDataGet( params string[] keys )
		{
			if ( keys == null )
				return null;

			List<string> listOfKeys = keys.Where( c => string.IsNullOrEmpty( c ) == false ).Select( c => c.ToUpper() ).Distinct().ToList();

			if ( listOfKeys.Count > 0 )
			{
				AgentDataGetResponse response;
				IntercommOutcome outcome = Intercomm.TryGetAgentData( new AgentDataGetRequest() { AgentId = this.AgentId, Keys = listOfKeys }, out response );
				if ( outcome.Result == IntercommResult.Success )
					return response.Items;
			}

			return new AgentData();
		}

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <returns>the value as a boolean, if possible. Will return false if the item doesn't exist or cannot be parsed</returns>
		public bool AgentDataGetAsBool( string key )
		{
			string value = AgentDataGet( key );
			return string.IsNullOrEmpty( value ) ? false : value.ToBoolean();
		}

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <returns>the value as an Int16, if possible. Will return 0 if the item doesn't exist or cannot be parsed</returns>
		public Int16 AgentDataGetAsInt16( string key )
		{
			string value = AgentDataGet( key );
			return string.IsNullOrEmpty( value ) ? (short)0 : value.ToInt16();
		}

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <returns>the value as an Int32, if possible. Will return 0 if the item doesn't exist or cannot be parsed</returns>
		public Int32 AgentDataGetAsInt32( string key )
		{
			string value = AgentDataGet( key );
			return string.IsNullOrEmpty( value ) ? 0 : value.ToInt32();
		}

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <returns>the value as an Int64, if possible. Will return 0 if the item doesn't exist or cannot be parsed</returns>
		public Int64 AgentDataGetAsInt64( string key )
		{
			string value = AgentDataGet( key );
			return string.IsNullOrEmpty( value ) ? 0 : value.ToInt64();
		}

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <returns>the value as a DateTime if possible. Will return null if the item doesn't exist or cannot be parsed</returns>
		public DateTime? AgentDataGetAsDateTime( string key )
		{
			string value = AgentDataGet( key );
			return string.IsNullOrEmpty( value ) ? null : value.ToDateTime();
		}

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <remarks>Should be used in conjunction with AgentDataSetAsJObject</remarks>
		/// <returns>the value as a JObject if possible. Will return null if the item doesn't exist or cannot be parsed</returns>
		public Newtonsoft.Json.Linq.JObject AgentDataGetAsJObject( string key )
		{
			try
			{
				string value = AgentDataGet( key );
				if ( string.IsNullOrEmpty( value ) == false )
					return Newtonsoft.Json.Linq.JObject.Parse( value );
			}
			catch 
			{
			}

			return null;
		}

		/// <summary>
		/// Requests a single value from the Hub for the key specified
		/// </summary>
		/// <param name="key">The key the Agent Data to retrieve</param>
		/// <remarks>Should be used in conjunction with AgentDataSetAsJArray</remarks>
		/// <returns>the value as a JArray if possible. Will return null if the item doesn't exist or cannot be parsed</returns>
		public Newtonsoft.Json.Linq.JArray AgentDataGetAsJArray( string key )
		{
			try
			{
				string value = AgentDataGet( key );
				if ( string.IsNullOrEmpty( value ) == false )
					return Newtonsoft.Json.Linq.JArray.Parse( value );
			}
			catch 
			{
			}

			return null;
		}

		#endregion

		#region AgentDataSet Methods

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">A non-null and non-empty string</param>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, string value )
		{
			if ( string.IsNullOrEmpty( key ) || string.IsNullOrEmpty( value ) )
				return false;

			key = key.ToUpper();

			AgentData ad = new AgentData();
			ad.Add( key, value );
			AgentDataUpdateResponse response = null;
			AgentDataUpdateRequest request = new AgentDataUpdateRequest() { AgentId = this.AgentId, Items = ad };
			return Agent.Intercomm.TryUpdateAgentData( request, out response ).Result == IntercommResult.Success;
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">A boolean value to save</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, bool value )
		{
			return AgentDataSet( key, value.ToString() );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">An Int16 value to save</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool SetAgentData( string key, Int16 value )
		{
			return AgentDataSet( key, value.ToString() );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">An Int32 value to save</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, Int32 value )
		{
			return AgentDataSet( key, value.ToString() );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">An Int64 value to save</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, Int64 value )
		{
			return AgentDataSet( key, value.ToString() );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">A DateTime value to save</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, DateTime value )
		{
			return value == null ? false : AgentDataSet( key, value.ToString() );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">A DateTime? value to save</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, DateTime? value )
		{
			return value == null || value.HasValue == false ? false : AgentDataSet( key, value.Value.ToString() );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">An object to save. The object will be converted to a string via value.ToString()</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, object value )
		{
			return value == null ? false : AgentDataSet( key, value.ToString() );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">A JObject to save. Can later be called by AgentDataGetAsJObject</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, Newtonsoft.Json.Linq.JObject value )
		{
			return value == null ? false : AgentDataSet( key, value.ToString( Newtonsoft.Json.Formatting.None, new Newtonsoft.Json.Converters.IsoDateTimeConverter() ) );
		}

		/// <summary>
		/// Transmits a key/value pair of agent data to the Hub
		/// </summary>
		/// <param name="key">The key name (will be forced to uppercase upon saving)</param>
		/// <param name="value">A JObject to save. Can later be called by AgentDataGetAsJArray</param>
		/// <remarks>The value will be saved as a string</remarks>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataSet( string key, Newtonsoft.Json.Linq.JArray value )
		{
			return value == null ? false : AgentDataSet( key, value.ToString( Newtonsoft.Json.Formatting.None, new Newtonsoft.Json.Converters.IsoDateTimeConverter() ) );
		}

		#endregion

		#region AgentDataDelete

		/// <summary>
		/// Indicates the Hub should delete the agent data for the given key
		/// </summary>
		/// <param name="key"></param>
		/// <returns>True if able to save, False if invalid data or it could not be saved</returns>
		public bool AgentDataDelete( string key )
		{
			if ( string.IsNullOrEmpty( key ) )
				return false;

			key = key.ToUpper();

			AgentData ad = new AgentData();
			ad.Add( key, null );
			AgentDataDeleteResponse response = null;
			AgentDataDeleteRequest request = new AgentDataDeleteRequest() { AgentId = this.AgentId, Items = ad };
			return Agent.Intercomm.TryDeleteAgentData( request, out response ).Result == IntercommResult.Success;
		}

		#endregion

		#endregion

		#region ------------------------------- Error Reporting -------------------------------

		/// <summary>
		/// Provides the agent code with a means to send an email alert to the configured recipients 
		/// </summary>
		/// <param name="format"></param>
		/// <param name="arguments"></param>
		public void LogEmergencyAlert( string format, params object[] arguments )
		{
			Log.EmergencyAlert( format, arguments );
		}

		/// <summary>
		/// Logs Exceptions to the Hub or Log4Net
		/// </summary>
		/// <param name="e"></param>
		/// <param name="error"></param>
		/// <param name="method"></param>
		public void LogException( Exception e, string error, string method )
		{
			Log.Exception( this.AgentId, e, error, method );
		}

		/// <summary>
		/// Logs Errors to the Hub or Log4Net
		/// </summary>
		/// <param name="error"></param>
		public void LogError( string error )
		{
			Log.Error( this.AgentId, error );
		}

		/// <summary>
		/// Logs to the Console if the Console is available
		/// </summary>
		/// <param name="format"></param>
		/// <param name="parameters"></param>
		public void LogConsole( string format, params object[] parameters )
		{
			if ( SvrBase.IsConsoleMode )
			{
				try
				{
					System.Console.WriteLine( string.Format( format, parameters ) );
				}
				catch { }
			}
		}

		/// <summary>
		/// Logs Debug-level events to the Hub or Log4Net
		/// </summary>
		/// <param name="msg"></param>
		public void LogDebug( string msg )
		{
			Log.Debug( this.AgentId, msg );
		}

		/// <summary>
		/// Logs Info-level events to the Hub or Log4Net
		/// </summary>
		/// <param name="msg"></param>
		public void LogInfo( string msg )
		{
			Log.Info( this.AgentId, msg );
		}

		#endregion

		#region ------------------------------- GetAppSetting Methods -------------------------------

		/// <summary>
		/// Get an Agent-specific application setting
		/// </summary>
		/// <param name="name">The name of the setting to get</param>
		/// <returns>A string containing the value retrieved or an empty string if no value returned</returns>
		public string AppSettingGet( string name )
		{
			return Config.GetAppSetting( this.AgentId, name );
		}

		/// <summary>
		/// Get an Agent-specific application setting as an Int32
		/// </summary>
		/// <param name="name">The name of the setting to get</param>
		/// <param name="defaultValue">Optional. Specify an integer other than 0 if preferred</param>
		/// <param name="name">The name of the setting to get</param>
		/// <returns>The config setting converted to an Int32 value, or 0 if not present or not a valid Int32</returns>
		public Int32 AppSettingGetAsInt( string name, int defaultValue = 0 )
		{
			return Config.GetAppSettingAsInt( this.AgentId, name, defaultValue );
		}

		/// <summary>
		/// Get an Agent-specific application setting as a Boolean
		/// </summary>
		/// <param name="name">The name of the setting to get</param>
		/// <param name="defaultValue">Optional. Specify true if you want the default to not be false</param>
		/// <param name="name">The name of the setting to get</param>
		/// <returns>The config setting converted to an Boolean value, or false if not present or not a valid Boolean</returns>
		public bool AppSettingGetAsBool( string name, bool defaultValue = false )
		{
			return Config.GetAppSettingAsBool( this.AgentId, name, defaultValue );
		}

		#endregion


		/// <summary>
		/// Quick calculator an Agent can use to determine how many send calls they'd transmit to the hub
		/// </summary>
		/// <param name="collectionSize">The # of records to push in the Send() call</param>
		/// <param name="desiredBatchSize">The desired batch size</param>
		/// <returns></returns>
		public int NumberOfBatches( int collectionSize, int desiredBatchSize )
		{
			int rem = 0, groups = 0;
			if ( collectionSize > desiredBatchSize )
			{
				groups = Math.DivRem( collectionSize, 100, out rem );
				if ( rem > 0 )
					groups++;
			}

			return groups;
		}
	}

	#endregion

	#region PublisherBase 

	/// <summary>
	/// For use with Agents that are Publish-only
	/// </summary>
	public abstract class PublisherBase : AgentBase, IPublisher
	{
		public abstract void Publish();
	}

	#endregion

	#region SubscriberBase 

	/// <summary>
	/// For use with Agents that are Subscribe-only
	/// </summary>
	public abstract class SubscriberBase : AgentBase, ISubscriber
	{
		public abstract void Subscribe( AgentWork work );
	}

	#endregion

	#region PubSubBase 

	/// <summary>
	/// For use with Agents that both Publish and Subscribe
	/// </summary>
	public abstract class PubSubBase : AgentBase, IPublisher, ISubscriber
	{
		public abstract void Publish();
		public abstract void Subscribe( AgentWork work );
	}

	#endregion
}
