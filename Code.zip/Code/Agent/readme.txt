﻿Notes:

================================== Introduction ==================================

Agents in this system are worker bees or ants. They don't have visibility into the Hub or what it does, all they
know how to do is either:

	1.	Push data into the system (that they are allowed to), or
	2.	Pull data out of the system (that they are allowed to) for pushing someplace else, then reporting back their outcome

Agents operate in one or both of the following 2 modes:

	1.	Publishers (the ones that push data into the system)
	2.	Subscribers (the ones pulling data out and pushing it someplace)

An Agent can be both/either. The way an Agent works is as follows:


	1.	Create a new Console application project
	2.	Reference JDA.ITG.Flow.Agent.dll
	3.	Copy in the app settings from the agent project
	4.	Implement either IAgentSubscriber or IAgentPublisher
	5.	Do your custom integration to your 3rd party
	6.	Configure in Hub the schedule your agent will operate under

The SampleAgent project demonstrates the various capabilities of an Agent, including the calls it can make to interact with 
it's own data store, maintained at the Hub.


