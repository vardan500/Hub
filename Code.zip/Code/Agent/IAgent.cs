﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow.Agent;
using JDA.ITG.Flow.Agent.Service;

namespace JDA.ITG.Flow
{
	public interface IAgent 
	{
		long AgentId { get; }
		string AgentName { get; }
	}

	/// <summary>Interface that must be implemented by the registering Agent</summary>
	public interface IPublisher : IAgent
	{
		/// <summary>Triggered when the agent's schedule hits.</summary>
		void Publish();
	}

	/// <summary>Interface that must be implemented by the registering Agent</summary>
	public interface ISubscriber : IAgent
	{
		/// <summary>Receives work to process and returns the updated status of the work processed</summary>
		/// <param name="work"></param>
		/// <returns>true if there is work to update</returns>
		void Subscribe( AgentWork workted );
	}
}
