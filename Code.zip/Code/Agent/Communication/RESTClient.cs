﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace JDA.ITG.Flow.Agent.Communication
{
	internal enum EncryptionMode 
	{ 
		Default     = 0, 
		Unencrypted = 1, 
		Encrypted   = 2,
	};

	internal class RESTClient
	{
		public const string REST_CONTENT_TYPE            = "Content-Type";
		public const string REST_CONTENT_TYPE_JSON       = "application/json";
		public const string REST_CONTENT_TYPE_TEXTPLAIN  = "text/plain";
		public const string REST_CONTENT_TYPE_XML        = "application/xml";

		public const string HTTP_GET = "GET";
		public const string HTTP_PUT = "PUT";
		public const string HTTP_POST = "POST";
		public const string HTTP_DELETE = "DELETE";

		#region Constructor

		static RESTClient()
		{
			ServicePointManager.ServerCertificateValidationCallback = ( sender, center, chain, ssl ) => true;
		}

		public RESTClient( int connectTimeoutInSeconds = 5, int commandTimeoutInSeconds = 15 )
		{
			this.LogErrors          = false;
			this.ConnectTimeout     = connectTimeoutInSeconds * 1000;
			this.CommandTimeout     = commandTimeoutInSeconds * 1000;
			this.KeepAlive          = true;
			this.RequestContentType = REST_CONTENT_TYPE_JSON;
			this.HttpLogError       = true;
			this.UserAgent          = "JDA.ITG.FLOW";
		}

		#endregion

		#region Data Members

		protected HttpClient _httpClient = new HttpClient();

		#endregion

		#region Properties

		public bool HttpLogError { get; set; }
		public int ConnectTimeout { get; set; }
		public int CommandTimeout { get; set; }
		public NetworkCredential Credentials { get; set; }

		public bool LogErrors	{ get; set; }
		public bool KeepAlive { get; set; }

		public bool Unauthorized { get; private set; }
		public bool ApplicationError { get; private set; }
		public bool NotFound { get; private set; }
		public bool UnknownStatus { get; private set; }
		public bool ConnectionError { get; private set; }

		public DateTime? RequestedAt { get; private set; }
		public string UserAgent { get; set; }
		public WebHeaderCollection RequestHeaders { get{ return( this._httpClient.Headers );	} }
		public WebHeaderCollection ResponseHeaders { get{ return( this._httpClient.ResponseHeaders );	} }
		public string ResponseVersion { get{ return( this._httpClient.Version );	}	}
		public HttpStatusCode ResponseStatusCode { get{ return( this._httpClient.StatusCode );	} }
		public string ResponseStatusDescription { get{ return( this._httpClient.StatusDescription );	}	}
		public long ResponseLength { get{ return( this._httpClient.ResponseContentLength ); } }
		public string ResponseBody { get; private set; }
		public string ResponseError { get; private set; }
		public Exception ResponseException { get; private set; }
		public string RequestContentType { get; set; }

		#endregion

		#region Reset

		private void Reset()
		{
			Dictionary<string, string> headers = new Dictionary<string, string>();
			foreach ( string key in this._httpClient.Headers.Keys )
				headers.Add( key, this._httpClient.Headers[key] );
	
			this._httpClient       = new HttpClient();

			foreach ( var item in headers )
			{
				if ( string.IsNullOrEmpty( this._httpClient.Headers[item.Key] ) )
					this._httpClient.Headers[item.Key] = item.Value;
			}

			this.ApplicationError  = false;
			this.Unauthorized      = false;
			this.NotFound          = false;
			this.UnknownStatus     = false;
			this.ConnectionError   = false;
			this.ResponseError     = null;
			this.ResponseException = null;
			this.ResponseBody      = string.Empty;
			this.RequestedAt       = null;

			this._httpClient.KeepAlive   = this.KeepAlive;
			this._httpClient.Credentials = this.Credentials;
			this._httpClient.LogError    = this.HttpLogError;
		}

		private void Reset2()
		{
			this.ApplicationError  = false;
			this.Unauthorized      = false;
			this.NotFound          = false;
			this.UnknownStatus     = false;
			this.ConnectionError   = false;
			this.ResponseError     = null;
			this.ResponseException = null;
			this.ResponseBody      = string.Empty;
			this.RequestedAt       = null;
		}

		#endregion

		#region Get

		public T Get<T>( string url )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_GET, null ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		public bool Get( string url )
		{
			return( this.DoRequest( url, HTTP_GET, null ) );
		}

		#endregion

		#region Delete

		public bool Delete( string url )
		{
			return( this.DoRequest( url, HTTP_DELETE, null ) );
		}

		public bool Delete( string url, string data )
		{
			return( this.DoRequest( url, HTTP_DELETE, data ) );
		}

		public T Delete<T>( string url )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_DELETE, null ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		public T Delete<T>( string url, string data )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_DELETE, data ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		#endregion

		#region Post

		public bool Post( string url, string data )
		{
			return( this.DoRequest( url, HTTP_POST, data ) );
		}

		public T Post<T>( string url, string data )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_POST, data ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		#endregion

		#region Put

		public bool Put( string url, string data )
		{
			return( this.DoRequest( url, HTTP_PUT, data ) );
		}

		public T Put<T>( string url, string data )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_PUT, data ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		#endregion

		#region DoRequest

		private bool DoRequest( string url, string method, string postdata )
		{
			bool result = false;

			try
			{
				//Reset the properties
				Reset();

				if( string.IsNullOrEmpty( this.RequestContentType ) == false )
					this._httpClient.ContentType = this.RequestContentType;
				else
					this._httpClient.ContentType = REST_CONTENT_TYPE_JSON;

				
				if ( this.Credentials != null )
					this._httpClient.Credentials = this.Credentials;

				this._httpClient.UserAgent = this.UserAgent;

				//Make sure these are defaulted
				if ( this.ConnectTimeout <= 0 )
					this.ConnectTimeout = 5 * 1000;
				else if ( this.ConnectTimeout <= 100 )
					this.ConnectTimeout = this.ConnectTimeout * 1000;

				if( this.CommandTimeout <= 0 )
					this.CommandTimeout = 15*1000;
				else if ( this.CommandTimeout <= 100 )
					this.CommandTimeout = this.CommandTimeout * 1000;

				//Indicate requested
				this.RequestedAt = DateTime.UtcNow;

				//Execute the http request
				if( this._httpClient.Execute( url, method, postdata, this.ConnectTimeout, this.CommandTimeout ))
				{
					//Was there an exception
					if( this._httpClient.ResponseException != null )
						Log.Debug( 0, string.Format( "Httpclient exception: {0}", this._httpClient.ResponseException ) );

					//Handle decryption
					this.ResponseBody = this._httpClient.ResponseBody;

					//Handle status
					switch ( this.ResponseStatusCode )
					{
						case HttpStatusCode.OK :
						break;

						case HttpStatusCode.RequestTimeout :
						{
							this.ConnectionError = true;

							if( this._httpClient.ResponseException != null )
							{
								if( this.LogErrors )
									Log.Exception( 0, this._httpClient.ResponseException, "HttpClient generated an exception", "DoRequest", url, method, postdata );
							}
						}
						break;

						case HttpStatusCode.PreconditionFailed :
							this.ApplicationError = true;
						break;

						case HttpStatusCode.Unauthorized :
							this.Unauthorized = true;
						break;

						case HttpStatusCode.NotFound :
							this.NotFound = true;
						break;

						default :
							this.UnknownStatus = true;
						break;

					} //end of switch

					result = true;
				}
				else
				{
					//This shouldn't happen
					if( this.LogErrors )
						Log.Error( 0, string.Format( "Invalid http response from uri: {0}", url ) );
				}
			}
			catch ( Exception ex )
			{
				//Hang onto the exception
				this.ResponseException = ex;

				//Was there an exception
				Log.Debug( 0 ,string.Format( "RESTClient exception: {0}"+System.Environment.NewLine+"{1}", this.ResponseException, this._httpClient.ResponseBody ?? string.Empty ) );

				//Should we log
				if( this.LogErrors )
					Log.Exception( 0, ex, string.Format( "Executing uri: {0} generated an exception", url ), "DoRequest", url, method, postdata );
			}

			return( result );
		}

		#endregion


	}
}
