﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using System.Net.Security;
using System.Collections.Concurrent;
using System.Threading;

namespace JDA.ITG.Flow.Agent.Communication
{
	internal class HttpClient
	{

		#region Constructor										|

		static HttpClient()
		{
			ServicePointManager.ServerCertificateValidationCallback = ( sender, center, chain, ssl ) => true;
		}

		public HttpClient()
		{
			//Default keepalive on.
			this.KeepAlive  = true;
			this.StatusCode = HttpStatusCode.Unused;
			this.LogError   = true;
			this.UserAgent = "NPC";
		}

		#endregion

		#region Data Members										|

		private WebHeaderCollection rq_headers = new WebHeaderCollection();
		private WebHeaderCollection rs_headers = new WebHeaderCollection();

		private static char[] HEADER_DELIMITOR = ":".ToCharArray();
		private static char[] METHOD_DELIMITOR = " ".ToCharArray();

		#endregion

		#region Properties										|

		public bool LogError { get; set; }
		public HttpStatusCode StatusCode { get; set; }
		public string StatusDescription { get; set; }
		public bool KeepAlive { get; set; }
		public string Version { get; set; }
		public string UserAgent { get; set; }
		public string ResponseBody { get; set; }
		public int ResponseContentLength { get; set; }
		public NetworkCredential Credentials { get; set; }
		public Exception ResponseException { get; private set; }

		public string ContentType { get { return this.Headers["Content-Type"] ?? string.Empty; } set { this.Headers["Content-Type"] = value; } }
		public WebHeaderCollection Headers { get { return rq_headers; } }

		public string ResponseContentType { get { return this.ResponseHeaders["Content-Type"] ?? string.Empty; } }
		public WebHeaderCollection ResponseHeaders { get { return rs_headers; } }

		private string RawRequest { get; set; }
		private string ErrorResponse { get{ return( string.Format( "HttpClient failed: {0}:{1}", this.StatusCode, this.StatusDescription ) ); } }

		#endregion

		#region AddHeader										|

		public void AddHeader( string name, string value )
		{
			try
			{
				rq_headers.Add( name, value );
			}
			catch { }
		}

		#endregion

		#region SSL									|

		private static bool ValidateServerCertificate( object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors )
		{
			return( true );
			//if( sslPolicyErrors == SslPolicyErrors.None )
			//  return true;

			//Console.WriteLine( "Certificate error: {0}", sslPolicyErrors );

			//// Do not allow this client to communicate with unauthenticated servers.
			//return false;
		}

		#endregion

		#region Execute										|

		public bool Execute( string url, string method, string body, int connectTimeoutInMS, int commandTimeoutInMS )
		{
			Socket           socket = null;
			StringBuilder    sb     = new StringBuilder( 500 );
			Uri              uri    = new Uri( url );
			bool             https  = (url.IndexOf( "https", 0, StringComparison.CurrentCultureIgnoreCase ) != -1);
			bool             sError = false;

			this.RawRequest        = string.Empty;
			this.ResponseBody      = string.Empty;
			this.ResponseException = null;

			this.ResponseHeaders.Clear();

			//Build the http request
			sb.Append( method.ToUpper() );
			sb.Append( " " );
			sb.Append( uri.PathAndQuery );
			sb.AppendLine( " HTTP/1.1" );

			sb.Append( "Host: " );
			sb.AppendLine( uri.Host );
			sb.AppendLine( "User-Agent: " + this.UserAgent );

			//Add all the headers
			foreach ( string key in this.Headers.Keys )
			{
				sb.Append( key  );
				sb.Append( ": " );
				sb.AppendLine( this.Headers[key] );
			} //end of for

			if( this.KeepAlive )
				sb.AppendLine( "Connection: Keep-Alive" );
			else
				sb.AppendLine( "Connection: Close" );

			sb.Append( "Content-Length: " );
			sb.AppendLine( body != null ? body.Length.ToString() : "0" );

			if ( this.Credentials != null )
			{
				string base64Cred = Convert.ToBase64String( System.Text.Encoding.UTF8.GetBytes( this.Credentials.UserName + ":" + this.Credentials.Password ) );

				sb.Append( "Authorization: Basic " );
				sb.AppendLine( base64Cred );
			}

			sb.AppendLine();
			if ( !string.IsNullOrEmpty( body ) )
				sb.Append( body );
			else
				sb.AppendLine();

			//Hold onto the raw request
			this.RawRequest = sb.ToString();

			Log.Debug( 0, string.Format( "Sending request to url: {0}", uri.ToString() ) );

			try
			{
				bool      success = false;
				byte[]    data    = System.Text.Encoding.UTF8.GetBytes( this.RawRequest );
				IPAddress ip      = uri.Host.ToIPAddress();

				//No ips, then we have an error
				if( ip == null )
				{
				  this.StatusCode            = HttpStatusCode.RequestTimeout;
					this.StatusDescription     = string.Format( "Invalid uri: {0}", uri );
				  this.ResponseBody          = string.Empty;
				  this.ResponseContentLength = 0;

					//Log info
					Log.Error( 0, this.ErrorResponse );

					if( LogError )
					{
						//Save the client info for the request
						Log.Error( 0, url + ":" + body );
					}

					return( true );
				}

				//Using a keepalive connection
				if( this.KeepAlive )
				{
					//Get a socket
					socket = HttpConnectionPool.Pool.Open( uri );

					//Did we get a socket
					success = ( socket != null );
				}
				//Using a close connection
				else
				{
					// Initialize the Socket
					socket = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp )
														{
															Blocking = false,
														};

					//Start connection
					IAsyncResult result = socket.BeginConnect( new IPEndPoint( ip, uri.Port ), null, null );  

					//Did we get connected
					if( result.AsyncWaitHandle.WaitOne( connectTimeoutInMS, true ))
						success = socket.Connected;
				}

				if ( success ) 
				{
					try
					{
						const int BUFFERSIZE = 1024*10;

						//Now that connected, make the socket blocking.  This way we can use the NetworkStream class
						socket.Blocking = true;

						//We have https
						if( https )
						{
							using( MemoryStream ms = new MemoryStream() )
							{
								//Process data
								using ( NetworkStream nStream = new NetworkStream( socket, false ) )
								{
									// A client has connected. Create the SslStream using the client's network stream.
									using( SslStream sslStream = new SslStream( nStream, false,	new RemoteCertificateValidationCallback( ValidateServerCertificate ), null ))
									{
										int    cLen      = 0;
										int    spos      = 0;
										bool   hasHeader = false;
										byte[] buffer    = new byte[BUFFERSIZE];

										//Authenticate
										sslStream.AuthenticateAsClient( Log.Application );

										if ( data != null )
											sslStream.Write( data, 0, data.Length );

										while( true )
										{
											//Read in data
											int cnt = nStream.Read( buffer, spos, buffer.Length-spos );
											if( cnt > 0 )
											{
												//Don't have header yet, so try to parse
												if( !hasHeader )
												{
													//We got enough to get all the headers, so mark it as done
													if( this.ReadHeader( buffer, spos+cnt, ms ))
													{
														hasHeader = true;
														spos      = 0;
														cLen      = int.Parse( this.ResponseHeaders["Content-Length"] );
													}
													else
													{
														spos = cnt;
													}
												}
												//We've got the header, so now just get the body
												else
												{
													ms.Write( buffer, spos, cnt );
												}
											}

											//Do we have all the data
											if( hasHeader && cLen == ms.Length )
												break;
										} //end of while
									}
								}

								//Set the body
								this.ResponseBody          = Encoding.UTF8.GetString( ms.ToArray() );
								this.ResponseContentLength = this.ResponseBody.Length;
							}
						}
						//http
						else
						{
							using( MemoryStream ms = new MemoryStream() )
							{
								//Process data
								using ( NetworkStream nStream = new NetworkStream( socket, false ) )
								{
									int    cLen      = 0;
									int    spos      = 0;
									bool   hasHeader = false;
									byte[] buffer    = new byte[BUFFERSIZE];

									if ( data != null )
										nStream.Write( data, 0, data.Length );

									while( true )
									{
										//Read in data
										int cnt = nStream.Read( buffer, spos, buffer.Length-spos );
										if( cnt > 0 )
										{
											//Don't have header yet, so try to parse
											if( !hasHeader )
											{
												//We got enough to get all the headers, so mark it as done
												if( this.ReadHeader( buffer, spos+cnt, ms ))
												{
													hasHeader = true;
													spos      = 0;
													cLen      = int.Parse( this.ResponseHeaders["Content-Length"] );
												}
												else
												{
													spos = cnt;
												}
											}
											//We've got the header, so now just get the body
											else
											{
												ms.Write( buffer, spos, cnt );
											}
										}

										//Do we have all the data
										if( hasHeader && cLen == ms.Length )
											break;
									} //end of while
								}

								//Set the body
								this.ResponseBody          = Encoding.UTF8.GetString( ms.ToArray() );
								this.ResponseContentLength = this.ResponseBody.Length;
							}
						}
					}
				  catch ( SocketException se )
				  {
				    this.ResponseException = se;

						//Have a socket error
						sError = true;

				    switch( se.ErrorCode )
				    {
				      //Connection refused.
				      case 10061 :
				      {
				        this.StatusCode            = HttpStatusCode.RequestTimeout;
				        this.StatusDescription     = string.Format( "Connection refused for uri: {0}", uri );
				        this.ResponseBody          = string.Empty;
				        this.ResponseContentLength = 0;
				      }
				      break;

				      default :
				      {
				        this.StatusCode            = HttpStatusCode.RequestTimeout;
				        this.StatusDescription     = string.Format( "Failed to connect to uri: {0}", uri );
				        this.ResponseBody          = string.Empty;
				        this.ResponseContentLength = 0;
				      }
				      break;
				    } //end of switch

						//Log info
						Log.Error( 0, this.ErrorResponse );

						if( LogError )
						{
							//Save the client info for the request
							Log.Error( 0, url + ":" + body );
						}

				    return( true );
				  }
				  catch ( IOException ioe )
				  {
						//Have a socket error
						sError = true;

				    this.StatusCode            = HttpStatusCode.RequestTimeout;
				    this.StatusDescription     = string.Format( "Failed to read/write data to uri: {0}", uri );
				    this.ResponseBody          = string.Empty;
				    this.ResponseContentLength = 0;
				    this.ResponseException     = ioe;

						//Log info
						Log.Error( 0, this.ErrorResponse );

						if( LogError )
						{
							//Save the client info for the request
							Log.Error( 0, url + ":" + body );
						}

				    return( true );
				  }
				  catch ( Exception e )
				  {
				    this.StatusCode            = HttpStatusCode.RequestTimeout;
				    this.StatusDescription     = string.Format( "Failed to connect to uri: {0}", uri );
				    this.ResponseBody          = string.Empty;
				    this.ResponseContentLength = 0;
				    this.ResponseException     = e;

						//Log info
						Log.Error( 0, this.ErrorResponse );

						if( LogError )
						{
							//Save the client info for the request
							Log.Error( 0, url + ":" + body );
						}

				    return( true );
				  }
				}
				else
				{
					this.StatusCode            = HttpStatusCode.RequestTimeout;
					this.StatusDescription     = string.Format( "Failed to connect to uri: {0}", uri );
					this.ResponseBody          = string.Empty;
					this.ResponseContentLength = 0;

					//Log info
					Log.Error( 0, this.ErrorResponse );

					if( LogError )
					{
						//Save the client info for the request
						Log.Error( 0, url + ":" + body );
					}

					return( true );
				}
			}
			catch ( Exception e )
			{
				this.StatusCode            = HttpStatusCode.RequestTimeout;
				this.StatusDescription     = string.Format( "Failed to connect to uri: {0}", uri );
				this.ResponseBody          = string.Empty;
				this.ResponseContentLength = 0;
				this.ResponseException     = e;

				//Log info
				Log.Error( 0, this.ErrorResponse );

				if( LogError )
				{
					//Save the client info for the request
					Log.Error( 0, url + ":" + body );
				}

				return( true );
			}
			finally
			{
				//Make sure we have a socket
				if( socket != null )
				{
					//Using a keepalive connection
					if( this.KeepAlive )
					{
						//If we didn't have a socket error, then should be good.
						if( !sError )
						{
							//Readd the socket to the pool
							HttpConnectionPool.Pool.Add( uri, socket );
						}
						else
						{
							//Make sure socket is closed
							SocketHelper.CloseSocket( socket );
						}
					}
					//Close
					else
					{
						//Close the socket
						SocketHelper.CloseSocket( socket );
					}
				}
			}

			return( this.StatusCode != HttpStatusCode.Unused );
		}

		#endregion

		#region Utility										|

		private bool ReadHeader( byte[] buffer, int len, MemoryStream body )
		{
			bool result = false;

			//Try to find the end of the headers \r\n\r\n
			for( int i=0; i<len-3; i++ )
			{
				//Look for first CR
				if( buffer[i] == 0x0D )
				{
					//Now see if we have the end of body
					if( buffer[i+1] == 0x0A && buffer[i+2] == 0x0D && buffer[i+3] == 0x0A )
					{
						int  hlen   = i+3;
						bool method = false;

						//Get header data
						using( StringReader sr = new StringReader( Encoding.UTF8.GetString( buffer, 0, len ) ))
						{
							while ( true )
							{
								try
								{
									//Read each line
									string s = sr.ReadLine();

									//Get method first
									if ( !method )
									{
										//Parse and do not do more than 3 possible spaces.
										//ie: GET /test?z=899009&y=test HTTP/1.0
										string[] ary = s.Split( " ".ToCharArray(), 3 );
										if ( ary.Length == 3 )
										{
											this.Version           = ary[0];
											this.StatusCode        = (HttpStatusCode)int.Parse( ary[1] );
											this.StatusDescription = ary[2];
										}
										else
										{
											throw( new Exception( "HTTP request information was invalid" ) );
										}

										method = true;
									}
									//Now get all the headers
									else
									{
										if( !string.IsNullOrEmpty( s ) )
										{
											string[] ary = s.Split( HEADER_DELIMITOR, 2 );
											this.ResponseHeaders.Add( ary[0], ary[1].Trim() );
										}
										else if( s == null )
										{
											break;
										}
									}
								}
								catch 
								{
									break;
								}
							} //end of while

							//We have extra data, put it in the body 
							if( hlen < len )
								body.Write( buffer, hlen+1, len-hlen-1 );
						}

						result = true;

						break;
					}
				}
			} //end of for

			return( result );
		}

		#endregion

	}

	internal static class StringHelper
	{
		public static IPAddress ToIPAddress( this string value )
		{
			if( string.IsNullOrEmpty( value ) || value.Contains( ":") )
				return IPAddress.Loopback;
			else
				return( ToIP4Address( value ) );
		}

		public static IPAddress ToIP4Address( this string value )
		{
			IPAddress result = null;

			//Valid
			if( !string.IsNullOrEmpty( value ) )
			{
				IPAddress[] ips = Dns.GetHostAddresses( value );

				result = ips.FirstOrDefault( c=> c.AddressFamily == AddressFamily.InterNetwork );
			}

			return( result );
		}
	}

	/// <summary>
	/// Connection pool
	/// </summary>
	public sealed class HttpConnectionPool : IDisposable
	{

		#region State										|

		/// <summary>
		/// Connection pool state for each connection.
		/// </summary>
		public sealed class State
		{

			#region Constructor										|

			private State()
			{
			}

			public State( Socket socket )
			{
				this.Socket   = socket;
				this.LastUsed = DateTime.UtcNow;
			}

			#endregion

			#region Properties										|

			public Socket Socket { get; private set; }
			public DateTime LastUsed  { get; set; }

			#endregion

			#region Close										|

			public void Close()
			{
				try
				{
					//Release handle
					if( this.Socket != null )
						SocketHelper.CloseSocket( this.Socket );

					this.Socket = null;
				}
				catch { }
			}

			#endregion

		}

		#endregion

		#region Constructor										|

		static HttpConnectionPool()
		{
			//Start the pool
			Pool.Start();

			//Set defaults
			Pool.ConnectionTimeoutInMS = 5000;
			Pool.SendTimeoutInMS       = 3*60*1000;
			Pool.ReceiveTimeoutInMS    = 3*60*1000;
			Pool.SendBufferSize        = 10*1024;
			Pool.ReceiveBufferSize     = 10*1024;

			//Set the event to handle on exit
			AppDomain.CurrentDomain.DomainUnload += new EventHandler( Pool.CurrentDomain_DomainUnload );
			AppDomain.CurrentDomain.ProcessExit  += new EventHandler( Pool.CurrentDomain_ProcessExit );
		}

		#endregion

		#region IDisposable Members										|

		/// <summary>
		/// Use C# destructor syntax for finalization code.
		/// This destructor will run only if the Dispose method 
		/// does not get called.
		/// It gives your base class the opportunity to finalize.
		/// Do not provide destructors in types derived from this class.
		/// </summary>
		~HttpConnectionPool()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose( false );
		}

		/// <summary>
		/// Implementation of IDisposable.
		/// </summary>
		public void Dispose()
		{
			Dispose( true );

			// This object will be cleaned up by the Dispose method.
			// Therefore, you should call GC.SupressFinalize to
			// take this object off the finalization queue 
			// and prevent finalization code for this object
			// from executing a second time.
			GC.SuppressFinalize( this );
		}

		// Dispose(bool disposing) executes in two distinct scenarios.
		// If disposing equals true, the method has been called directly
		// or indirectly by a user's code. Managed and unmanaged resources
		// can be disposed.
		// If disposing equals false, the method has been called by the 
		// runtime from inside the finalizer and you should not reference 
		// other objects. Only unmanaged resources can be disposed.
		private void Dispose( Boolean _bDisposing )
		{
			// Check to see if Dispose has already been called.
			if( !this.Disposed )
			{
				// If disposing equals true, dispose all managed 
				// and unmanaged resources.
				if( _bDisposing )
				{
					lock( this )
					{
						//Release all connections
						foreach( var kvp in _connections )
						{
							State state = null;

							//Pop each socket and close
							while( kvp.Value.TryDequeue( out state ))
								state.Close();
						} //end of for

						//Release all items
						_connections.Clear();
					}
				}
			}

			this.Disposed = true;         
		}

		#endregion

		#region Data Members										|
		
		private ConcurrentDictionary<string,ConcurrentQueue<State>> _connections      = new ConcurrentDictionary<string,ConcurrentQueue<State>>( StringComparer.CurrentCultureIgnoreCase );
		private Thread                                              _connectionThread = null;

		private const int CHECK_TIMEOUT = 2*60*1000;
		private const int POOL_TIMEOUT  = 1*60*1000;

		private const string CONNECTIONSERVICE = "Httpclient connection processor";

		/// <summary>
		/// Global connection pool
		/// </summary>
		private static HttpConnectionPool CONNECTIONPOOL = new HttpConnectionPool();

		#endregion

		#region Properties										|

		public int ConnectionTimeoutInMS { get; set; }
		public int SendTimeoutInMS { get; set; }
		public int ReceiveTimeoutInMS { get; set; }
		public int SendBufferSize { get; set; }
		public int ReceiveBufferSize { get; set; }

		private bool Disposed { get; set; }
		private bool DomainUnloading { get; set; }

		public static HttpConnectionPool Pool
		{
			get{ return( CONNECTIONPOOL );	}
		}

		#endregion

		#region Start/Stop											|

		private void Start()
		{
			try
			{
				//Start the connection processing
				this.StartConnectionProcess();
			}
			catch ( Exception )
			{
			}
		}

		private void Stop()
		{
			try
			{
				//Should have already been set
				QuitEvent.Set();

				Log.Info( 0, CONNECTIONSERVICE + " Stopping" );

				if( _connectionThread != null )
					_connectionThread.Join( 1000 );
			}
			catch ( Exception )
			{
			}
		}

		private void StartConnectionProcess()
		{
			// Set the reset slaves timer
			Log.Info( 0, CONNECTIONSERVICE + " starting" );

			_connectionThread              = new Thread( new ThreadStart( CheckConnections ) );
			_connectionThread.IsBackground = true;
			_connectionThread.Priority     = ThreadPriority.BelowNormal;
			_connectionThread.Start();
		}

		private void CheckConnections()
		{
			try
			{
				WaitHandle[] handles = { QuitEvent.Get() };
				bool bContinue = true;

				Log.Info( 0, CONNECTIONSERVICE + " status check" );

				do
				{
					switch ( WaitHandle.WaitAny( handles, CHECK_TIMEOUT, false ) )
					{
						//Quit fired
						case 0:
							bContinue = false;
							break;

						//run time
						default:
							{
								//Stop processing
								if ( this.DomainUnloading )
								{
									bContinue = false;
									break;
								}

								try
								{
									//Set the timeout specifier
									DateTime timeout = DateTime.UtcNow.AddMilliseconds( -1 * POOL_TIMEOUT );

									//Check for dead connections
									foreach ( var kvp in _connections )
									{
										//Get the queues current count
										int cnt = kvp.Value.Count;

										//First dequeue each connect
										//Check the time stamp on the connection to see if it hasn't been used for a long time
										//If have been used recently, requeue for use.
										for ( int i = 0; i < cnt; i++ )
										{
											State state = null;
											bool remove = false;

											//Get the item from the queue
											if ( kvp.Value.TryDequeue( out state ) )
											{
												if ( state.LastUsed < timeout )
													remove = true;
												else if ( !SocketHelper.IsConnected( state.Socket ) )
													remove = true;

												//If removed, cleanup, else add back in
												if ( remove )
													state.Close();
												else
													kvp.Value.Enqueue( state );
											}

											//Stop processing
											if ( this.DomainUnloading )
											{
												bContinue = false;
												break;
											}

										} //end of for
									} //end of for
								}
								catch ( Exception )
								{
								}
							}
							break;

					} //end of switch
				} while ( bContinue );
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "Httpclient connection manager thread aborted", "CheckConnections" );
			}

			Log.Info( 0, CONNECTIONSERVICE + " Checked" );

			//Restart processing, abort not normal
			if ( !this.DomainUnloading && !QuitEvent.IsEventSet )
				this.StartConnectionProcess();
		}

		#endregion

		#region Open/Add										|

		private Socket Connect( Uri uri )
		{
			Socket    result = null;
			IPAddress ip     = IPAddress.Parse( uri.Host );

			//No ips, then we have an error
			if( ip == null )
				return( null );

			//Setup the linger options
			LingerOption myOpts = new LingerOption( true, 10 );

			// Initialize the socket so that we use the TCP Protocol, IPv4, and a stream
			Socket socket = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp )
												{ 
													SendTimeout       = this.SendTimeoutInMS,
													SendBufferSize    = this.SendBufferSize,
													ReceiveTimeout    = this.ReceiveTimeoutInMS,
													ReceiveBufferSize = this.SendBufferSize,
													LingerState       = myOpts,
													Blocking          = false,
												};

			try
			{
				//Start connection
				IAsyncResult aresult = socket.BeginConnect( new IPEndPoint( ip, uri.Port ), null, null );  

				//Did we get connected
				if( aresult.AsyncWaitHandle.WaitOne( this.ConnectionTimeoutInMS, true ))
				{
					//Did the socket connect
					if( socket.Connected )
					{
						//Set keepalive at the socket level
						socket.SetSocketOption( SocketOptionLevel.Socket, SocketOptionName.KeepAlive, 1 );

						//Return socket
						result = socket;
					}
				}

				//Connect the socket.
//					socket.Connect( ips[0], uri.Port );

				//Set the keep alive up.
//					socket.SetSocketOption( SocketOptionLevel.Socket, SocketOptionName.KeepAlive, 1 );
				//socket.SetSocketOption( SocketOptionLevel.Socket, SocketOptionName.Linger, myOpts );
				//socket.SetSocketOption( SocketOptionLevel.Socket, SocketOptionName.NoDelay, 1 );

//					result = socket;
			}
			catch ( SocketException )
			{
				//Log.Exception( se, string.Empty, 
				//  new LogNVP( LogNVP.METHOD, System.Reflection.MethodBase.GetCurrentMethod(), uri ) ) );
			}

			return( result );
		}

		private Socket GetQueueSocket( Uri uri, ConcurrentQueue<State> queue )
		{
			Socket result = null;
			State  state  = null;

			//See if have one in queue
			if( queue.TryDequeue( out state ))
			{
				//Not connected, then get next one
				if( !SocketHelper.IsConnected( state.Socket ))
				{
				  result = this.GetQueueSocket( uri, queue );
				}
				//Good, return connection
				else
				{
				  result = state.Socket;
				}
			}
			//Not one there, so connect
			else
			{
				//Connect
				result = Connect( uri );
			}

			if( result != null )
				Log.Debug( 0, string.Format( "Using queued socket handle: {0}", result.Handle ) );

			return( result );
		}

		public void Add( Uri uri, Socket socket )
		{
			try
			{
				ConcurrentQueue<State> queue  = null;

				//Get the queue listing
				if( this._connections.TryGetValue( uri.Authority, out queue ))
				{
					//Push socket back into queue
					queue.Enqueue( new State( socket ) );
				}
				else
				{
					//Try to add again
					this._connections.TryAdd( uri.Authority, new ConcurrentQueue<State>() );

					//Get the queue listing
					if( this._connections.TryGetValue( uri.Authority, out queue ))
					{
						//Push socket back into queue
						queue.Enqueue( new State( socket ) );
					}
					else
					{
						Log.Error( 0, "Unabled to get the httpclient connection pool queue" );
					}
				}
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "Failed to add the httpclient connection pool socket", "Add", uri, socket );
			}
		}

		public Socket Open( Uri uri )
		{
			Socket result = null;

			try
			{
				ConcurrentQueue<State> queue  = null;

				//Get the queue listing
				if( this._connections.TryGetValue( uri.Authority, out queue ))
				{
					result = this.GetQueueSocket( uri, queue );
				}
				else
				{
					//Try to add the listing again
					this._connections.TryAdd( uri.Authority, new ConcurrentQueue<State>() );

					//Get the queue listing
					if( this._connections.TryGetValue( uri.Authority, out queue ))
					{
						result = this.GetQueueSocket( uri, queue );
					}
					else
					{
						Log.Error( 0, "Unabled to get the httpclient connection pool queue" );
					}
				}
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "Failed to open the httpclient connection pool socket", "Open", uri );
			}

			return( result );
		}

		#endregion

		#region Domain Exit

		/// <summary>
		/// Domain unload event
		/// </summary>
		private void CurrentDomain_DomainUnload( object sender, EventArgs e )
		{
			this.DomainUnloading = true;

			try
			{
				QuitEvent.Set();
			}
			catch {}

			//Stop the pool
			this.Stop();

			//Release the pool
			Pool.Dispose();
		}

		/// <summary>
		/// Process exit event
		/// </summary>
		private void CurrentDomain_ProcessExit( object sender, EventArgs e )
		{
			this.DomainUnloading = true;

			try
			{
				QuitEvent.Set();
			}
			catch {}

			//Stop the pool
			this.Stop();

			//Release the pool
			Pool.Dispose();
		}

		#endregion

	}
}
