﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace JDA.ITG.Flow.Agent.Communication
{
	internal class RESTClient2
	{
		public const string REST_CONTENT_TYPE            = "Content-Type";
		public const string REST_CONTENT_TYPE_JSON       = "application/json";
		public const string REST_CONTENT_TYPE_TEXTPLAIN  = "text/plain";
		public const string REST_CONTENT_TYPE_XML        = "application/xml";
		public const string REST_API_HEADER              = "JDA.ITG.FLOW";

		public const string HTTP_GET = "GET";
		public const string HTTP_PUT = "PUT";
		public const string HTTP_POST = "POST";
		public const string HTTP_DELETE = "DELETE";

	  #region Constructor

	  static RESTClient2()
	  {
	    ServicePointManager.ServerCertificateValidationCallback = ( sender, center, chain, ssl ) => true;
	  }

		public RESTClient2( int timeoutInSeconds = 90 )
		{
			this.LogErrors          = false;
			this.Timeout            = timeoutInSeconds * 1000;
	    this.KeepAlive          = true;
	    this.RequestContentType = REST_CONTENT_TYPE_JSON;
	    this.HttpLogError       = true;
	    this.UserAgent          = "NPC";
	  }

	  #endregion

		#region Data Members

		protected HttpWebRequest _request = null;
	  protected HttpWebResponse _response = null;

	  #endregion

	  #region Properties|

	  public bool HttpLogError { get; set; }
	  public int Timeout { get; set; }
	  public NetworkCredential Credentials { get; set; }

	  public bool LogErrors	{ get; set; }
	  public bool KeepAlive { get; set; }

	  public bool Unauthorized { get; private set; }
	  public bool ApplicationError { get; private set; }
	  public bool NotFound { get; private set; }
	  public bool UnknownStatus { get; private set; }
	  public bool ConnectionError { get; private set; }

	  public DateTime? RequestedAt { get; private set; }
	  public string UserAgent { get; set; }
	  public WebHeaderCollection RequestHeaders { get{ return( _request != null ? _request.Headers : new WebHeaderCollection() );	} }
	  public WebHeaderCollection ResponseHeaders { get{ return( _response != null ? _response.Headers : new WebHeaderCollection() );	} }
	  public string ResponseVersion { get{ return( _response != null ? _response.ProtocolVersion.ToString() : string.Empty );	}	}
	  public HttpStatusCode ResponseStatusCode { get{ return( _response != null ? _response.StatusCode : HttpStatusCode.OK );	} }
	  public string ResponseStatusDescription { get{ return( _response != null ? _response.StatusDescription : string.Empty );	}	}
	  public long ResponseLength { get{ return( _response != null ? _response.ContentLength : 0 ); } }
	  public string ResponseBody { get; private set; }
	  public string ResponseError { get; private set; }
	  public bool ResponseEncrypted { get; private set; }
	  public bool ResponseCompressed { get; private set; }
	  public string ResponseUserToken { get; private set; }
	  public Exception ResponseException { get; private set; }
	  public string RequestContentType { get; set; }

	  #endregion


		#region Get

		public T Get<T>( string url )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_GET, null ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		public bool Get( string url )
		{
			return( this.DoRequest( url, HTTP_GET, null ) );
		}

		#endregion

		#region Delete

		public bool Delete( string url )
		{
			return( this.DoRequest( url, HTTP_DELETE, null ) );
		}

		public bool Delete( string url, string data )
		{
			return( this.DoRequest( url, HTTP_DELETE, data ) );
		}

		public T Delete<T>( string url )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_DELETE, null ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		public T Delete<T>( string url, string data )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_DELETE, data ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		#endregion

		#region Post

		public bool Post( string url, string data )
		{
			return( this.DoRequest( url, HTTP_POST, data ) );
		}

		public T Post<T>( string url, string data )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_POST, data ) )
				if ( this.ResponseStatusCode == HttpStatusCode.OK )
					result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		#endregion

		#region Put

		public bool Put( string url, string data )
		{
			return( this.DoRequest( url, HTTP_PUT, data ) );
		}

		public T Put<T>( string url, string data )
		{
			T result = default( T );

			if ( this.DoRequest( url, HTTP_PUT, data ) )
				result = Serializer.Deserialize<T>( this.ResponseBody );

			return result;
		}

		#endregion

	  #region DoRequest										|

	  private bool DoRequest( string url, string method, string postdata )
	  {
	    bool result = false;

	    try
	    {

	      this.ResponseBody = string.Empty;
	      this.ResponseException = null;

	      _request = (HttpWebRequest)HttpWebRequest.Create( url );
	      _request.Method = method;
	      _request.KeepAlive = this.KeepAlive;
	      _request.Credentials = this.Credentials;
				//this allows the hub to separate out calls to the MVC site vs. API calls... (lazy, can also use different port numbers)
				_request.Headers.Add( REST_API_HEADER, "true" );

	      if ( !string.IsNullOrEmpty( this.RequestContentType ) )
	        _request.ContentType = this.RequestContentType;
	      else
	        _request.ContentType = REST_CONTENT_TYPE_JSON;

	      if ( this.Credentials != null )
	        _request.Credentials = this.Credentials;

	      _request.UserAgent = this.UserAgent;

	      //We have post data
	      if ( !string.IsNullOrEmpty( postdata ) )
	      {

	        _request.ContentLength = postdata.Length;
	        using ( StreamWriter sw = new StreamWriter( _request.GetRequestStream() ) )
	        {
	          sw.Write( postdata );
	        }

	      }
	      //Just make sure it empty then
	      else
	      {
	        postdata = string.Empty;
	      }

	      //Make sure these are defaulted
	      if ( this.Timeout <= 0 )
	        this.Timeout = 15 * 1000;
	      else if ( this.Timeout <= 100 )
	        this.Timeout = this.Timeout * 1000;

	      //Indicate requested
	      this.RequestedAt = DateTime.UtcNow;

	      //Execute the http request

	      _request.Timeout = this.Timeout;

	      try
	      {
	        _response = (HttpWebResponse)_request.GetResponse();
	      }
	      catch ( WebException ex )
	      {
	        Log.Debug( 0, string.Format( "Httpclient exception: {0}", ex ) );

	        this.ResponseException = ex;

	        if ( ex.Response != null )
	          _response = (HttpWebResponse)ex.Response;
	      }
	      catch ( Exception ex )
	      {
	        Log.Debug( 0, string.Format( "Httpclient exception: {0}", ex ) );

	        this.ResponseException = ex;

	      }

	      //Execute the http request
	      if ( _response != null )
	      {
	        //Was there an exception
	        if ( this.ResponseException != null )
	          Log.Debug( 0, string.Format( "Httpclient exception: {0}", this.ResponseException ) );

	        //Handle decryption
	        if ( _response.ContentLength > 0 )
	        {
	          using ( StreamReader sr = new StreamReader( _response.GetResponseStream() ) )
	          {
	            this.ResponseBody = sr.ReadToEnd();
	          }
	        }

	        //Handle status
	        switch ( this.ResponseStatusCode )
	        {
	          case HttpStatusCode.OK:
	            break;

	          case HttpStatusCode.RequestTimeout:
	            {
	              this.ConnectionError = true;

	              if ( this.ResponseException != null )
	              {
	                Log.Exception( 0, this.ResponseException, "HttpClient generated an exception", "DoRequest", url, method, postdata );
	              }
	            }
	            break;

	          case HttpStatusCode.PreconditionFailed:
	            {
	              this.ApplicationError = true;
								this.ResponseError = this.ResponseStatusDescription;
	            }
	            break;

	          case HttpStatusCode.Unauthorized:
	            {
	              this.Unauthorized = true;
	            }
	            break;

	          case HttpStatusCode.NotFound:
	            {
	              this.NotFound = true;
	            }
	            break;

	          default:
	            this.UnknownStatus = true;
	            break;

	        } //end of switch

	        result = true;
	      }
	      else
	      {
	        //This shouldn't happen
	        Log.Error( 0, string.Format( "Invalid http response from uri: {0}", url ) );
	      }
	    }
	    catch ( Exception ex )
	    {
	      //Hang onto the exception
	      this.ResponseException = ex;

	      //Was there an exception
	      Log.Debug( 0, string.Format( "RESTClient exception: {0}" + System.Environment.NewLine + "{1}", this.ResponseException, this.ResponseBody ?? string.Empty ) );

	      //Should we log
	      if ( this.LogErrors )
	      {
	        Log.Exception( 0, ex, string.Format( "Executing uri: {0} generated an exception", url ), "DoRequest", url, method, postdata );
	      }
	    }

			return result;
	  }

	  #endregion
	}
}
