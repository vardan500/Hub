﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace JDA.ITG.Flow.Agent.Communication
{
	/// <summary>
	/// Contains the tcp state information
	/// </summary>
	internal class TcpState : IDisposable
	{

		#region Constructor										|

		protected TcpState()
		{
		}

		public TcpState( Socket socket )
		{
			this.Client = socket;

			Reset();
		}

		/// <summary>
		/// Use C# destructor syntax for finalization code.
		/// This destructor will run only if the Dispose method 
		/// does not get called.
		/// It gives your base class the opportunity to finalize.
		/// Do not provide destructors in types derived from this class.
		/// </summary>
		~TcpState()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose( false );
		}

		#endregion

		#region Data Members										|

		public const int MAXBUFFER = 1024*10;

		public byte[] Buffer    = null;
		public int    BytesRecv = 0;

		#endregion

		#region Properties										|

		protected bool Disposed { get; set; }
		public Socket Client { get; private set; }

		#endregion

		#region IDisposable Members										|

		/// <summary>
		/// Implementation of IDisposable.
		/// </summary>
		public virtual void Dispose()
		{
			Dispose( true );

			// This object will be cleaned up by the Dispose method.
			// Therefore, you should call GC.SupressFinalize to
			// take this object off the finalization queue 
			// and prevent finalization code for this object
			// from executing a second time.
			GC.SuppressFinalize( this );
		}

		/// <summary>
		/// Dispose(bool disposing) executes in two distinct scenarios.
		/// If disposing equals true, the method has been called directly
		/// or indirectly by a user's code. Managed and unmanaged resources
		/// can be disposed.
		/// If disposing equals false, the method has been called by the 
		/// runtime from inside the finalizer and you should not reference 
		/// other objects. Only unmanaged resources can be disposed.
		/// </summary>
		/// <param name="_bDisposing"></param>
		protected virtual void Dispose( Boolean _bDisposing )
		{
			// Check to see if Dispose has already been called.
			if( !this.Disposed )
			{
				// If disposing equals true, dispose all managed 
				// and unmanaged resources.
				if( _bDisposing )
				{
					lock( this )
					{
						if( this.Client != null )
						{
							SocketHelper.CloseSocket( this.Client );

							this.Client = null;
						}
					}
				}
			}

			this.Disposed = true;         
		}

		#endregion

		#region Reset										|

		public virtual void Reset()
		{
			Buffer    = new Byte[MAXBUFFER];
			BytesRecv = 0;
		}

		#endregion

	}
	
	/// <summary>
	/// Socket helper routines.
	/// </summary>
	internal static class SocketHelper
	{

		#region Data Members										|

		internal static IntPtr INVALIDHANDLE = new IntPtr( -1 );

		/*
		* All Windows Sockets error constants are biased by WSABASEERR from
		* the "normal"
		*/
		private const Int32 WSABASEERR     = 10000;

		/*
		* Windows Sockets definitions of regular Berkeley error constants
		*/
		private const Int32 WSAEWOULDBLOCK = (WSABASEERR+35);

		#endregion

		#region Close										|

		/// <summary>
		/// Close the socket.
		/// </summary>
		/// <param name="socket"></param>
		public static void CloseSocket( Socket socket )
		{
			//Make sure valid socket object
			if( socket != null )
			{
				//Wrap, incase the socket has issues, so an exception doesn't leave this method.
				try
				{
					//First shutdown the socket.
					socket.Shutdown( System.Net.Sockets.SocketShutdown.Both );
				}
				catch ( ObjectDisposedException )
				{
				}
				catch { }

				//Wrap, incase the socket has issues, so an exception doesn't leave this method.
				try
				{
					//Close the socket.
					socket.Close();
				}
				catch ( ObjectDisposedException )
				{
				}
				catch { }
			}
		}

		#endregion

		#region Connected										|

		/// <summary>
		/// See if the socket is still connected, by polling the TCP/IP stack.
		/// </summary>
		/// <param name="socket">Socket to test</param>
		/// <returns>True if still connected, else false</returns>
		public static bool IsConnected( this Socket socket ) 
		{ 
			try 
			{ 
	      if(( socket != null )&&( socket.Handle != INVALIDHANDLE ))
				{
          // Check for exception first, connection attempt failed.
          if( ( socket.Poll( 0, SelectMode.SelectError ))||
            //connection succeeded or data can be sent, if this is not flagged, have lost connectivity.
             ( !socket.Poll( 0, SelectMode.SelectWrite )) )
					{
					}
					else
					{
						return !( socket.Poll( 0, SelectMode.SelectRead ) && socket.Available == 0 ); 
					}
				}
			} 
			catch( SocketException ) 
			{ 
				return( false );
			} 

			return( false );
		}


//    public static bool IsConnected( Socket socket )
//    {
//      try
//      {
//        //Make sure a valid socket.
//        if(( socket != null )&&( socket.Handle != INVALIDHANDLE ))
//        {
//          // Check for exception first, connection attempt failed.
//          if(( socket.Poll( 0, SelectMode.SelectError ))||
//            //If read set, check to see if connection has been closed/reset/terminated, we can't use Read, because there might be data there
////						 ( socket.Poll( 0, SelectMode.SelectRead ))||
//            //connection succeeded or data can be sent, if this is not flagged, have lost connectivity.
//             ( !socket.Poll( 0, SelectMode.SelectWrite )) )
//          {
//          }
//          else
//          {
//            return( true );
//          }
//        }
//      }
//      catch { }

//      return( false );
//    }

		#endregion

		#region Connecting										|

		/// <summary>
		/// Nonblocking socket connection.
		/// </summary>
		/// <returns>True it connected else false</returns>
		public static bool NonBlockingConnect( Socket socket, IPEndPoint endPoint, int waitTime, ManualResetEvent quit )
		{
			try
			{
				//Set as nonblocking
				socket.Blocking = false;

				try
				{
					//Connect the socket.
					socket.Connect( endPoint );
				}
				catch ( SocketException se )
				{
					//If this isn't blocking, throw the error.
					if( se.ErrorCode != WSAEWOULDBLOCK )
					{
						Log.Error( 0, "Receiving socket is blocking.  Cannot connect with non-blocking socket" );

						return( false );
					}
				}

				int count = waitTime / 2;

				//Now check for connection, waiting between tries.
				do
				{
					//If the quit event is fired, then get out
					if(( quit != null )&&( quit.WaitOne( 0, false ) ))
						break;

					//Now try to see if connection succeeded.
					if( socket.Poll( 0, SelectMode.SelectWrite ) )
						return( true );

					//Not connected yet, so wait a short time
					Thread.Sleep( 2 );

					//Either connected or retries our done.
				} while( count-- > 0 );
			}
			catch { }

			return( false );
		}

		#endregion

	}

	/// <summary>
	/// Contains the socket information for the client communications
	/// Message structure
	///		Length : 5
	///		Type   : 3
	///		Key    : 25
	///		Body   : 0-2048
	/// </summary>
	internal class SocketInfo
	{

		#region Constructor											|

		private SocketInfo()
		{
		}

		#endregion

		#region Data Members										|

		public enum MessageType_T { EngineCompletion=0 };

		#endregion

		#region Properties										|

		public static int MinHeaderSize { get{ return( 5 );	} }
		public MessageType_T MessageType { get; private set; }
		public int Length { get; private set; }
		public string Body { get; private set; }
		public string Key { get; private set; }

		#endregion

		#region Parse										|

		/// <summary>
		/// Message structure
		///		Length : 5
		///		Type   : 3
		///		Key    : 25
		///		Body   : 0-2048
		/// </summary>
		/// <param name="length"></param>
		/// <param name="buffer"></param>
		/// <returns></returns>
		public static SocketInfo Parse( int length, byte[] buffer )
		{
			SocketInfo result = new SocketInfo();

			try
			{
				MessageType_T msgType = MessageType_T.EngineCompletion;

				if( !Enum.TryParse<MessageType_T>( System.Text.ASCIIEncoding.Default.GetString( buffer, SocketInfo.MinHeaderSize, 3 ), true, out msgType ))
					msgType = MessageType_T.EngineCompletion;

				//Set the message
				result.Length      = length;
				result.MessageType = msgType;
				result.Key         = System.Text.ASCIIEncoding.Default.GetString( buffer, SocketInfo.MinHeaderSize+3, 25 );
				result.Body        = System.Text.ASCIIEncoding.Default.GetString( buffer, SocketInfo.MinHeaderSize+3+25, length-(SocketInfo.MinHeaderSize+3+25) );
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "Socket parse failed", "MX.TXEngine.SocketInfo.Parse", length, buffer );

				result = null;
			}

			return( result );
		}

		#endregion

		#region Build									|

		public static byte[] Build( MessageType_T type, string key, string body )
		{
			byte[] result = null;

			//Make sure valid length
			if( key.Length > 25 )
				key = key.Substring( 0, 25 );

			//Make sure it fits
			if( body.Length-(MinHeaderSize+3+25) < TcpState.MAXBUFFER )
			{
				int length = MinHeaderSize + 3 + 25 + body.Length;

				//Build the body
				result = System.Text.ASCIIEncoding.ASCII.GetBytes( ( length.ToString().PadLeft( MinHeaderSize, '0' ) + Convert.ToInt32( type ).ToString().PadLeft( 3, '0' ) + key.PadRight( 25, ' ' ) + body ) );
			}
			else
			{
				Log.Error( 0, "SocketInfo body is too large" );
			}

			return( result );
		}

		#endregion

	}

	/// <summary>
	/// Connection pool
	/// </summary>
	internal sealed class ConnectionPool : IDisposable
	{

		#region State

		/// <summary>
		/// Connection pool state for each connection.
		/// </summary>
		public sealed class State
		{

			#region Constructor

			private State()
			{
			}

			public State( Socket socket )
			{
				this.Socket   = socket;
				this.LastUsed = DateTime.UtcNow;
			}

			#endregion

			#region Properties

			public Socket Socket { get; private set; }
			public DateTime LastUsed  { get; set; }

			#endregion

			#region Close

			public void Close()
			{
				try
				{
					//Release handle
					if( this.Socket != null )
						SocketHelper.CloseSocket( this.Socket );

					this.Socket = null;
				}
				catch ( Exception )
				{
				}
			}

			#endregion

		}

		#endregion

		#region Constructor

		static ConnectionPool()
		{
			//Start the pool
			Pool.Start();

			//Set the event to handle on exit
			AppDomain.CurrentDomain.DomainUnload += new EventHandler( Pool.CurrentDomain_DomainUnload );
			AppDomain.CurrentDomain.ProcessExit  += new EventHandler( Pool.CurrentDomain_ProcessExit );
		}

		#endregion

		#region IDisposable Members

		/// <summary>
		/// Use C# destructor syntax for finalization code.
		/// This destructor will run only if the Dispose method 
		/// does not get called.
		/// It gives your base class the opportunity to finalize.
		/// Do not provide destructors in types derived from this class.
		/// </summary>
		~ConnectionPool()      
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false) is optimal in terms of
			// readability and maintainability.
			Dispose( false );
		}

		/// <summary>
		/// Implementation of IDisposable.
		/// </summary>
		public void Dispose()
		{
			Dispose( true );

			// This object will be cleaned up by the Dispose method.
			// Therefore, you should call GC.SupressFinalize to
			// take this object off the finalization queue 
			// and prevent finalization code for this object
			// from executing a second time.
			GC.SuppressFinalize( this );
		}

		// Dispose(bool disposing) executes in two distinct scenarios.
		// If disposing equals true, the method has been called directly
		// or indirectly by a user's code. Managed and unmanaged resources
		// can be disposed.
		// If disposing equals false, the method has been called by the 
		// runtime from inside the finalizer and you should not reference 
		// other objects. Only unmanaged resources can be disposed.
		private void Dispose( Boolean _bDisposing )
		{
			// Check to see if Dispose has already been called.
			if( !this.Disposed )
			{
				// If disposing equals true, dispose all managed 
				// and unmanaged resources.
				if( _bDisposing )
				{
					//Release the timer
					_tmCheck.Close();

					lock( this )
					{
						//Release all connections
						foreach( var kvp in _connections )
						{
							State state = null;

							//Pop each socket and close
							while( kvp.Value.TryDequeue( out state ))
								state.Close();
						} //end of for

						//Release all items
						_connections.Clear();
					}
				}
			}

			this.Disposed = true;         
		}

		#endregion

		#region Data Members
		
		private ConcurrentDictionary<string,ConcurrentQueue<State>> _connections = new ConcurrentDictionary<string,ConcurrentQueue<State>>( StringComparer.CurrentCultureIgnoreCase );
		private System.Timers.Timer                                 _tmCheck     = new System.Timers.Timer();
		
		private const int CONNECTTIMEOUT = 20*1000;
		private const int CHECKTIMEOUT   = 5*60*1000;
		private const int POOLTIMEOUT    = 30*60*1000;

		/// <summary>
		/// Global connection pool
		/// </summary>
		private static ConnectionPool CONNECTIONPOOL = new ConnectionPool();

		#endregion

		#region Properties

		private bool Disposed { get; set; }
		private bool DomainUnloading { get; set; }

		public static ConnectionPool Pool
		{
			get{ return( CONNECTIONPOOL );	}
		}

		#endregion

		#region Start/Stop

		private void Start()
		{
			try
			{
				// Set the socket timeout timer
				_tmCheck.Enabled  = true;
				_tmCheck.Interval = CHECKTIMEOUT;
				_tmCheck.Elapsed += new System.Timers.ElapsedEventHandler( this.Check_Connections );
			}
			catch { }
		}

		private void Stop()
		{
			try
			{
				//Stop the timer from running.
				_tmCheck.Enabled = false;
			}
			catch { }
		}

		private void Check_Connections( Object sender, System.Timers.ElapsedEventArgs e )
		{
			try
			{
				//Set the timeout specifier
				DateTime timeout = DateTime.Now.AddMilliseconds( -1*POOLTIMEOUT );

				//Check for dead connections
				foreach( var kvp in _connections )
				{
					int cnt = kvp.Value.Count;

					//Stop processing
					if( this.DomainUnloading )
						return;

					//Check each container
					for( int i=0; i<cnt; i++ )
					{
						State state  = null;
						bool  remove = false;

						//Get the item from the queue
						if( kvp.Value.TryDequeue( out state ))
						{
							if( state.LastUsed < timeout )
								remove = true;
							else if( !SocketHelper.IsConnected( state.Socket ))
								remove = true;
						}

						//Stop processing
						if( this.DomainUnloading )
							return;

						//If removed, cleanup, else add back in
						if( remove )
							state.Close();
						else
							kvp.Value.Enqueue( state );
					} //end of for
				} //end of for
			}
			catch { }
		}

		#endregion

		#region Open/Add

		private Socket Connect( string endPoint )
		{
			Socket result = null;

			try
			{
				string[] ip = endPoint.Split( ":".ToCharArray(), 2 );

				if( ip.Length == 2 )
				{
					//Get socket info
					IPAddress address = IPAddress.Parse( ip[0] );
					int       port    = Convert.ToInt32( ip[1] );

					//Valid IP
					if( address != null && port > 0 )
					{
						//Setup the linger options
						LingerOption myOpts = new LingerOption( true, 10 );

						// Initialize the socket so that we use the TCP Protocol, IPv4, and a stream
						Socket socket = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp )
															{ 
																NoDelay        = true,
																SendBufferSize = TcpState.MAXBUFFER,
																SendTimeout    = 10 * 1000,
																LingerState    = myOpts,
															};

						//Create a non-blocking socket
						if( SocketHelper.NonBlockingConnect( socket, new IPEndPoint( address, port ), CONNECTTIMEOUT, null ) )
						{
							//Set the keep alive up.
							socket.SetSocketOption( SocketOptionLevel.Socket, SocketOptionName.KeepAlive, 1 );
							//socket.SetSocketOption( SocketOptionLevel.Socket, SocketOptionName.Linger, myOpts );
							//socket.SetSocketOption( SocketOptionLevel.Socket, SocketOptionName.NoDelay, 1 );

							result = socket;
						}
					}
					else
					{
						Log.Error( 0, string.Format( "Invalid endpoint: {0}", endPoint ) );
					}
				}
				else
				{
					Log.Error( 0, string.Format( "Invalid endpoint: {0}", endPoint ) );
				}
			}
			catch( Exception e )
			{
				Log.Exception( 0, e, "Connection pool connect failed", "Connect", endPoint );
			}

			return( result );
		}

		private Socket GetQueueSocket( string endPoint, ConcurrentQueue<State> queue )
		{
			Socket result = null;
			State  state  = null;

			//See if have one in queue
			if( queue.TryDequeue( out state ))
			{
				//Not connected, then get next one
				if( !SocketHelper.IsConnected( state.Socket ))
				{
				  result = this.GetQueueSocket( endPoint, queue );
				}
				//Good, return connection
				else
				{
				  result = state.Socket;
				}
			}
			//Not one there, so connect
			else
			{
#if DEBUG
				//System.Diagnostics.Trace.WriteLine( "Creating new socket" );
#endif

				//Connect
				result = Connect( endPoint );
			}

			return( result );
		}

		public void Add( string endPoint, Socket socket )
		{
			try
			{
				ConcurrentQueue<State> queue  = null;

				//See if in dictionary yet
				if( !this._connections.ContainsKey( endPoint ))
					this._connections.TryAdd( endPoint, new ConcurrentQueue<State>() );

				//Get the queue listing
				if( this._connections.TryGetValue( endPoint, out queue ))
				{
					//Push socket back into queue
					queue.Enqueue( new State( socket ) );
				}
				else
				{
					Log.Error( 0, "Unabled to get the connection pool queue" );
				}
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "Connection pool add failed", "Add", endPoint, socket );
			}
		}

		public Socket Open( string endPoint )
		{
			Socket result = null;

			try
			{
				ConcurrentQueue<State> queue  = null;

				//See if in dictionary yet
				if( !this._connections.ContainsKey( endPoint ))
					this._connections.TryAdd( endPoint, new ConcurrentQueue<State>() );

				//Get the queue listing
				if( this._connections.TryGetValue( endPoint, out queue ))
				{
					result = this.GetQueueSocket( endPoint, queue );
				}
				else
				{
					Log.Error( 0, "Unabled to get the connection pool queue" );
				}
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "Connection pool open failed", "Open", endPoint );
			}

			return( result );
		}

		#endregion

		#region Domain Exit

		/// <summary>
		/// Domain unload event
		/// </summary>
		private void CurrentDomain_DomainUnload( object sender, EventArgs e )
		{
			this.DomainUnloading = true;

			//Stop the pool
			this.Stop();

			//Release the pool
			Pool.Dispose();
		}

		/// <summary>
		/// Process exit event
		/// </summary>
		private void CurrentDomain_ProcessExit( object sender, EventArgs e )
		{
			this.DomainUnloading = true;

			//Stop the pool
			this.Stop();

			//Release the pool
			Pool.Dispose();
		}

		#endregion

	}

}
