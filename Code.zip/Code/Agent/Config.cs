﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace JDA.ITG.Flow.Agent
{
	#region Config

	internal static class Config
	{
		#region private variables

		//these constants are used to look up settings in app.config
		public const string CONFIG_HUB_URL = "DataHubBaseUrl";
		public const string CONFIG_AGENT_CREDS = "Agent[{0}].Credentials";
		public const string CONFIG_SMTP_INFO = "LoggingSMTP";
		public const string CONFIG_LOGGING_LEVEL = "LoggingLevel";
		public const string CONFIG_HEARTBEAT_INTERVAL = "HeartbeatInterval";
		public const string CONFIG_REST_COMMAND_TIMEOUT = "RESTCommandTimeout";
		public const string CONFIG_REST_CONNECTION_TIMEOUT = "RESTConnectTimeout";

		readonly static char[] COMMA_DELIMITER = ",".ToCharArray();

		//set at startup and/or loaded from the hub
		static volatile string _address = string.Empty;
		static volatile string _machine = string.Empty;
		static volatile int _emergencyAlertDelay = 90;
		static volatile bool _serverUp = false;
		static volatile int _heartbeatInterval = 10;
		static volatile SmtpConfig _smtpInfo = null;
		static volatile bool _properlyConfigured = false;

		//these are used by the AgentManager to keep track of heartbeats sent using the AgentId 0 (used for general config and logging)
		static object _serverLastContactedAtLock = new object();
		static DateTime _serverLastContactedAt = DateTime.MinValue;
		//static readonly ConcurrentDictionary<string, string> _configurationValues = new ConcurrentDictionary<string, string>();
		static internal LoggingLevel LoggingLevel { get; private set; }

		//these lists allow support for multiple agents to operate. Each key below is the Agent Id
		static readonly Dictionary<long, string> _agentCredentials = new Dictionary<long, string>();
		static readonly ConcurrentDictionary<long, AgentStatus> _agentStatus = new ConcurrentDictionary<long, AgentStatus>();
		static readonly ConcurrentDictionary<long, DateTime> _agentLastHeartbeat = new ConcurrentDictionary<long, DateTime>();
		static readonly ConcurrentDictionary<long, AgentConfig> _agents = new ConcurrentDictionary<long, AgentConfig>();
		static readonly ConcurrentDictionary<string, string> _configurationValues = new ConcurrentDictionary<string, string>();

		//if we want to keep track of the work we're doing and the outbound work we want to send back
		//the completed container might be particularly useful if we cannot communicate with the hub and we've finished work..
		//as we can dump this to the manager thread that sends it back on it's next cycle. For now we'll just K.I.S.S
		//this doesn't need a concurrent dictionary because we'll lock on this every time
		static Dictionary<string, WorkInProgress> _workInProcess = new Dictionary<string, WorkInProgress>();
		static string _workInProcessPath = System.Reflection.Assembly.GetEntryAssembly().Location + ".store";
		static object _workInProcessLock = new object();

		#endregion

		#region properties

		//these will only be set once - at startup

		/// <summary>The Url to connect to the Hub</summary>
		internal static string DataHubBaseUrl { get; private set; }

		/// <summary>Indicates whether the component will run in standalone mode (true) or communicate with the hub (false)</summary>
		internal static StandaloneTesting StandaloneTesting { get; private set; }

		/// <summary>Contains information needed to send alerts via SMTP</summary>
		internal static SmtpConfig SmtpInfo { get { return _smtpInfo; } }

		/// <summary>How frequently duplicate alerts should be sent</summary>
		internal static int EmergencyAlertDelay { get { return _emergencyAlertDelay; } }

		/// <summary>Used to track which machine this is running on when logging to the Hub</summary>
		internal static string IPAddress { get { return _address; } }

		/// <summary>Used to track which machine this is running on when logging to the Hub</summary>
		internal static string MachineName { get { return _machine; } }

		/// <summary>Indicates if the Configuration on startup looks good</summary>
		internal static bool ProperlyConfigured { get { return _properlyConfigured; } }

		/// <summary>Frequency to send heartbeats using Agent Id 0</summary>
		internal static int DefaultAgentHeartbeatInterval { get { return _heartbeatInterval; } }

		/// <summary>Indicates if the Agent was able to communicate successfully with the hub</summary>
		internal static bool ServerUp { get { return _serverUp; } }

		/// <summary>The list of configuration errors found during initialization</summary>
		internal static readonly List<string> ConfigurationErrors = new List<string>();

		/// <summary>Lock-wrapped property to access the aforementioned last contact at...</summary>
		internal static DateTime ServerLastContactedAt
		{
			get { lock ( _serverLastContactedAtLock ) { return _serverLastContactedAt; } }
			set { if ( value != null ) lock ( _serverLastContactedAtLock ) { _serverLastContactedAt = value; } }
		}

		#endregion

		#region Load

		/// <summary>Initializes the Configuration for the Agent.</summary>
		public static void Load()
		{
			try
			{
				//by default, we want to log errors
				Config.LoggingLevel = Flow.LoggingLevel.ERROR;

				//load up the IP and machine name
				AssignMachineInfo();

				#region Load App Settings

				Dictionary<string, string> settings = new Dictionary<string, string>();
				//load app settings into the config values list
				foreach ( string key in ConfigurationManager.AppSettings.AllKeys )
					_configurationValues.TryAdd( key, ConfigurationManager.AppSettings.Get( key ) );

				//trigger reloading physical properties from the key/values in _configurationValues
				UpdateGlobalConfiguration();

				#endregion

				#region Setup Agents

				//when making heartbeat calls using Agent Id 0, we still need credentials for the Hub to acknowledge us
				string creds = GetAppSetting( string.Format( CONFIG_AGENT_CREDS, 0 ) );
				if ( string.IsNullOrEmpty( creds ) == true || creds.Split( ":".ToCharArray(), StringSplitOptions.RemoveEmptyEntries ).Length != 2 )
				{
					Log.Error( 0, "Credentials missing or invalid for " + string.Format( CONFIG_AGENT_CREDS, 0 ) );
					return;
				}
				else
				{
					//initialize the last heartbeat and credentials for Agent Id 0
					_agentLastHeartbeat.TryAdd( 0, DateTime.MinValue );
					_agentCredentials.Add( 0, creds );
					//don't need the agent config, as that'll be used in AssignStaticPropertiesFromConfig();
				}

				//The AgentManager built a list of agent classes to support. We'll walk through these now, loading their credentials
				//from the app.config
				foreach ( long agentId in AgentManager.Agents.Keys )
				{
					creds = GetAppSetting( string.Format( CONFIG_AGENT_CREDS, agentId ) );
					if ( string.IsNullOrEmpty( creds ) == true || creds.Split( ":".ToCharArray(), StringSplitOptions.RemoveEmptyEntries ).Length != 2 )
					{
						Log.Error( agentId, "Credentials missing or invalid for " + string.Format( CONFIG_AGENT_CREDS, agentId ) );
						return;
					}
					else
					{
						_agentCredentials.Add( agentId, creds );
						_agentLastHeartbeat.TryAdd( agentId, DateTime.MinValue );
						//we know the add will work, as agentId collision is handled by the AgentManager
						_agents.TryAdd( agentId, new AgentConfig() );
					}

				}

				#endregion

				#region DataHubBaseUrl

				//the URI to communicate with the hub
				DataHubBaseUrl = GetAppSetting( CONFIG_HUB_URL );
				if ( string.IsNullOrEmpty( DataHubBaseUrl ) )
					ConfigurationErrors.Add( "DataHubBaseUrl is missing" );

				#endregion

				#region Setup Standalone Testing

				//Allows a developer to code up an agent without having to connect to a hub
				Config.StandaloneTesting = new StandaloneTesting()
				{
					Enabled = Config.GetAppSettingAsBool( "StandaloneTesting" ),
					HeartbeatFile = Config.GetAppSetting( "StandaloneTesting.HeartbeatFile" ),
					WorkFile = Config.GetAppSetting( "StandaloneTesting.WorkFile" ),
					VolatileFile = Config.GetAppSetting( "StandaloneTesting.VolatileFile" ),
					LogFile = Config.GetAppSetting( "StandaloneTesting.LogFile" ),
				};

				if ( Config.StandaloneTesting.Enabled )
				{
					Config.StandaloneTesting.ProperlyConfigured = false;

					if ( System.IO.File.Exists( Config.StandaloneTesting.HeartbeatFile ) == false )
					{
						Log.Error( 0, "Cannot Initialize Standalone Testing: Unable to find HeartbeatFile at: " + Config.StandaloneTesting.HeartbeatFile );
					}
					else if ( string.IsNullOrEmpty( Config.StandaloneTesting.WorkFile ) == false && System.IO.Directory.Exists( System.IO.Path.GetDirectoryName( Config.StandaloneTesting.WorkFile ) ) == false )
					{
						Log.Error( 0, "Cannot Initialize Standalone Testing: WorkFile path doesn't exist: " + Config.StandaloneTesting.WorkFile );
					}
					else if ( string.IsNullOrEmpty( Config.StandaloneTesting.VolatileFile ) == false && System.IO.Directory.Exists( System.IO.Path.GetDirectoryName( Config.StandaloneTesting.VolatileFile ) ) == false )
					{
						Log.Error( 0, "Cannot Initialize Standalone Testing: VolatileFile path doesn't exist: " + Config.StandaloneTesting.VolatileFile );
					}
					else if ( string.IsNullOrEmpty( Config.StandaloneTesting.LogFile ) == false && System.IO.Directory.Exists( System.IO.Path.GetDirectoryName( Config.StandaloneTesting.LogFile ) ) == false )
					{
						Log.Error( 0, "Cannot Initialize Standalone Testing: LogFile path doesn't exist: " + Config.StandaloneTesting.LogFile );
					}
					else
					{
						try
						{
							//if there is a pre-existing log file, nuke it and start over.
							if ( System.IO.File.Exists( Config.StandaloneTesting.LogFile ) )
							{
								System.IO.File.Delete( Config.StandaloneTesting.LogFile );
							}
						}
						catch { }

						Config.StandaloneTesting.ProperlyConfigured = true;
					}
				}

				#endregion

				if ( ConfigurationErrors.Count == 0 )
					Reload( false, true );

			}
			catch
			{
				//ignore the error at this point..
			}

		}

		#endregion

		#region Reload

		/// <summary>
		/// Called by the HeartBeat Worker every N# of seconds. Allows for in-place reloading of global configuration
		/// </summary>
		/// <param name="reassignMachineInfo"></param>
		/// <param name="loadSettingsFromHub"></param>
		internal static void Reload( bool reassignMachineInfo = true, bool loadSettingsFromHub = true )
		{
			ConfigurationErrors.Clear();

			//Machine name and/or IP can change. We'll regularly check to see if it has
			if ( reassignMachineInfo )
				AssignMachineInfo();

			if ( loadSettingsFromHub )
				LoadDefaultAgentSettings();

			_properlyConfigured = ConfigurationErrors.Count == 0;

			if ( _properlyConfigured )
				_serverUp = true;

			if ( Config.ProperlyConfigured && Config.ServerUp )
				LoadAgents();
		}

		#endregion

		#region Assign Machine Info

		/// <summary>Loads the IP Address and Machine Name from the current system to report to the Hub</summary>
		static void AssignMachineInfo()
		{
			try
			{
				//in case something is changed without power cycling...
				_machine = System.Net.Dns.GetHostName().ToUpper();
				List<System.Net.IPAddress> list = System.Net.Dns.GetHostAddresses( MachineName ).ToList();
				list.RemoveAll( c => c.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork );

				var item = list.FirstOrDefault();

				if ( item == null )
					_address = "127.0.0.1";
				else
					_address = item.ToString();
			}
			catch { }
		}

		#endregion

		#region LoadDefaultAgentSettings

		/// <summary>Is what it sounds like. :) Loads the default agent settings</summary>
		static void LoadDefaultAgentSettings()
		{
			DateTime lastHeartbeat;
			if ( _agentLastHeartbeat.TryGetValue( 0, out lastHeartbeat ) == false )
				lastHeartbeat = DateTime.MinValue;

			if ( lastHeartbeat.AddSeconds( Config.DefaultAgentHeartbeatInterval ) < DateTime.UtcNow )
			{
				HeartbeatResponse rs = null;
				bool success = false;

				_agentLastHeartbeat.AddOrUpdate( 0, DateTime.UtcNow, ( k, v ) => DateTime.UtcNow );

				if ( string.IsNullOrEmpty( DataHubBaseUrl ) == false )
				{
					IntercommOutcome call = Intercomm.TryHeartbeat( 0, out rs );
					success = call.Result == IntercommResult.Success;
					if ( call.Result != IntercommResult.Success )
					{
						Log.Error( 0, "Error while attempting to retrieve the configuration settings: " + call.Error );
						ConfigurationErrors.Add( "Error while attempting to retrieve the configuration settings: " + call.Error );
					}
				}
				else
				{
					ConfigurationErrors.Add( "DataHubBaseUrl and LocalMode heartbeat file is missing" );
				}

				if ( success )
				{
					Config._serverUp = true;
					Config._serverLastContactedAt = DateTime.UtcNow;

					if ( rs.Settings != null && rs.Settings.Count > 0 )
					{
						foreach ( var item in rs.Settings )
							_configurationValues.AddOrUpdate( item.Key, item.Value, ( k, v ) => item.Value );

						//the lines above store the latest configuration settings in the _cv dictionary. now we want to hard-set them to properties
						UpdateGlobalConfiguration();
					}
				}
			}

		}

		#endregion

		#region UpdateGlobalConfiguration

		/// <summary>Set properties defined in Config.cs from the key/value collection returned by the hub</summary>
		static void UpdateGlobalConfiguration()
		{
			#region Update Global App settings (stored in the database as AgentId 0)

			string str;

			#region reload local smtp info

			if ( _configurationValues.TryGetValue( CONFIG_SMTP_INFO, out str ) )
			{
				_smtpInfo = new SmtpConfig( str );
				if ( string.IsNullOrEmpty( SmtpInfo.Error ) == false )
					ConfigurationErrors.Add( "LoggingSMTP connection string is invalid: " + SmtpInfo.Error );
			}

			#endregion

			#region Logging Level

			if ( _configurationValues.TryGetValue( CONFIG_LOGGING_LEVEL, out str ) )
			{
				LoggingLevel level;
				if ( Enum.TryParse<LoggingLevel>( str, out level ) )
					Config.LoggingLevel = level;
				else
				{
					Config.LoggingLevel = LoggingLevel.ERROR;
					Log.Info( 0, "LoggingLevel is not a value enum item, defaulting to DEBUG" );
				}
			}
			else
			{
				Config.LoggingLevel = LoggingLevel.ERROR;
				Log.Error( 0, "LoggingLevel missing" );
			}

			#endregion

			#region Heartbeat Interval

			if ( _configurationValues.TryGetValue( CONFIG_HEARTBEAT_INTERVAL, out str ) )
			{
				int ll;
				if ( int.TryParse( str, out ll ) )
				{
					if ( ll < 5 || ll > 60 )
					{
						ll = 5;
						Log.Info( 0, "HeartbeatInterval interval must be between 5 and 60. Defaulting to 5" );
					}
				}
				else
				{
					ll = 5;
					Log.Info( 0, "HeartbeatInterval interval must be between 5 and 60. Defaulting to 5" );
				}

				Config._heartbeatInterval = ll;
			}

			#endregion

			#endregion

		}

		#endregion

		#region LoadAgents

		/// <summary>
		/// Send heartbeats for all the agents in the exe
		/// </summary>
		static void LoadAgents()
		{
			Dictionary<long, HeartbeatResponse> hearbeats = new Dictionary<long, HeartbeatResponse>();

			foreach ( var agent in _agents.Where( c => c.Key > 0 ) )
			{
				DateTime lastHeartbeat;
				if ( _agentLastHeartbeat.TryGetValue( agent.Key, out lastHeartbeat ) == false )
					lastHeartbeat = DateTime.MinValue;

				if ( lastHeartbeat.AddSeconds( agent.Value.HeartbeatInterval ) < DateTime.UtcNow )
				{
					HeartbeatResponse rs = null;
					bool success = false;

					_agentLastHeartbeat.AddOrUpdate( agent.Key, DateTime.UtcNow, ( k, v ) => DateTime.UtcNow );

					if ( string.IsNullOrEmpty( DataHubBaseUrl ) == false )
					{
						IntercommOutcome call = Intercomm.TryHeartbeat( agent.Key, out rs );
						success = call.Result == IntercommResult.Success;

						if ( call.Result != IntercommResult.Success )
							ConfigurationErrors.Add( "Error while attempting to retrieve the configuration settings: " + call.Error );
					}
					else
					{
						ConfigurationErrors.Add( "DataHubBaseUrl and LocalMode heartbeat file is missing" );
					}

					if ( success )
					{
						hearbeats.Add( agent.Key, rs );
						AgentStatus status = rs.Enabled ? AgentStatus.Ready : AgentStatus.Paused;
						_agentStatus.AddOrUpdate( agent.Key, status, ( k, v ) => status );
						agent.Value.Schedule = rs.Schedule;
						if ( rs.Settings != null && rs.Settings.Count > 0 )
							agent.Value.Settings = rs.Settings;

					}
					else
					{
						_agentStatus.AddOrUpdate( agent.Key, AgentStatus.Ready, ( k, v ) => AgentStatus.Paused );
					}
				}
			}
		}

		#endregion

		#region Agent helper methods

		public static Dictionary<long, AgentConfig> GetAgents()
		{
			Dictionary<long, AgentConfig> results = new Dictionary<long, AgentConfig>();

			lock ( _agents )
			{
				foreach ( var item in _agents )
					results.Add( item.Key, item.Value );
			}
			return results;
		}

		public static AgentConfig GetAgent( long agentId )
		{
			AgentConfig ac = null;
			lock ( _agents )
			{
				_agents.TryGetValue( agentId, out ac );
			}
			return ac;
		}

		public static string GetAgentCredentials( long agentId )
		{
			string creds;
			_agentCredentials.TryGetValue( agentId, out creds );
			return creds ?? string.Empty;
		}

		public static AgentStatus GetAgentStatus( long agentId )
		{
			return _agentStatus.GetOrAdd( agentId, AgentStatus.None );
		}

		public static void DisableAgent( long agentId )
		{
			_agentStatus.AddOrUpdate( agentId, AgentStatus.Paused, ( k, v ) => AgentStatus.Paused );
		}

		#endregion

		#region GetAppSetting

		internal static string GetAppSetting( string name )
		{
			string value = string.Empty;
			_configurationValues.TryGetValue( name, out value );
			return value;
		}

		internal static Int32 GetAppSettingAsInt( string name, int defaultValue = 0 )
		{
			string value = GetAppSetting( name );
			int i;
			if ( int.TryParse( value, out i ) )
				return i;
			else
				return defaultValue;
		}

		internal static bool GetAppSettingAsBool( string name, bool defaultValue = false )
		{
			string value = GetAppSetting( name );
			bool b;
			if ( bool.TryParse( value, out b ) )
				return b;
			else
				return defaultValue;
		}

		internal static string GetAppSetting( long agentId, string name )
		{
			if ( agentId <= 0 )
			{
				Log.Error( 0, "GetAppSetting requires the agentId parameter to be non-null" );
				return string.Empty;
			}

			AgentConfig ac;
			string value = string.Empty;
			if ( _agents.TryGetValue( agentId, out ac ) )
				ac.Settings.TryGetValue( name, out value );


			return value ?? string.Empty;
		}

		internal static Int32 GetAppSettingAsInt( long agentId, string name, int defaultValue = 0 )
		{
			string value = GetAppSetting( agentId, name );

			int i;
			if ( int.TryParse( value, out i ) )
				return i;
			else
				return defaultValue;
		}

		internal static bool GetAppSettingAsBool( long agentId, string name, bool defaultValue = false )
		{
			string value = GetAppSetting( agentId, name );

			bool b;
			if ( bool.TryParse( value, out b ) )
				return b;
			else
				return defaultValue;
		}

		#endregion

		#region Save/Load (this is on hold and is a Work In Progress. Overkill for now)

		/// <summary>
		/// Saves the items current being processed to disk (in case the server is down and this guy closes)
		/// </summary>
		internal static void SaveWorkInProgressToDisk()
		{
			lock ( _workInProcessLock )
			{
				try
				{
					if ( _workInProcess.Count == 0 )
						return;

					string json = Serializer.Serialize( _workInProcess, false );
					json = Compression.CompressToBase64( json );
					json = Crypto.Encryption( json );

					using ( System.IO.StreamReader sr = new System.IO.StreamReader( _workInProcessPath ) )
					{
						sr.ReadToEnd();
					}

					if ( string.IsNullOrEmpty( json ) )
						return;

				}
				catch { }
			}
		}

		/// <summary>
		/// Loads the worked data stored locally back into memory for transmission to the hub
		/// </summary>
		internal static void LoadWorkInProgressFromDisk()
		{
			lock ( _workInProcessLock )
			{
				try
				{
					string json = string.Empty;
					using ( System.IO.StreamReader sr = new System.IO.StreamReader( _workInProcessPath ) )
					{
						sr.ReadToEnd();
					}

					if ( string.IsNullOrEmpty( json ) )
						return;

					json = Crypto.Decryption( json );
					json = Compression.DecompressFromBase64( json );

				}
				catch { }
			}
		}

		internal static void SaveWorkInProgress( AgentWork work )
		{
			if ( work == null || work.Count == 0 )
				return;

			lock ( _workInProcessLock )
			{
				bool updated = false;

				foreach ( var item in work )
				{
					string key = string.Format( "{0}:{1}", item.ObjectName, item.ObjectKey );

					if ( _workInProcess.ContainsKey( key ) == false )
					{
						updated = true;
						_workInProcess.Add( key, new WorkInProgress() { Work = item } );
					}
				}

				if ( updated )
					SaveWorkInProgressToDisk();
			}
		}

		internal static void RemoveWorkInProgress( AgentWork work )
		{
			if ( work == null || work.Count == 0 )
				return;

			lock ( _workInProcessLock )
			{
				bool updated = false;

				foreach ( var item in work )
				{
					string key = string.Format( "{0}:{1}", item.ObjectName, item.ObjectKey );
					if ( _workInProcess.Remove( key ) && updated == false )
						updated = true;
				}

				if ( updated )
					SaveWorkInProgressToDisk();
			}
		}

		#endregion
	}

	#endregion

	#region AgentConfig

	internal class AgentConfig
	{
		public AgentConfig()
		{
			this.HeartbeatInterval = 10;
			this.LoggingLevel = Flow.LoggingLevel.DEBUG;
			this.ImmediatelyRerun = false;
			this.Settings = new Dictionary<string, string>();
			this.Schedule = null;
		}

		internal int HeartbeatInterval { get; set; }
		internal LoggingLevel LoggingLevel { get; set; }
		internal bool ImmediatelyRerun { get; set; }
		internal Dictionary<string, string> Settings  { get; set; }
		internal AgentSchedule Schedule { get; set; }
	}

	#endregion

	#region SmtpConfig

	internal class SmtpConfig
	{
		static char[] SC = ";".ToCharArray();
		static char[] EQ = "=".ToCharArray();

		public SmtpConfig( string settings )
		{
			try
			{
				if ( string.IsNullOrEmpty( settings ) == false )
				{
					string[] kvp = settings.Split( SC );
					foreach ( string s in kvp )
					{
						string[] item = s.Split( EQ );
						string key = item.FirstOrDefault();
						string value = item.LastOrDefault();

						if ( string.IsNullOrEmpty( key ) || string.IsNullOrEmpty( value ) )
							continue;

						switch ( key.ToLower() )
						{
							case "username":
								this.Username = value;
								break;

							case "password":
								this.Password = value;
								break;

							case "from":
								this.From = value;
								break;

							case "recipients":
								this.Recipients = value;
								break;

							case "host":
								this.Host = value;
								break;

							case "enabled":
								this.Enabled = value.ToLower() == "true";
								break;

							case "usessl":
								this.UseSSL = value.ToLower() == "true";
								break;

							case "delay":
								{
									int i = 0;
									if ( int.TryParse( value, out i ) )
										this.Delay = i;
									else
										this.Delay = 90;
									break;
								}

							case "port":
								{
									int i = 0;
									if ( int.TryParse( value, out i ) )
										this.Port = i;
									else
										this.Port = 25;
									break;
								}

							case "timeout":
								{
									int i = 0;
									if ( int.TryParse( value, out i ) )
										this.Timeout = i;
									else
										this.Timeout = 90;
									break;
								}
						}
					}


					List<string> errors = new List<string>();

					//fallback in case this is screwed up. No logging will happen here..
					if ( this.Username == null )
						errors.Add( "Username missing" );
					if ( this.Password == null )
						errors.Add( "Password missing" );
					if ( this.Host == null )
						errors.Add( "Host missing" );
					if ( this.Port == 0 )
						errors.Add( "Port == 0" );
					if ( this.From == null )
						errors.Add( "From missing" );
					if ( this.Recipients == null )
						errors.Add( "Recipients missing" );

					this.Error = string.Join( ", ", errors );
					this.Enabled = string.IsNullOrEmpty( this.Error );
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( 0, ex, "Error parsing SmtpConfig", "SmtpConfig Constructor", settings );
			}
		}

		public string Error { get; set; }

		public bool Enabled { get; set; }
		public int Delay { get; set; }
		public string From { get; set; }
		public string Host { get; set; }
		public int Port { get; set; }
		public string Username { get; set; }
		public string Password { get; set; }
		public int Timeout { get; set; }
		public string Recipients { get; set; }
		public bool UseSSL { get; set; }
		public bool ConsumerEnabled { get; set; }
	}

	#endregion

	#region StandaloneTesting

	/// <summary>
	/// Simple object for storing the standalone testing config
	/// </summary>
	internal class StandaloneTesting
	{
		public bool Enabled = false;
		public bool ProperlyConfigured = false;
		public string HeartbeatFile = string.Empty;
		public string WorkFile = string.Empty;
		public string VolatileFile = string.Empty;
		public string LogFile = string.Empty;
	}

	#endregion

	#region WorkInProgress (this is on hold and is a Work In Progress. Overkill for now)

	public class WorkInProgress
	{
		public bool InProcess { get; set; }
		public AgentWorkItem Work { get; set; }
	}

	#endregion
}