﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDA.ITG.Flow.Agent
{
	internal enum IntercommResult 
	{ 
		Success = 0, 
		Failure = 1, 
		Error = 2,
		AlreadyRunning = 3
	}

	/// <summary>
	/// Wrapper class providing details of failures when communicating with the Hub
	/// </summary>
	internal class IntercommOutcome
	{
		public IntercommOutcome( IntercommResult result = IntercommResult.Success, string error = null )
		{
			this.Result = result;
			this.Error = error ?? string.Empty;
		}

		public IntercommResult Result { get; set; }
		public string Error { get; set; }
	}
}

