﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDA.ITG.Flow.Agent
{
	#region StandaloneVolatileItems

	/// <summary>
	/// Local "store" of agent data for use in offline/standalone mode. Allows for reading and writing of agent-specific data
	/// </summary>
	internal class StandaloneVolatileItems : List<StandaloneVolatileItem>
	{
		#region GetItems

		public AgentData GetItems( long agentId )
		{
			AgentData items = new AgentData();

			foreach( var item in this.Where( c=> c.AgentId == agentId ) )
				items.Add( item.Name, item.Value );

			return items;
		}

		#endregion

		#region SetItems

		public void SetItems( AgentDataUpdateRequest items )
		{
			if ( items != null && items.Items.Count > 0 )
			{
				foreach ( var item in items.Items )
				{
					this.RemoveAll( c => c.AgentId == items.AgentId && c.Name == item.Key );
					this.Add( new StandaloneVolatileItem() { AgentId = items.AgentId, Name = item.Key, Value = item.Value } );
				}
			}
		}

		#endregion

		#region DeleteItems

		public void DeleteItems( AgentDataDeleteRequest items )
		{
			if ( items != null && items.Items.Count > 0 )
			{
				foreach ( var item in items.Items )
				{
					this.RemoveAll( c => c.AgentId == items.AgentId && c.Name == item.Key );
				}
			}
		}

		#endregion

		#region static Get

		internal static IntercommOutcome Get( AgentDataGetRequest request, out AgentDataGetResponse response )
		{
			IntercommOutcome outcome = new IntercommOutcome();
			response = new AgentDataGetResponse();
			StandaloneVolatileItems store = null;

			try
			{
				if ( System.IO.File.Exists( Config.StandaloneTesting.VolatileFile ) )
				{
					using ( System.IO.StreamReader reader = new System.IO.StreamReader( Config.StandaloneTesting.VolatileFile ) )
					{
						store = Serializer.Deserialize<StandaloneVolatileItems>( reader.ReadToEnd() );
					}
				}
			}
			catch ( Exception ex )
			{
				outcome = new IntercommOutcome( IntercommResult.Error, string.Format( "Error reading StandaloneTesting.VolatileFile: {0}, Stack: {1}", ex.Message, ex.StackTrace ) );
				response.Error = CommandError.SystemError;
				response.Message = outcome.Error;
			}

			response.Items = ( store != null ) ? store.GetItems( request.AgentId ) : new AgentData();

			return outcome;
		}

		#endregion

		#region static Delete

		internal static IntercommOutcome Delete( AgentDataDeleteRequest request, out AgentDataDeleteResponse response )
		{
			IntercommOutcome outcome = new IntercommOutcome();
			response = new AgentDataDeleteResponse();
			StandaloneVolatileItems store = null;

			try
			{
				try
				{
					if ( System.IO.File.Exists( Config.StandaloneTesting.VolatileFile ) )
					{
						using ( System.IO.StreamReader reader = new System.IO.StreamReader( Config.StandaloneTesting.VolatileFile ) )
						{
							store = Serializer.Deserialize<StandaloneVolatileItems>( reader.ReadToEnd() );
						}
					}
				}
				catch ( Exception ex )
				{
					outcome.Result = IntercommResult.Error;
					outcome.Error = string.Format( "Error reading StandaloneTesting.VolatileFile: {0}, Stack: {1}", ex.Message, ex.StackTrace );
				}

				if ( store == null )
					store = new StandaloneVolatileItems();

				store.DeleteItems( request );

				using ( System.IO.StreamWriter writer = new System.IO.StreamWriter( Config.StandaloneTesting.VolatileFile ) )
				{
					writer.Write( Serializer.Serialize( store, true ) );
				}
			}
			catch ( Exception ex )
			{
				outcome.Result = IntercommResult.Error;
				outcome.Error = string.Format( "Error reading StandaloneTesting.VolatileFile: {0}, Stack: {1}", ex.Message, ex.StackTrace );
				response.Error = CommandError.SystemError;
				response.Message = outcome.Error;
			}

			return outcome;
		}

		#endregion

		#region static Update

		internal static IntercommOutcome Update( AgentDataUpdateRequest request, out AgentDataUpdateResponse response )
		{
			IntercommOutcome outcome = new IntercommOutcome();
			response = new AgentDataUpdateResponse();
			StandaloneVolatileItems store = null;

			try
			{
				try
				{
					if ( System.IO.File.Exists( Config.StandaloneTesting.VolatileFile ) )
					{
						using ( System.IO.StreamReader reader = new System.IO.StreamReader( Config.StandaloneTesting.VolatileFile ) )
						{
							store = Serializer.Deserialize<StandaloneVolatileItems>( reader.ReadToEnd() );
						}
					}
				}
				catch ( Exception ex )
				{
					outcome.Result = IntercommResult.Error;
					outcome.Error = string.Format( "Error reading StandaloneTesting.VolatileFile: {0}, Stack: {1}", ex.Message, ex.StackTrace );
				}

				if ( store == null )
					store = new StandaloneVolatileItems();

				store.SetItems( request );

				using ( System.IO.StreamWriter writer = new System.IO.StreamWriter( Config.StandaloneTesting.VolatileFile ) )
				{
					writer.Write( Serializer.Serialize( store, true ) );
				}
			}
			catch ( Exception ex )
			{
				outcome.Result = IntercommResult.Error;
				outcome.Error = string.Format( "Error reading StandaloneTesting.VolatileFile: {0}, Stack: {1}", ex.Message, ex.StackTrace );
				response.Error = CommandError.SystemError;
				response.Message = outcome.Error;
			}

			return outcome;
		}

		#endregion
	}

	#endregion

	#region StandaloneVolatileItem

	public class StandaloneVolatileItem
	{
		public long AgentId { get; set; }
		public string Name { get; set; }
		public string Value { get; set; }
	}

	#endregion

}

