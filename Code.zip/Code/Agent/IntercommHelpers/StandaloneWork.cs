﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDA.ITG.Flow.Agent
{
	#region StandaloneWorkRecord 

	/// <summary>
	/// Used for standalone, disconnected mode as a storage for GetWork and UpdateWork
	/// </summary>
	internal class StandaloneWorkRecord
	{
		public StandaloneWorkRecord() { }

		public StandaloneWorkRecord( AgentWorkItem record )
		{
			this.Data = record.Document;
			this.Date = DateTime.UtcNow;
			this.Key = record.ObjectKey;
			this.ObjectName = record.ObjectName;
		}

		public string ObjectName { get; set; }
		public string Key { get; set; }
		public string Data { get; set; }
		public DateTime Date { get; set; }
		public long SuccessfulAgents {get;set;}
		public long ErrorAgents {get;set;}
	}

	#endregion

	#region StandaloneWorkRecords

	/// <summary>
	/// Used for standalone, disconnected mode as a storage for GetWork and UpdateWork
	/// </summary>
	class StandaloneWorkRecords : List<StandaloneWorkRecord>
	{
		#region GetWork

		internal AgentWork GetWork( WorkGetRequest request )
		{
			AgentWork results = new AgentWork();
			foreach ( var item in this )
			{
				if ( ( item.SuccessfulAgents & request.AgentId ) != request.AgentId )
					results.Add( new AgentWorkItem() { Document = item.Data, ObjectKey = item.Key, ObjectName = item.ObjectName } );
			}
			return results;
		}

		#endregion

		#region UpdateWork

		internal void UpdateWork( WorkUpdateRequest request )
		{
			if ( request.Work != null )
			{
				foreach ( var item in request.Work )
				{
					//if there is a document, then we're saving a new item. If it aleady exists, overwrite it 
					if ( string.IsNullOrEmpty( item.Document ) )
					{
						this.RemoveAll( c => c.ObjectName == item.ObjectName && c.Key == item.ObjectKey );
						this.Add( new StandaloneWorkRecord( item ) );
					}
					else
					{
						//if there is no document, we're updating the status

						//see if the item truly exists
						var existing = this.SingleOrDefault( c => c.ObjectName == item.ObjectName && c.Key == item.ObjectKey );
						if ( existing != null )
						{
							existing.Date = DateTime.UtcNow;
							if ( item.Successful )
							{
								//set the flag to add the agent to the bitflag of agents that already worked this data
								existing.SuccessfulAgents |= request.AgentId;
								//and remove the flag (if set) from the errors flag
								if ( ( existing.ErrorAgents & request.AgentId ) == request.AgentId )
									existing.ErrorAgents ^= request.AgentId;
							}
							else
							{
								//set the flag to add the agent to the bitflag of agents that already err'd this data
								existing.ErrorAgents |= request.AgentId;
								//and remove the flag (if set) from the successful flag
								if ( ( existing.SuccessfulAgents & request.AgentId ) == request.AgentId )
									existing.SuccessfulAgents ^= request.AgentId;
							}
						}
					}
				}
			}
		}

		#endregion

		#region static Get

		internal static IntercommOutcome Get( WorkGetRequest request, out WorkGetResponse response )
		{
			IntercommOutcome outcome = new IntercommOutcome();
			response = new WorkGetResponse();
			StandaloneWorkRecords store = null;

			try
			{
				using ( System.IO.StreamReader reader = new System.IO.StreamReader( Config.StandaloneTesting.WorkFile ) )
				{
					store = Serializer.Deserialize<StandaloneWorkRecords>( reader.ReadToEnd() );
				}
			}
			catch ( Exception ex )
			{
				outcome = new IntercommOutcome( IntercommResult.Error, string.Format( "Error reading StandaloneTesting.GetWorkFile: {0}, Stack: {1}", ex.Message, ex.StackTrace ) );
				response.Error = CommandError.SystemError;
				response.Message = outcome.Error;
			}

			response.Work = ( store != null ) ? store.GetWork( request ) : new AgentWork();

			return outcome;
		}

		#endregion

		#region static Update

		internal static IntercommOutcome Update( WorkUpdateRequest request, out WorkUpdateResponse response )
		{
			IntercommOutcome outcome = new IntercommOutcome();
			response = new WorkUpdateResponse();
			StandaloneWorkRecords store = null;

			try
			{
				try
				{
					if ( System.IO.File.Exists( Config.StandaloneTesting.WorkFile ) )
					{
						using ( System.IO.StreamReader reader = new System.IO.StreamReader( Config.StandaloneTesting.WorkFile ) )
						{
							store = Serializer.Deserialize<StandaloneWorkRecords>( reader.ReadToEnd() );
						}
					}
				}
				catch ( Exception ex )
				{
					outcome.Result = IntercommResult.Error;
					outcome.Error = string.Format( "Error reading StandaloneTesting.GetWorkFile: {0}, Stack: {1}", ex.Message, ex.StackTrace );
				}

				if ( store == null )
					store = new StandaloneWorkRecords();

				store.UpdateWork( request );

				using ( System.IO.StreamWriter writer = new System.IO.StreamWriter( Config.StandaloneTesting.WorkFile ) )
				{
					writer.Write( Serializer.Serialize( store, true ) );
				}
			}
			catch ( Exception ex )
			{
				outcome.Result = IntercommResult.Error;
				outcome.Error = string.Format( "Error reading StandaloneTesting.UpdateWorkFile: {0}, Stack: {1}", ex.Message, ex.StackTrace );
				response.Error = CommandError.SystemError;
				response.Message = outcome.Error;
			}

			return outcome;
		}

		#endregion
	}

	#endregion
}

