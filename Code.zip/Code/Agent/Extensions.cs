﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDA.ITG.Flow.Agent
{
	#region String Helper Extension Methods

	public static class StringHelper
	{
		#region ToStream

		public static System.IO.Stream ToStream( this string value )
		{
			return new System.IO.MemoryStream( System.Text.Encoding.UTF8.GetBytes( value ?? string.Empty ) );
		}

		#endregion

		#region ToByte		

		public static Byte ToByte( this string value, Byte defValue )
		{
			Byte nReturn = defValue;

			try
			{
				if ( !byte.TryParse( value, out nReturn ) )
					nReturn = defValue;
			}
			catch { }

			return ( nReturn );
		}

		#endregion

		#region Between	

		public static bool IsValidLongBetween( this String value, long min, long max )
		{
			long l;
			if ( min > max )
				return false;
			if ( value == null )
				return false;

			if ( long.TryParse( value, out l ) )
				if ( l >= min && l <= max )
					return true;

			return false;
		}

		#endregion

		#region First/Last	

		public static String FirstN( this String value, Int32 len )
		{
			return FirstN( value, len, false );
		}

		public static String FirstN( this String value, Int32 len, Boolean pad )
		{
			String strReturn = String.Empty;

			try
			{
				if( !string.IsNullOrEmpty( value ) )
					if( value.Length > len )
						strReturn = value.Substring( 0, len );
					else
						strReturn = value;

				if( pad && strReturn.Length < len )
					strReturn = strReturn.PadRight( len, ' ' );
			}
			catch ( Exception )
			{
			}

			return ( strReturn );
		}

		public static String LastN( this String value, Int32 len )
		{
			return LastN( value, len, false );
		}

		public static String LastN( this String value, Int32 len, Boolean pad )
		{
			String strReturn = String.Empty;

			try
			{
				if( !string.IsNullOrEmpty( value ) )
					if( value.Length > len )
						strReturn = value.Substring( value.Length - len, len );
					else
						strReturn = value;

				if( pad && strReturn.Length < len )
					strReturn = strReturn.PadRight( len, ' ' );
			}
			catch ( Exception )
			{
			}

			return ( strReturn );
		}

		#endregion

		#region Masks

		public static string Mask4( this String value )
		{
			if ( value.IsNullOrEmpty() )
				return string.Empty;
			else
				return Mask( value, 4 );
		}

		public static string MaskAll( this String value )
		{
			if ( value.IsNullOrEmpty() )
				return string.Empty;
			else
				return Mask( value, value.Length );
		}

		public static string Mask( this String value, Int32 len )
		{
			try
			{
				if ( value.IsNullOrEmpty() )
					return string.Empty;
				else if ( value.Length > len )
					return new string( '*', value.Length - len ) + value.Substring( value.Length - len, len );
				else
					return value;
			}
			catch ( Exception ex )
			{
				Log.Exception( 0, ex, "Mask failed", "Mask", value, len );
			}

			return value;
		}

		#endregion

		#region Base64	

		public static String ToBase64( this String value )
		{
			String strReturn = String.Empty;

			try
			{
				strReturn = Convert.ToBase64String( System.Text.ASCIIEncoding.UTF8.GetBytes( value ) );
			}
			catch ( Exception )
			{
			}

			return ( strReturn );
		}

		public static String FromBase64( this String value )
		{
			String strReturn = String.Empty;

			try
			{
				strReturn = System.Text.ASCIIEncoding.UTF8.GetString( Convert.FromBase64String( value ) );
			}
			catch ( Exception )
			{
			}

			return ( strReturn );
		}

		#endregion

		#region GUID	

		public static Guid ToGUID( this String value )
		{
			Guid strReturn = Guid.Empty;

			try
			{
				if( !string.IsNullOrEmpty( value ) )
					strReturn = new Guid( value );
			}
			catch ( Exception )
			{
			}

			return ( strReturn );
		}

		public static Boolean IsGuid( this String value )
		{
			Boolean bReturn = false;

			try
			{
				if( !string.IsNullOrEmpty( value ) )
				{
					Guid g = new Guid( value );
					bReturn = true;
				}
			}
			catch ( Exception )
			{
			}

			return ( bReturn );
		}

		#endregion

		#region ToBoolean

		public static Boolean ToBoolean1( this String value )
		{
			return ( ToBoolean1( value, false ) );
		}

		public static Boolean ToBoolean1( this String value, Boolean defValue )
		{
			Boolean nReturn = defValue;

			try
			{
				nReturn = ( value[0] == '1' );
			}
			catch ( Exception )
			{
			}

			return ( nReturn );
		}

		#endregion

		#region NoSlash	

		public static string NoSlash( this String value )
		{
			if ( !string.IsNullOrEmpty( value ) && value.Contains( "/" ) )
				return value.Replace( "/", string.Empty );
			else
				return value;
		}

		#endregion

		#region IsNullOrEmpty

		public static Boolean IsNullOrEmpty( this String value )
		{
			Boolean bReturn = false;

			try
			{
				return string.IsNullOrEmpty( value ) || string.IsNullOrWhiteSpace( value );
			}
			catch ( Exception )
			{
			}

			return ( bReturn );
		}

		#endregion

		#region ToStringUpper

		public static String ToStringUpper( this string value )
		{
			string strReturn = string.Empty;

			if( value != null )
				strReturn = value.ToUpper();

			return ( strReturn );
		}

		#endregion

		#region ToStringLower

		public static String ToStringLower( this string value )
		{
			string strReturn = string.Empty;

			if( value != null )
				strReturn = value.ToLower();

			return ( strReturn );
		}

		#endregion

		#region ToNumeric

		public static string ToNumeric( this string value )
		{
			string strReturn = string.Empty;

			if( value != null )
			{
				for( int i=0; i<value.Length; i++ )
				{
					if( value[i] >= '0' && value[i] <= '9' )
						strReturn += value[i];
				}
			}

			//We have nothing to return
			if( strReturn.IsNullOrEmpty() )
				strReturn = "0";

			return ( strReturn );
		}

		#endregion

		#region ToUtf8Bytes	

		public static byte[] ToUtf8Bytes( this string value )
		{
			byte[] result = null;

			//Valid
			if( !value.IsNullOrEmpty() )
			{
				result = System.Text.UTF8Encoding.UTF8.GetBytes( value );
			}
			else
			{
				result = new byte[0];
			}

			return( result );
		}

		#endregion

		#region ToASCIIBytes	

		public static byte[] ToASCIIBytes( this string value )
		{
			byte[] result = null;

			//Valid
			if( !value.IsNullOrEmpty() )
			{
				result = System.Text.ASCIIEncoding.ASCII.GetBytes( value );
			}
			else
			{
				result = new byte[0];
			}

			return( result );
		}

		#endregion

		#region ToIPAddress	

		public static string ToIPAddressAsString( this string value )
		{
			return( ToIP4Address( value ).ToString() );
		}

		public static string ToIP4AddressAsString( this string value )
		{
			return( ToIP4Address( value ).ToString() );
		}

		public static System.Net.IPAddress ToIPAddress( this string value )
		{
			if(value.IsNullOrEmpty() || value.Contains( ":") )
				return System.Net.IPAddress.Loopback;
			else
				return( ToIP4Address( value ) );
		}

		public static System.Net.IPAddress ToIP4Address( this string value )
		{
			System.Net.IPAddress result = null;

			//Valid
			if( !value.IsNullOrEmpty() )
			{
				System.Net.IPAddress[] ips = System.Net.Dns.GetHostAddresses( value );

				result = ips.FirstOrDefault( c=> c.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork );
			}

			return( result );
		}

		#endregion

		#region InRange	

		public static bool InRange( this string value, params string[] range )
		{
			return range != null && range.Contains( value, StringComparer.CurrentCultureIgnoreCase );
		}

		#endregion

		#region ToTitle

		public static string ToTitle( this string value )
		{
			string result = string.Empty;

			if( value != null )
			{
				System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
				System.Globalization.TextInfo    textInfo    = cultureInfo.TextInfo;

				result = textInfo.ToTitleCase( value );
			}

			return ( result );
		}

		#endregion

	}

	#endregion

	#region Object Helper Extension Methods

	public static class ObjectHelper
	{

		#region Data Members

		//private static DateTime MIN_DATETIME = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
		private static DateTime MIN_DATETIME = DateTime.MinValue;
		private static string BASE362 = "0123456789abcdefghijklmnopqrstuvwxyz";
		private static char[] BASE361 = BASE362.ToCharArray();

		#region Hex Table

		/// <summary>Hex string lookup table. (VERY FAST and faster than X2 formatting)</summary>
		private static readonly string[] HexStringTable = new string[]
		{
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0A", "0B", "0C", "0D", "0E", "0F",
    "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1A", "1B", "1C", "1D", "1E", "1F",
    "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2A", "2B", "2C", "2D", "2E", "2F",
    "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "3A", "3B", "3C", "3D", "3E", "3F",
    "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "4A", "4B", "4C", "4D", "4E", "4F",
    "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "5A", "5B", "5C", "5D", "5E", "5F",
    "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "6A", "6B", "6C", "6D", "6E", "6F",
    "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "7A", "7B", "7C", "7D", "7E", "7F",
    "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8A", "8B", "8C", "8D", "8E", "8F",
    "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9A", "9B", "9C", "9D", "9E", "9F",
    "A0", "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "AA", "AB", "AC", "AD", "AE", "AF",
    "B0", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "BA", "BB", "BC", "BD", "BE", "BF",
    "C0", "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "CA", "CB", "CC", "CD", "CE", "CF",
    "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "DA", "DB", "DC", "DD", "DE", "DF",
    "E0", "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9", "EA", "EB", "EC", "ED", "EE", "EF",
    "F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "FA", "FB", "FC", "FD", "FE", "FF"
		};

		#endregion

		#endregion

		#region IsNull								|

		public static bool IsNull( this object value )
		{
			return value == null;
		}

		#endregion

		#region ToJSON								|

		public static string ToJson( this object value )
		{
		  return Serializer.Serialize( value );
		}

		#endregion

		#region ToStream								|

		public static System.IO.Stream ToOutStream( this object value )
		{
			System.IO.Stream result = null;

			if ( value.GetType().IsPrimitive )
			{
				result = new System.IO.MemoryStream( System.Text.Encoding.UTF8.GetBytes( value.ToString() ?? string.Empty ) );
				result.Position = 0;
			}
			else
				result = new System.IO.MemoryStream();

			return result;
		}

		#endregion

		#region ToByte										|

		public static Byte ToByte( this Object value )
		{
			return ( ToByte( value, 0 ) );
		}

		public static Byte ToByte( this Object value, Byte defValue )
		{
			Byte nReturn = defValue;

			try
			{
				nReturn = Convert.ToByte( value );
			}
			catch { }

			return ( nReturn );
		}

		#endregion

		#region ToInt16										|

		public static Int16 ToInt16( this Object value )
		{
			return ( ToInt16( value, 0 ) );
		}

		public static Int16 ToInt16( this Object value, Int16 defValue )
		{
			Int16 nReturn = defValue;

			try
			{
				if ( value is Boolean )
				{
					nReturn = ( (bool)value ) ? (short)1 : (short)0;
				}
				else if( value is String )
				{
					if ( !String.IsNullOrEmpty( value as String ) )
					{
						if ( !Int16.TryParse( value.ToString(), out nReturn ) )
							nReturn = defValue;
					}
				}
				else
				{
						if ( !Int16.TryParse( value.ToString(), out nReturn ) )
							nReturn = defValue;
				}
			}
			catch { }

			return ( nReturn );
		}

		#endregion

		#region ToInt32										|

		public static Int32 ToInt32( this Object value )
		{
			return ( ToInt32( value, 0 ) );
		}

		public static Int32 ToInt32( this Object value, Int32 defValue )
		{
			Int32 nReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				if( value is Enum )
				{
					nReturn = Convert.ToInt32( value );
				}
				else if ( value is Boolean )
				{
					nReturn = ( (bool)value ) ? 1 : 0;
				}
				else if( value is String )
				{
					if ( !String.IsNullOrEmpty( value as String ) )
					{
						if ( !Int32.TryParse( value.ToString(), out nReturn ) )
							nReturn = defValue;
					}
				}
				else
				{
					if ( !Int32.TryParse( value.ToString(), out nReturn ) )
						nReturn = defValue;
				}
			}
			catch ( Exception )
			{
			}

			return ( nReturn );
		}

		#endregion

		#region ToInt64										|

		public static Int64 ToInt64( this Object value )
		{
			return ( ToInt64( value, (Int64)0 ) );
		}

		public static Int64 ToInt64( this Object value, Int64 defValue )
		{
			Int64 nReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				if( value is Enum )
				{
					nReturn = Convert.ToInt64( value );
				}
				else if ( value is Boolean )
				{
					nReturn = ( (bool)value ) ? 1 : 0;
				}
				else if( value is String )
				{
					if ( !String.IsNullOrEmpty( value as String ) )
					{
						if ( !Int64.TryParse( value.ToString(), out nReturn ) )
							nReturn = defValue;
					}
				}
				else
				{
					if ( !Int64.TryParse( value.ToString(), out nReturn ) )
						nReturn = defValue;
				}
			}
			catch ( Exception )
			{
			}

			return ( nReturn );
		}

		#endregion

		#region ToDecimal										|

		public static Decimal ToDecimal( this Object value )
		{
			return ( ToDecimal( value, 0 ) );
		}

		public static Decimal ToDecimal( this Object value, Decimal defValue )
		{
			Decimal nReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				if( value is String )
				{
					if ( !String.IsNullOrEmpty( value as String ) )
					{
						if ( !decimal.TryParse( value.ToString(), out nReturn ) )
							nReturn = defValue;
					}
				}
				else
				{
					if ( !decimal.TryParse( value.ToString(), out nReturn ) )
						nReturn = defValue;
				}
			}
			catch ( Exception )
			{
			}

			return ( nReturn );
		}

		#endregion

		#region ToDouble										|

		public static Double ToDouble( this Object value )
		{
			return ( ToDouble( value, 0 ) );
		}

		public static Double ToDouble( this Object value, Double defValue )
		{
			Double nReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				if( value is String )
				{
					if ( !String.IsNullOrEmpty( value as String ) )
					{
						if ( !double.TryParse( value.ToString(), out nReturn ) )
							nReturn = defValue;
					}
				}
				else
				{
					if ( !double.TryParse( value.ToString(), out nReturn ) )
						nReturn = defValue;
				}
			}
			catch ( Exception )
			{
			}

			return ( nReturn );
		}

		#endregion

		#region ToBoolean										|

		public static bool ToBoolean( this object value )
		{
			return ( ToBoolean( value, false ) );
		}

		public static bool ToBoolean( this object value, bool defValue )
		{
			bool result = defValue;

			if ( value == null )
				return defValue;

			if( value is bool )
				return( (bool)value );

			try
			{
				if( value != null )
				{
					if( !bool.TryParse( value.ToString(), out result ))
						result = defValue;
				}
			}
			catch { }

			return ( result );
		}

		#endregion

		#region ToTime										|

		public static System.DateTime ToTimeFromHHMMSS( this object value )
		{
			return( ToTimeExact( value, "hhmmss", MIN_DATETIME ) );
		}

		public static System.DateTime ToTimeExact( this object value, string format, DateTime defValue )
		{
			DateTime nReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				if( value != null )
					nReturn = DateTime.ParseExact( value.ToStringValue(), format, System.Globalization.CultureInfo.InvariantCulture );
			}
			catch
			{
				nReturn = defValue;
			}

			return ( nReturn );
		}

		#endregion

		#region ToDate										|

		public static System.DateTime ToDateFromYYYYMMDD( this object value )
		{
			return( ToDateExact( value, "yyyyMMdd", MIN_DATETIME ) );
		}

		public static System.DateTime ToDateExact( this object value, string format, DateTime defValue )
		{
			DateTime nReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				if( value != null )
					nReturn = DateTime.ParseExact( value.ToStringValue(), format, System.Globalization.CultureInfo.InvariantCulture );
			}
			catch
			{
				nReturn = defValue;
			}

			return ( nReturn );
		}

		#endregion

		#region ToDateTime										|

		public static DateTime? ToLocalDateTime( this Object _oDate )
		{
			DateTime? dt = ToDateTime( _oDate, MIN_DATETIME );
			if ( dt.HasValue )
				return dt.Value.ToLocalTime();
			else
				return null;
		}

		public static DateTime? ToDateTime( this Object _oDate )
		{
			return ToDateTime( _oDate, null );
		}

		public static DateTime? ToDateTime( this Object value, DateTime? defValue )
		{
			DateTime? nReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				if( value != null )
				{
					DateTime dt;
					if ( value is int )
					{
						nReturn = ( (uint)value ).ToDateTime();
					}
					else
					{
						if ( DateTime.TryParse( value.ToStringValue(), out dt ) )
							nReturn = dt;
					}
				}
			}
			catch ( Exception )
			{
			}

			if(nReturn != null )
				if ( nReturn.Value.Kind != DateTimeKind.Utc )
					nReturn = DateTime.SpecifyKind( nReturn.Value, DateTimeKind.Utc );

			return nReturn;
		}

		#endregion

		#region ToChar										|

		public static Char ToChar( this Object value )
		{
			return ( ToChar( value, (Char)0 ) );
		}

		public static Char ToChar( this Object value, Char defValue )
		{
			Char chReturn = defValue;

			if ( value == null )
				return defValue;

			try
			{
				chReturn = Convert.ToChar( value );
			}
			catch ( Exception )
			{
			}

			return ( chReturn );
		}

		#endregion

		#region ToString										|

		public static String ToStringValue( this Object value )
		{
			String strReturn = String.Empty;

			if( value != null )
				strReturn = value.ToString();

			return ( strReturn );
		}

		public static String ToStringTrim( this Object value )
		{
			String strReturn = String.Empty;

			if( value != null )
				strReturn = value.ToString().Trim();

			return ( strReturn );
		}

		#endregion

		#region GUID										|

		public static Guid ToGUID( this Object value )
		{
			Guid strReturn = Guid.Empty;

			if ( value == null )
				return strReturn;

			try
			{
				strReturn = new Guid( value.ToString() );
			}
			catch ( Exception )
			{
			}

			return ( strReturn );
		}

		public static String ToStrippedGUIDString( this Object value )
		{
			String strReturn = String.Empty;

			if ( value == null )
				return strReturn;

			try
			{
				strReturn = value.ToString().Replace( "-", string.Empty ).ToUpper();
			}
			catch ( Exception )
			{
			}

			return ( strReturn );
		}

		#endregion

		#region Reverse										|

		public static string Reverse( string input )
		{
			Stack<char> resultStack = new Stack<char>();
			foreach( char c in input )
				resultStack.Push( c );

			StringBuilder sb = new StringBuilder();

			while( resultStack.Count > 0 )
				sb.Append( resultStack.Pop() );

			return ( sb.ToString() );
		}

		#endregion

		#region Base36										        |

		public static Int64 FromBase36( this String inputString )
		{
			inputString = Reverse( inputString.ToLower() );
			long result = 0;
			int pos = 0;

			foreach( char c in inputString )
			{
				result += BASE362.IndexOf( c ) * (long)Math.Pow( 36, pos );
				pos++;
			} //end of for

			return result;
		}

		public static String ToBase36( this Int64 inputNumber )
		{
			String sReturn = String.Empty;

			try
			{
				StringBuilder sb = new StringBuilder();
				while( inputNumber != 0 )
				{
					sb.Append( BASE361[inputNumber % 36] );
					inputNumber /= 36;
				}

				sReturn = Reverse( sb.ToString() );
			}
			catch ( Exception )
			{
			}

			return ( sReturn );
		}

		#endregion

		#region Hex											     |

		public static String ToHex( this String value )
		{
			return System.Text.Encoding.ASCII.GetBytes( value ).ToHex();
		}

		public static String ToHex( this byte[] value )
		{
			StringBuilder stringBuilder = new StringBuilder();

			try
			{
				if( value != null )
					foreach( byte z in value )
						stringBuilder.Append( HexStringTable[z] );
			}
			catch
			{
			}

			return stringBuilder.ToString();
		}

		public static byte[] FromHex( this String hexString )
		{
			byte[] data = null;

			try
			{
				if( hexString != null )
				{
					if( hexString.Length % 2 == 1 )
						hexString = '0' + hexString;

					// Up to you whether to pad the first or last byte    
					data = new byte[hexString.Length / 2];
					for( int i = 0; i < data.Length; i++ )
						data[i] = Convert.ToByte( hexString.Substring( i * 2, 2 ), 16 );
				}
			}
			catch
			{
				data = new byte[] { };
			}

			return data;
		}

		public static String FromHexBytes( this String hexString )
		{
			return System.Text.Encoding.ASCII.GetString( hexString.FromHex() );
		}

		#endregion

		#region ToObjectList										|

		public static List<T> ToObjectList<T>( this T o )
		{
			if( o == null )
			{
				return ( null );
			}
			else
			{
				List<T> list = new List<T>();

				list.Add( o );

				return ( list );
			}
		}

		public static List<T> ToObjectList<T>( this Array o )
		{
			if( o == null )
			{
				return ( null );
			}
			else
			{
				List<T> list = new List<T>();

				for( int i=0; i<o.Length; i++ )
				{
					if( o.GetValue( i ) is T )
						list.Add( (T)o.GetValue( i ) );
				}

				return ( list );
			}
		}

		#endregion

	}

	#endregion
}
