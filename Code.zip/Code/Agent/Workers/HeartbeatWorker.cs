﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Management;
using System.Management.Instrumentation;

namespace JDA.ITG.Flow.Agent.Workers
{
	/// <summary>
	/// Background thread that triggers Config to send Heartbeats for all loaded agents
	/// </summary>
	/// <remarks>
	/// This class implements WorkerBase, which implements IServiceObject. The HostManager.cs loads all classes that derive from IServiceObject
	/// at startup and, via a background thread, loading up each class in its own thread. All classes derived from WorkerBase respect a global QuitEvent,
	/// ensuring clean shutdown
	/// </remarks>
	internal class HeartbeatWorker : WorkerBase
	{
		protected override bool ServerMustBeUp { get { return true; } }
		protected override int Interval { get { return 1000; } }

		protected override AgentStatus[] ExecutableStatus
		{
			get
			{
				//heartbeat runs on all status
				return new AgentStatus[]{ 
					AgentStatus.None, 
					AgentStatus.Paused, 
					AgentStatus.Ready, 
					AgentStatus.Shutdown, 
					AgentStatus.Startup, 
				};
			}
		}

		#region Cycle

		protected override void Cycle()
		{
			Config.Reload();
		}

		#endregion

	}
}
