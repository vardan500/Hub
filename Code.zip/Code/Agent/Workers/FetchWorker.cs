﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Management;
using System.Management.Instrumentation;

namespace JDA.ITG.Flow.Agent.Workers
{
	/// <summary>
	/// Background thread that cycles every few milliseconds, runs through the schedules for all loaded Agents, and 
	/// invokes them via the AgentManager.
	/// </summary>
	/// <remarks>
	/// This class implements WorkerBase, which implements IServiceObject. The HostManager.cs loads all classes that derive from IServiceObject
	/// at startup and, via a background thread, loading up each class in its own thread. All classes derived from WorkerBase respect a global QuitEvent,
	/// ensuring clean shutdown
	/// </remarks>
	internal class FetchWorker : WorkerBase
	{
		#region private variables

		readonly List<TimeSpan> _intervals = new List<TimeSpan>();
		static readonly ConcurrentDictionary<long, DateTime> _lastCycle = new ConcurrentDictionary<long, DateTime>();
		static readonly ConcurrentDictionary<long, bool> _immediateRerun = new ConcurrentDictionary<long, bool>();

		#endregion

		#region Properties

		protected override bool ServerMustBeUp { get { return true; } }
		/// <summary>Yes, 2 milliseconds</summary>
		protected override int Interval { get { return 2; } }
		protected override AgentStatus[] ExecutableStatus { get { return new AgentStatus[] { AgentStatus.Ready }; } }

		#endregion

		#region Cycle

		protected override void Cycle()
		{
			if ( Config.ServerUp )
			{
				foreach ( var item in Config.GetAgents() )
				{
					bool immediate = false;
					if ( Config.GetAgentStatus( item.Key ) != AgentStatus.Ready )
					{
						Log.Debug( item.Key, "Agent " + item.Key.ToString() + " is not ready" );
					}
					else if ( _immediateRerun.TryGetValue( item.Key, out immediate ) && immediate )
					{
						Run( item.Key );
					}
					else if ( HitSchedule( item.Key ) )
					{
						Run( item.Key );
					}
				}
			}
		}

		/// <summary>
		/// Check to see if it's time to run this Agent again
		/// </summary>
		/// <param name="agentId"></param>
		/// <returns></returns>
		private bool HitSchedule( long agentId )
		{
			bool result = false;

			AgentConfig config = Config.GetAgent( agentId );

			if ( config == null )
			{
				Log.Error( agentId, string.Format( "AgentConfig is missing for AgentId: {0}, HitSchedule Aborting", agentId ) );
				return result;
			}
			else if ( Config.GetAgentStatus( agentId ) != AgentStatus.Ready )
				return result;

			//update the cycle timer. Do it BEFORE the Run() occurs, because Run() can override
			//it and set it to zero or a longer value depending on the outcome...
			if ( config.Schedule.Mode == AgentIntervalMode.DailyAtSpecificTimes )
			{
				if ( config.Schedule.Intervals != null && config.Schedule.Intervals.Count > 0 )
				{

					//walk through the list of intervals. See if it matches the current interval. 
					//if so, check to see if the interval has already run in memory.
					//if the interval we're running is the last item in the list, then purge it once we get past it

					for ( int i = 0; i < config.Schedule.Intervals.Count; i++ )
					{
						TimeSpan current = config.Schedule.Intervals[i];
						TimeSpan now = DateTime.Now.TimeOfDay;
						//dump seconds + milliseconds
						current = new TimeSpan( current.Hours, current.Minutes, 0 );
						now = new TimeSpan( now.Hours, now.Minutes, 0 );

						if ( current > now )
						{
							//if the current one is in the future, abort
							break;
						}
						else if ( current < now )
						{
							//if this is in the past, then see if we're on the last one. if so, clear out the working list
							if ( i == config.Schedule.Intervals.Count - 1 )
							{
								//we've past the last interval. clear out the list for the next time around
								_intervals.Clear();
							}
						}
						else if ( current == now )
						{
							//it's NOW. See if we already hit on this one or not...
							if ( _intervals.Exists( c => c == now ) )
							{
								//skip it
								continue;
							}
							else
							{
								if ( DayOfWeekOk( config.Schedule ) )
								{
									_intervals.Add( now );
									result = true;
								}
							}
						}
					}
				}
			}
			else if ( config.Schedule.Mode == AgentIntervalMode.CycleEveryNSeconds && config.Schedule.CycleEveryNSeconds > 0 )
			{
				DateTime lastRun;
				if ( _lastCycle.TryGetValue( agentId, out lastRun ) == false )
					lastRun = DateTime.UtcNow.AddDays( -2 );

				if ( Convert.ToInt64( DateTime.UtcNow.Subtract( lastRun ).TotalSeconds ) >= config.Schedule.CycleEveryNSeconds )
				{
					_lastCycle.AddOrUpdate( agentId, DateTime.UtcNow, ( k, v ) => DateTime.UtcNow );
					result = true;
				}

			}

			return result;
		}

		#endregion 

		#region Run

		private void Run( long agentId )
		{
			bool immediatelyContinue = false;

			if ( Config.GetAgentStatus( agentId ) != AgentStatus.Ready )
			{
				immediatelyContinue = false;
				//Log.Debug( () => "GetWorkCommand is disabled by config value 'Command.GetWork.Enabled' != true. Change the config value in sql to true to enable getting work" );
			}
			else
			{
				if ( AgentManager.IsPublisher(agentId) )
				{
					AgentManager.GiveWorkToAgent( agentId );
				}

				if ( AgentManager.IsSubscriber( agentId ) )
				{
					AgentWork workToDo = new AgentWork();
					WorkGetResponse rs;
					var result = Intercomm.TryGetWork( agentId, out rs );
					if ( result.Result == IntercommResult.Success )
					{
						if(rs != null && rs.Work != null && rs.Work.Count > 0)
							workToDo.AddRange( rs.Work.Select( c => new AgentWorkItem() { ObjectName = c.ObjectName, ObjectKey = c.ObjectKey, Document = c.Document, Error = string.Empty, Successful = false } ) );

						AgentManager.GiveWorkToAgent( agentId, workToDo );
						immediatelyContinue = ( workToDo.Count > 0 );
					}
				}
			}

			if ( immediatelyContinue )
				_immediateRerun.AddOrUpdate( agentId, immediatelyContinue, ( k, v ) => immediatelyContinue );
			else
				_immediateRerun.TryRemove( agentId, out immediatelyContinue );
		}

		#endregion


		private bool DayOfWeekOk( AgentSchedule schedule )
		{
			if ( string.IsNullOrEmpty( schedule.DaysOfWeek ) )
				return true;

			string dow = ( (int)DateTime.Today.DayOfWeek ).ToString();

			return schedule.DaysOfWeek.Contains( dow ) == true;
		}

	}
}
