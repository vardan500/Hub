﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Management;
using System.Management.Instrumentation;

namespace JDA.ITG.Flow.Agent.Workers
{
	/// <summary>
	/// Base class that encapsulates basic thread operations for all implementing classes. Derizes from IServiceObject, which is
	/// supported and operated by  /Shared/HostManager.cs
	/// </summary>
	internal abstract class WorkerBase : IServiceObject
	{
		#region Data Members

		private Thread _processorThread = null;
		private string _workerName = null;

		#endregion

		#region Properties

		public string WorkerName
		{
			get
			{
				if ( string.IsNullOrEmpty( _workerName ) )
					_workerName = this.GetType().Name;

				return _workerName;
			}
		}

		#endregion

		#region abstracts

		/// <summary>
		/// Indicates the worker only tries to process agents whose status is in this list (e.g. Heartbeats can run for anyone, but Fetch work cannot)
		/// </summary>
		protected abstract AgentStatus[] ExecutableStatus { get; }

		/// <summary>
		/// The frequency (in milliseconds) at which the background thread cycles. If the interval varies for agents, 
		/// set this value low and do a secondary time check based on each agent (like the Fetch Worker's HitSchedule() method
		/// </summary>
		protected abstract int Interval { get; }

		/// <summary>
		/// Indicates the worker will not execute any operation if the server isn't up. The only class that should have this set to false is the Heartbeat
		/// (and possibly logging)
		/// </summary>
		protected abstract bool ServerMustBeUp { get; }

		/// <summary>
		/// This class is the worker's implementation logic. WorkerBase will invoke it when Interval hits, the status is valid
		/// </summary>
		/// <returns>true if Immediately re-run</returns>
		protected abstract void Cycle();

		#endregion

		#region Start/Shutdown

		public void Start()
		{
			Log.Info( 0, WorkerName + " starting" );

			//first, make sure we're clean
			Shutdown();

			//Startup the main process
			_processorThread = new Thread( new ThreadStart( Process ) );
			_processorThread.Start();
		}

		public void Shutdown()
		{
			Log.Info( 0, WorkerName + " stopping" );

			//We have a thread
			if ( _processorThread != null )
			{
				//setting quit event
				QuitEvent.Set();
			}

			//wait for the quit event to complete
			if ( _processorThread != null )
			{
				//Wait for thread
				_processorThread.Join( 20 * 1000 );
			}
		}

		#endregion

		#region Main Processing

		private void Process()
		{
			try
			{
				WaitHandle[] handles = { QuitEvent.Get() };
				bool bContinue = true;

				Log.Info( 0, WorkerName + " thread started" );

				do
				{
					//fire every Interval or if the global QuitEvent has fired
					switch ( WaitHandle.WaitAny( handles, this.Interval, false ) )
					{
						case 0:
							bContinue = false;
							break;

						default:

							try
							{
								Cycle();
							}
							catch( Exception ex )
							{
								//trap any unhandled errors thrown by the implemented Cycle() method. 
								//We should really abort here and log something
								bContinue = false;
								Log.Error( 0, string.Format( "Worker: {0} through an unhandled exception in its Cycle() call. Aborting Thread ASAP. Error: {1}, Stack: {2}", this.GetType().Name, ex.Message, ex.StackTrace ?? string.Empty ) );
							}

							break;

					} //end of switch

				} while ( bContinue );
			}
			catch ( ThreadAbortException )
			{
				//this is ok 
			}
			catch ( Exception e )
			{
				Log.Exception( 0, e, "Process Failed", this.GetType().Name + ".Process" );
			}

			Log.Info( 0, WorkerName + " thread stopped" );
		}

		#endregion

	}
}
