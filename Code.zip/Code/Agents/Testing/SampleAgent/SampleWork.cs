﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow;
using JDA.ITG.Flow.Agent;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SampleAgent
{
	class SampleWork : PubSubBase
	{
		public override long AgentId { get { return 1073741824; } }
		public override string AgentName { get { return "Sample Agent"; } }

		public override void Publish()
		{
			//generate a new work record
			AgentWork work = new AgentWork();
			work.Add(
					new AgentWorkItem()
					{
						Document = new JObject( 
							new JProperty( "Name", "Jonathan Tester" ), 
							new JProperty( "DOB", new DateTime( 1954, 3, 21 ) ) ).ToString(),
						ObjectKey = "E1830801380",
						ObjectName = "Associate",
					});

			this.Send( work );
		}

		public override void Subscribe( AgentWork work )
		{
			foreach ( var item in work )
				item.Successful = true;

			Send( work );
		}

		/// <summary>
		/// Use this in a web page or other application to force-inject data into the system 
		/// </summary>
		/// <param name="associates"></param>
		public void SendingYouDataFromAWebPage( List<CustomAssociateThingy> associates )
		{
			//we want to send 
			AgentWork work = new AgentWork();
			work.AddRange( associates.Select( c => new AgentWorkItem() { Document = Serializer.Serialize( c ), ObjectKey = c.Id, ObjectName = "AssociateThingy" } ) );
			//send the incoming data to the hub in blocks of 50
			Send( work, 50 );
		}


	}

	/// <summary>
	/// Just a sample object
	/// </summary>
	public class CustomAssociateThingy
	{
		public string Id { get; set; }
		public string Name { get; set; }
	}
}
