﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JDA.ITG.Flow;

namespace SampleAgent
{
	class Program
	{
		static void Main( string[] args )
		{
			//This is the  agent that will do the work in this exe
			AgentManager.Intialize( args, typeof( SampleWork ) );
		}
	}
}
