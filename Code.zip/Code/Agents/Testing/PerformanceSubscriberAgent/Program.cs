﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow;
using Newtonsoft.Json.Linq;

namespace PerformanceSubscriberAgent
{
	class Program
	{
		static void Main( string[] args )
		{
			AgentManager.Intialize( args, typeof( TestAgent ) );
		}
	}

	class TestAgent : SubscriberBase
	{
		public override long AgentId { get { return 256; } }
		public override string AgentName { get { return "PerformanceSubscriber"; } }

		public override void Subscribe( AgentWork work )
		{
			for ( int i = 0; i < work.Count; i++ )
			{
				if ( work[i].ObjectName == "Associate" )
				{
					JObject lastTenrox = this.AgentDataGetAsJObject( work[i].ObjectKey );
					//ok, do a get from tenrox for this employee
					//compare the two
					//if they are the same, we can update tenrox
					//this.SetAgentData( work[i].ObjectKey, lastTenrox.ToString() );
				}


				//I did something with that data...
				//work[i].Successful = true;
				work[i].Error = "there was a baaad problem: ";

				this.LogConsole( "Processing Item #{0}, key = {1}", i, work[i].ObjectKey );
			}

			Send( work );
		}

	}	
}
