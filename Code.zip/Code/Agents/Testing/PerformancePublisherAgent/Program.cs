﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow;
using Newtonsoft.Json.Linq;

namespace PerformancePublisherAgent
{
	class Program
	{
		static void Main( string[] args )
		{
	

			AgentManager.Intialize( args, typeof( TestAgent ) );
		}
	}

	class TestAgent : PublisherBase
	{
		public static string Json = string.Empty;

		public override long AgentId { get { return 128; } }
		public override string AgentName { get { return "PerformancePublisher"; } }

		public override void Publish()
		{
			if ( string.IsNullOrEmpty( Json ) )
			{
				using ( System.IO.StreamReader reader = new System.IO.StreamReader( System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream( "PerformancePublisherAgent.json.txt" ) ) )
				{
					Json = reader.ReadToEnd();
				}
			}


			int numRecordsToGenerate = this.AppSettingGetAsInt( "Items", 100 );

			int batches = this.NumberOfBatches( numRecordsToGenerate, 100 );

			AgentWork work = new AgentWork();
			for ( int b = 0; b < batches; b++ )
			{
				for ( int i = 0; i < numRecordsToGenerate; i++ )
				{
					string key = DateTime.UtcNow.ToString( "yyyyMMdd_HHmmss_" ) + i.ToString();
					work.Add( new AgentWorkItem() { Document = Json, ObjectKey = key, ObjectName = "PerfTest" } );
					Send( work );
					work.Clear();
					this.LogConsole( "Processing Item #{0}, key = {1}", i, key );
				}
			}
		}
	}
}
