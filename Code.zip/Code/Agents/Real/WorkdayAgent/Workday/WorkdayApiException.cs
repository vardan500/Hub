﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JDA.ITG.DataAbstraction.Workday
{
    class WorkdayApiException : ApplicationException
    {
        public WorkdayApiException()
            : base()
        {
            //LogManager.Log("WorkdayApiException: (no Message)");
        }

        public WorkdayApiException(string Message, Exception InnerException)
            : base(Message, InnerException)
        {
            //LogManager.Log("WorkdayApiException: " + Message);
        }

        public WorkdayApiException(string Message)
            : base(Message)
        {
            //LogManager.Log("WorkdayApiException: " + Message);
        }

    }
}
