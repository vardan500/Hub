﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow;
using JDA.ITG.Flow.Agent;
using JDA.ITG.Flow.Agent.Shared;
using JDA.ITG.DataAbstraction.Workday;
using JDA.ITG.DataAbstraction.Workday.WorkdayHumanResources;

namespace WorkdayAgent.Workday
{
	static class Processor
	{
		public static bool TryGetWork( WorkdayFetchAgent agent, DateTime from, DateTime to, out Dictionary<string,DateTime> workerIdsAndDates )
		{
			workerIdsAndDates = new Dictionary<string, DateTime>();

			return workerIdsAndDates.Count > 0;
		}

		public static bool TryGetAssociatesFromRAAS( WorkdayFetchAgent agent, Dictionary<string, DateTime> workersAndDates, out List<Associate> results )
		{
			results = new List<Associate>();

			return results.Count > 0;
		}

		public static bool TryGetWork_Old( WorkdayFetchAgent agent, DateTime from, DateTime to, out List<Associate> results )
		{
			results = null;

			string username = agent.AppSettingGet( "WDAPIUserName" );
			string password = agent.AppSettingGet( "WDAPIPassword" );
			string endpoint = agent.AppSettingGet( "WDEndpointHumanResources" );
      string version  = agent.AppSettingGet( "WDRequestVersion");

			WorkerType[] workers = null;

			// Create the client
			using ( Human_ResourcesPortClient client = new Human_ResourcesPortClient( "Human_Resources" ) )
			{
				// Set the WS-Security Credentials
				//client.ClientCredentials.UserName.UserName = username;
				//client.ClientCredentials.UserName.Password = password;

				// Set the Endpoint URI
				client.Endpoint.Address = new System.ServiceModel.EndpointAddress( endpoint );
				try
				{
					client.Open();

					if ( client.State == System.ServiceModel.CommunicationState.Opened )
					{
						workers = WorkerData.GetWorkersModified( agent, client, from, to );
					}
				}
				catch ( Exception ex )
				{
					agent.LogException( ex, "Error retrieving Worker delta from WorkDay", "Processor.Run" );
				}
				finally
				{
					client.Close();
				}
			}

			if ( workers != null )
			{
				results = new List<Associate>();
				foreach ( var item in workers )
				{
					if ( item.Worker_Data != null )
					{
						Associate associate;
						if ( WorkerData.TryGetAssociateFromWorkday( agent, item.Worker_Data, out associate ) )
							results.Add( associate );
					}
					else
					{
						agent.LogError( "Received a Worker with a null Worker_Data. Research immediately" );
					}
				}
			}

			return results != null && results.Count > 0;
		}
	}
}
