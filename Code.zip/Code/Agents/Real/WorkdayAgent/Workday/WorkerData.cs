﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.DataAbstraction.Workday.WorkdayHumanResources;
using JDA.ITG.Flow;
using JDA.ITG.Flow.Agent;
using JDA.ITG.Flow.Agent.Shared;

namespace JDA.ITG.DataAbstraction.Workday
{
	public enum WorkerSearchEnum
	{
		//UpdatedOnly,
		UpdatedAndEffective,
		UpdatedAndEffectiveFuture,
		UpdatedAndEffectiveOrEffectiveToday,
		UpdatedAndEffectiveFutureOrEffectiveToday
	}

	public class WorkerData
	{
		#region declarations

		const string NullBindingError = "NULL binding exception.  Use WDServiceHelper.GetClient() to populate binding.";

		#endregion


		#region Retrieval Methods

		private static Worker_Response_GroupType GetFullWorkerResponseGroup()
		{
			Worker_Response_GroupType workerResponseGroup = new Worker_Response_GroupType();

			workerResponseGroup.Include_Account_ProvisioningSpecified = true;
			workerResponseGroup.Include_Account_Provisioning = true;
			workerResponseGroup.Include_Background_Check_DataSpecified = true;
			workerResponseGroup.Include_Background_Check_Data = true;
			workerResponseGroup.Include_Benefit_EligibilitySpecified = true;
			workerResponseGroup.Include_Benefit_Eligibility = true;
			workerResponseGroup.Include_Benefit_EnrollmentsSpecified = true;
			workerResponseGroup.Include_Benefit_Enrollments = true;
			workerResponseGroup.Include_CareerSpecified = true;
			workerResponseGroup.Include_Career = true;
			workerResponseGroup.Include_CompensationSpecified = true;
			workerResponseGroup.Include_Compensation = true;
			workerResponseGroup.Include_Development_ItemsSpecified = true;
			workerResponseGroup.Include_Development_Items = true;
			workerResponseGroup.Include_Employee_Contract_DataSpecified = true;
			workerResponseGroup.Include_Employee_Contract_Data = true;
			workerResponseGroup.Include_Employee_ReviewSpecified = true;
			workerResponseGroup.Include_Employee_Review = true;
			workerResponseGroup.Include_Employment_InformationSpecified = true;
			workerResponseGroup.Include_Employment_Information = true;
			workerResponseGroup.Include_Feedback_ReceivedSpecified = true;
			workerResponseGroup.Include_Feedback_Received = true;
			workerResponseGroup.Include_GoalsSpecified = true;
			workerResponseGroup.Include_Goals = true;
			workerResponseGroup.Include_Management_Chain_DataSpecified = true;
			workerResponseGroup.Include_Management_Chain_Data = true;
			workerResponseGroup.Include_OrganizationsSpecified = true;
			workerResponseGroup.Include_Organizations = true;
			workerResponseGroup.Include_Personal_InformationSpecified = true;
			workerResponseGroup.Include_Personal_Information = true;
			workerResponseGroup.Include_PhotoSpecified = true;
			workerResponseGroup.Include_Photo = true;
			workerResponseGroup.Include_QualificationsSpecified = true;
			workerResponseGroup.Include_Qualifications = true;
			workerResponseGroup.Include_ReferenceSpecified = true;
			workerResponseGroup.Include_Reference = true;
			workerResponseGroup.Include_Related_PersonsSpecified = true;
			workerResponseGroup.Include_Related_Persons = true;
			workerResponseGroup.Include_RolesSpecified = true;
			workerResponseGroup.Include_Roles = true;
			workerResponseGroup.Include_Succession_ProfileSpecified = true;
			workerResponseGroup.Include_Succession_Profile = true;
			workerResponseGroup.Include_Talent_AssessmentSpecified = true;
			workerResponseGroup.Include_Talent_Assessment = true;
			workerResponseGroup.Include_Transaction_Log_DataSpecified = true;
			workerResponseGroup.Include_Transaction_Log_Data = true;
			workerResponseGroup.Include_User_AccountSpecified = true;
			workerResponseGroup.Include_User_Account = true;
			workerResponseGroup.Include_Worker_DocumentsSpecified = true;
			workerResponseGroup.Include_Worker_Documents = true;

			return workerResponseGroup;
		}

		private static Worker_Response_GroupType GetWorkerResponseGroup()
		{
			Worker_Response_GroupType workerResponseGroup = new Worker_Response_GroupType();

			workerResponseGroup.Include_Reference = true;
			workerResponseGroup.Include_ReferenceSpecified = true;
			workerResponseGroup.Include_Personal_Information = true;
			workerResponseGroup.Include_Personal_InformationSpecified = true;
			workerResponseGroup.Include_Employment_InformationSpecified = true;
			workerResponseGroup.Include_Employment_Information = true;
			workerResponseGroup.Include_Employment_InformationSpecified = true;
			workerResponseGroup.Include_Management_Chain_Data = true;
			workerResponseGroup.Include_Management_Chain_DataSpecified = true;
			workerResponseGroup.Include_Organizations = true;
			workerResponseGroup.Include_OrganizationsSpecified = true;
			workerResponseGroup.Include_Transaction_Log_Data = true;
			workerResponseGroup.Include_Transaction_Log_DataSpecified = true;

			return workerResponseGroup;
		}

		private static Worker_Response_GroupType GetBasicWorkerResponseGroup()
		{
			Worker_Response_GroupType workerResponseGroup = new Worker_Response_GroupType();

			workerResponseGroup.Include_Reference = true;
			workerResponseGroup.Include_ReferenceSpecified = true;
			workerResponseGroup.Include_Personal_Information = true;
			workerResponseGroup.Include_Personal_InformationSpecified = true;
			workerResponseGroup.Include_Organizations = true;
			workerResponseGroup.Include_OrganizationsSpecified = true;
			workerResponseGroup.Include_Transaction_Log_Data = true;
			workerResponseGroup.Include_Transaction_Log_DataSpecified = true;

			return workerResponseGroup;
		}

		internal static WorkerType[] GetWorkersModified( WorkdayAgent.WorkdayFetchAgent agent, Human_ResourcesPortClient client, DateTime startdt, DateTime enddt, WorkerSearchEnum searchtype = WorkerSearchEnum.UpdatedAndEffective )
		{

			//LogManager.Log("GetWorkers Entry");

			var list = new List<WorkerType>();

			if ( client == null )
			{
				throw new WorkdayApiException( "GetWorkers: " + NullBindingError );
			}

			// Define the paging defaults
			decimal countSize = 999;
			decimal totalPages = 1;
			decimal currentPage = 1;


			while ( totalPages >= currentPage )
			{
				// Create a "request" object
				Get_Workers_RequestType request = new Get_Workers_RequestType();

				// Set the WWS version desired
				request.version = agent.GetVersion();

				// Set the date/time & page parameters in the request
				request.Response_Filter = new Response_FilterType();
				request.Response_Filter.Page = currentPage;
				request.Response_Filter.PageSpecified = true;
				request.Response_Filter.Count = countSize;
				request.Response_Filter.CountSpecified = true;
				request.Response_Filter.As_Of_Effective_DateSpecified = false;   //MARKMG-19NOV12 per Omnipoint, these values filter the responses. We are filtering based upon the request.
				request.Response_Filter.As_Of_Entry_DateTimeSpecified = false;

				// Set the desired response group(s) to return
				request.Response_Group = new Worker_Response_GroupType();
				request.Response_Group.Include_Reference = true;
				request.Response_Group.Include_ReferenceSpecified = true;
				request.Response_Group.Include_Personal_Information = true;
				request.Response_Group.Include_Personal_InformationSpecified = true;
				request.Response_Group.Include_Employment_Information = true;
				request.Response_Group.Include_Employment_InformationSpecified = true;
				request.Response_Group.Include_Organizations = true;
				request.Response_Group.Include_OrganizationsSpecified = true;

				request.Response_Group.Include_Management_Chain_Data = true;
				request.Response_Group.Include_Management_Chain_DataSpecified = true;

				// Need to update the date filters to use UpdatedAndEffective
				Worker_Request_CriteriaType criteria = GetUpdateRange( startdt, enddt, searchtype );
				request.Request_Criteria = criteria;

				// Create a "response" object
				Get_Workers_ResponseType response = client.Get_Workers( request );

				list.AddRange( response.Response_Data );

				if ( totalPages == 1 )
				{
					totalPages = Math.Ceiling( response.Response_Results.Total_Pages / countSize );
				}
				currentPage++;

			}

			//LogManager.Log("GetProducts Complete");
			return list.ToArray();
		}

		internal static WorkerType GetWorkerModifiedById( WorkdayAgent.WorkdayFetchAgent agent, Human_ResourcesPortClient client, DateTime startdt, DateTime enddt, string EmployeeId, WorkerSearchEnum searchtype = WorkerSearchEnum.UpdatedAndEffectiveFuture )
		{

			//LogManager.Log("GetWorkers Entry");

			WorkerType workerType = new WorkerType();

			if ( client == null )
			{
				throw new WorkdayApiException( "GetWorkers: " + NullBindingError );
			}

			// Define the paging defaults
			decimal countSize = 1; ;
			decimal totalPages = 1;
			decimal currentPage = 1;


			while ( totalPages >= currentPage )
			{
				// Create a "request" object
				Get_Workers_RequestType request = new Get_Workers_RequestType();

				// Set the WWS version desired
				request.version = agent.GetVersion();

				// Set the date/time & page parameters in the request
				request.Response_Filter = new Response_FilterType();
				request.Response_Filter.Page = currentPage;
				request.Response_Filter.PageSpecified = true;
				request.Response_Filter.Count = countSize;
				request.Response_Filter.CountSpecified = true;
				request.Response_Filter.As_Of_Effective_DateSpecified = false;   //MARKMG-19NOV12 per Omnipoint, these values filter the responses. We are filtering based upon the request.
				request.Response_Filter.As_Of_Entry_DateTimeSpecified = false;

				// Set the desired response group(s) to return
				request.Response_Group = new Worker_Response_GroupType();
				request.Response_Group.Include_Reference = true;
				request.Response_Group.Include_ReferenceSpecified = true;
				request.Response_Group.Include_Personal_Information = true;
				request.Response_Group.Include_Personal_InformationSpecified = true;
				request.Response_Group.Include_Employment_Information = true;
				request.Response_Group.Include_Employment_InformationSpecified = true;

				request.Response_Group.Include_Organizations = true;
				request.Response_Group.Include_OrganizationsSpecified = true;

				request.Response_Group.Include_Management_Chain_Data = true;
				request.Response_Group.Include_Management_Chain_DataSpecified = true;
				request.Response_Group.Include_Transaction_Log_Data = true;
				request.Response_Group.Include_Transaction_Log_DataSpecified = true;


				WorkerObjectType w = new WorkerObjectType();
				w.Descriptor = "Employee_ID";
				w.ID = new WorkerObjectIDType[1];
				w.ID[0] = new WorkerObjectIDType();
				WorkerObjectIDType woidt = new WorkerObjectIDType();
				woidt.type = "Employee_ID";
				woidt.Value = EmployeeId;
				w.ID[0] = woidt;

				Worker_Request_ReferencesType refType = new Worker_Request_ReferencesType();
				refType.Worker_Reference = new WorkerObjectType[1];
				refType.Worker_Reference[0] = w;
				request.Request_References = refType;

				Worker_Request_CriteriaType criteria = GetUpdateRange( startdt, enddt, WorkerSearchEnum.UpdatedAndEffectiveFuture );
				request.Request_Criteria = criteria;

				// Create a "response" object
				Get_Workers_ResponseType response = client.Get_Workers( request );

				workerType = response.Response_Data[0];

				if ( totalPages == 1 )
				{
					totalPages = response.Response_Results.Total_Pages;
				}
				currentPage++;

			}

			//LogManager.Log("GetProducts Complete");
			return workerType;
		}

		internal static Get_Workers_RequestType GetWorkersModifiedRequest( WorkdayAgent.WorkdayFetchAgent agent, int countSize, DateTime startdt, DateTime enddt, WorkerSearchEnum searchtype = WorkerSearchEnum.UpdatedAndEffective )
		{
			int currentPage = 1;

			// Create a "request" object
			Get_Workers_RequestType request = new Get_Workers_RequestType();

			// Set the WWS version desired
			request.version = agent.GetVersion();

			// Set the date/time & page parameters in the request
			request.Response_Filter = new Response_FilterType();
			request.Response_Filter.Page = currentPage;
			request.Response_Filter.PageSpecified = true;
			request.Response_Filter.Count = countSize;
			request.Response_Filter.CountSpecified = true;
			request.Response_Filter.As_Of_Effective_DateSpecified = false;   //MARKMG-19NOV12 per Omnipoint, these values filter the responses. We are filtering based upon the request.
			request.Response_Filter.As_Of_Entry_DateTimeSpecified = false;

			// Set the desired response group(s) to return
			request.Response_Group = new Worker_Response_GroupType();
			request.Response_Group.Include_Reference = true;
			request.Response_Group.Include_ReferenceSpecified = true;
			request.Response_Group.Include_Personal_Information = true;
			request.Response_Group.Include_Personal_InformationSpecified = true;
			request.Response_Group.Include_Employment_Information = true;
			request.Response_Group.Include_Employment_InformationSpecified = true;
			request.Response_Group.Include_Management_Chain_Data = true;
			request.Response_Group.Include_Management_Chain_DataSpecified = true;
			request.Response_Group.Include_Organizations = true;
			request.Response_Group.Include_OrganizationsSpecified = true;


			Worker_Request_CriteriaType criteria = GetUpdateRange( startdt, enddt, WorkerSearchEnum.UpdatedAndEffective );
			request.Request_Criteria = criteria;

			return request;
		}

		public static Task<Get_WorkersOutput> GetWorkersModifiedNext( Human_ResourcesPortClient client, int currentPage, Get_Workers_RequestType request )
		{
			request.Response_Filter.Page = currentPage;

			// Create a "response" object
			var response = client.Get_WorkersAsync( request );
			return response;
		}

		public static Worker_Request_CriteriaType GetEffectiveRange( DateTime startdt, DateTime enddt )
		{

			Worker_Request_CriteriaType criteria = new Worker_Request_CriteriaType();
			criteria.Transaction_Log_Criteria_Data = new Transaction_Log_CriteriaType[1];
			Transaction_Log_CriteriaType tranLogCriteria = new Transaction_Log_CriteriaType();
			tranLogCriteria.Transaction_Date_Range_Data = new Effective_And_Updated_DateTime_DataType();
			tranLogCriteria.Transaction_Date_Range_Data.Effective_From = startdt;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_Through = enddt;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_ThroughSpecified = true;
			criteria.Transaction_Log_Criteria_Data[0] = tranLogCriteria;


			return criteria;
		}

		public static Worker_Request_CriteriaType GetUpdateRange( DateTime startdt, DateTime enddt )
		{

			Worker_Request_CriteriaType criteria = new Worker_Request_CriteriaType();
			criteria.Transaction_Log_Criteria_Data = new Transaction_Log_CriteriaType[1];
			Transaction_Log_CriteriaType tranLogCriteria = new Transaction_Log_CriteriaType();
			tranLogCriteria.Transaction_Date_Range_Data = new Effective_And_Updated_DateTime_DataType();
			tranLogCriteria.Transaction_Date_Range_Data.Updated_From = startdt;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_Through = enddt;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_ThroughSpecified = true;
			criteria.Transaction_Log_Criteria_Data[0] = tranLogCriteria;

			return criteria;
		}

		public static Worker_Request_CriteriaType GetUpdateRange( DateTime startdt, DateTime enddt, WorkerSearchEnum searchType )
		{
			Worker_Request_CriteriaType criteria = new Worker_Request_CriteriaType();

			criteria.Exclude_Contingent_Workers = false;
			criteria.Exclude_Employees = false;

			switch ( searchType )
			{
				case WorkerSearchEnum.UpdatedAndEffective:
					criteria.Transaction_Log_Criteria_Data = new Transaction_Log_CriteriaType[2];
					criteria.Transaction_Log_Criteria_Data[0] = GetUpdatedAndEffective( startdt, enddt );
					criteria.Transaction_Log_Criteria_Data[1] = GetEffective( startdt, enddt );
					break;
				case WorkerSearchEnum.UpdatedAndEffectiveFuture:
					criteria.Transaction_Log_Criteria_Data = new Transaction_Log_CriteriaType[1];
					criteria.Transaction_Log_Criteria_Data[0] = GetUpdatedAndEffectiveFuture( startdt, enddt );
					break;
				//case WorkerSearchEnum.UpdatedOnly:
				//    return  GetUpdateRange(startdt, enddt);
				case WorkerSearchEnum.UpdatedAndEffectiveOrEffectiveToday:
					criteria.Transaction_Log_Criteria_Data = new Transaction_Log_CriteriaType[2];
					criteria.Transaction_Log_Criteria_Data[0] = GetUpdatedAndEffective( startdt, enddt );
					criteria.Transaction_Log_Criteria_Data[1] = GetEffectiveToday( startdt, enddt );
					break;
				case WorkerSearchEnum.UpdatedAndEffectiveFutureOrEffectiveToday:
					criteria.Transaction_Log_Criteria_Data = new Transaction_Log_CriteriaType[2];
					criteria.Transaction_Log_Criteria_Data[0] = GetUpdatedAndEffectiveFuture( startdt, enddt );
					criteria.Transaction_Log_Criteria_Data[1] = GetEffectiveToday( startdt, enddt );
					break;
				default:
					throw new WorkdayApiException( "Invalid Date Range Criteria type" );

			}

			return criteria;
		}

		public static Transaction_Log_CriteriaType GetUpdatedAndEffective( DateTime startdt, DateTime enddt )
		{

			Transaction_Log_CriteriaType tranLogCriteria = new Transaction_Log_CriteriaType();
			tranLogCriteria.Transaction_Date_Range_Data = new Effective_And_Updated_DateTime_DataType();
			tranLogCriteria.Transaction_Date_Range_Data.Updated_From = startdt;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_Through = enddt;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_ThroughSpecified = true;

			tranLogCriteria.Transaction_Date_Range_Data.Effective_From = new DateTime( 1900, 1, 1 );
			tranLogCriteria.Transaction_Date_Range_Data.Effective_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_Through = enddt;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_ThroughSpecified = true;


			return tranLogCriteria;
		}

		public static Transaction_Log_CriteriaType GetUpdatedAndEffectiveFuture( DateTime startdt, DateTime enddt )
		{

			Transaction_Log_CriteriaType tranLogCriteria = new Transaction_Log_CriteriaType();
			tranLogCriteria.Transaction_Date_Range_Data = new Effective_And_Updated_DateTime_DataType();
			tranLogCriteria.Transaction_Date_Range_Data.Updated_From = startdt;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_Through = enddt;
			tranLogCriteria.Transaction_Date_Range_Data.Updated_ThroughSpecified = true;

			tranLogCriteria.Transaction_Date_Range_Data.Effective_From = new DateTime( 1900, 1, 1 );
			tranLogCriteria.Transaction_Date_Range_Data.Effective_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_Through = enddt.AddYears( 1 );
			tranLogCriteria.Transaction_Date_Range_Data.Effective_ThroughSpecified = true;

			return tranLogCriteria;
		}

		public static Transaction_Log_CriteriaType GetEffectiveToday( DateTime startdt, DateTime enddt )
		{


			Transaction_Log_CriteriaType tranLogCriteria = new Transaction_Log_CriteriaType();
			tranLogCriteria.Transaction_Date_Range_Data = new Effective_And_Updated_DateTime_DataType();

			tranLogCriteria.Transaction_Date_Range_Data.Effective_From = DateTime.Today;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_Through = DateTime.Today.AddHours( 23 ).AddMinutes( 59 ).AddSeconds( 59 ).AddMilliseconds( 999 );
			tranLogCriteria.Transaction_Date_Range_Data.Effective_ThroughSpecified = true;

			return tranLogCriteria;
		}

		public static Transaction_Log_CriteriaType GetEffective( DateTime startdt, DateTime enddt )
		{


			Transaction_Log_CriteriaType tranLogCriteria = new Transaction_Log_CriteriaType();
			tranLogCriteria.Transaction_Date_Range_Data = new Effective_And_Updated_DateTime_DataType();

			tranLogCriteria.Transaction_Date_Range_Data.Effective_From = startdt;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_FromSpecified = true;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_Through = enddt;
			tranLogCriteria.Transaction_Date_Range_Data.Effective_ThroughSpecified = true;

			return tranLogCriteria;
		}

		internal static void ChangeEmailAddress( WorkdayAgent.WorkdayFetchAgent agent, Human_ResourcesPortClient client, string employeeId, string emailaddress )
		{
			Employee_Personal_Info_UpdateType update = new Employee_Personal_Info_UpdateType();
			update.Employee_Reference = new Employee_ReferenceType();
			update.Employee_Reference.Integration_ID_Reference = new External_Integration_ID_Reference_DataType();
			update.Employee_Reference.Integration_ID_Reference.ID = new IDType() { System_ID = "WD-EMPLID", Value = employeeId };
			update.Employee_Personal_Info_Data = new Worker_Personal_Info_DataType();
			update.Employee_Personal_Info_Data.Personal_Info_Data = new Personal_Info_DataType();
			update.Employee_Personal_Info_Data.Personal_Info_Data.Person_Data = new Person_DataType();
			update.Employee_Personal_Info_Data.Personal_Info_Data.Person_Data.Contact_Data = new Contact_DataType();
			update.Employee_Personal_Info_Data.Personal_Info_Data.Person_Data.Contact_Data.Internet_Email_Address_Data = new Internet_Email_Address_DataType[1];
			Internet_Email_Address_DataType email = new Internet_Email_Address_DataType();
			email.Email_Address = emailaddress;
			email.Usage_Data = new Communication_Method_Usage_DataType();
			email.Usage_Data.Public = true;
			email.Usage_Data.PublicSpecified = true;
			email.Usage_Data.Type_Reference = new Communication_Usage_Type_ReferenceType[1];
			email.Usage_Data.Type_Reference[0] = new Communication_Usage_Type_ReferenceType() { PrimarySpecified = true, Primary = true, Value = "WORK" };
			update.Employee_Personal_Info_Data.Personal_Info_Data.Person_Data.Contact_Data.Internet_Email_Address_Data[0] = email;
			try
			{
				client.Update_Employee_Personal_Info( update );
			}
			catch ( Exception ex )
			{
				agent.LogException( ex, "Error changing email address at Workday", "WorkerData.ChangeEmailAddress" );

			}

		}

		#endregion

		#region Converter Methods

		internal static bool TryGetAssociateFromWorkday( WorkdayAgent.WorkdayFetchAgent agent, Worker_DataType worker, out Associate associate )
		{
			associate = new Associate();

			try
			{
				associate.EmployeeId = worker.Worker_ID;
				//SetValue(associate.Id, worker.Worker_ID);
				//SetValue(worker.Employment_Data.Worker_Status_Data.Academic_Tenure_DateSpecified, associate.Id, worker.Worker_ID);

				associate.ADInfoSpecified = true;

				associate.PersonalInfoSpecified = TryGetPersonalInfo( worker, associate );

				associate.ContactInfoSpecified = TryGetContactInfo( worker, associate );
				associate.EmploymentStatusSpecified = TryGetEmploymentStatusInfo( worker, associate );
				associate.EmploymentPositionSpecified = TryGetEmploymentPositionInfo( worker, associate );

				if ( worker.Management_Chain_Data != null )
					if ( worker.Management_Chain_Data.Worker_Matrix_Management_Chain_Data != null && worker.Management_Chain_Data.Worker_Matrix_Management_Chain_Data.Length > 0 )
						associate.EmploymentPosition.ManagerId = worker.Management_Chain_Data.Worker_Supervisory_Management_Chain_Data[0].Manager_Reference.ID[1].Value;

				associate.OperationalMatrixSpecified = TryGetOrganizationInfo( worker, associate );
				associate.StandardPayPlanSpecified = TryGetPayPlan( worker, associate );

				return true;
			}
			catch ( Exception ex )
			{
				agent.LogException( ex, "Error Translating Worker into Associate", "WorkerData.TryGetAssociateFromWorkday" );
				return false;
			}
		}

		public static void GetPayDetail( Associate associate, Worker_DataType worker )
		{
			associate.Currency = worker.Compensation_Data.Salary_and_Hourly_Data[0].Currency_Reference.Descriptor;

		}

		public static void GetBenefitInfo( Associate associate, Worker_DataType worker )
		{
			foreach ( var plan in worker.Benefit_Enrollment_Data.Health_Care_Data )
			{
				//plan.
			}
			// .WorkerType.Worker_Data.Benefit_Enrollment_Data.Health_Care_Data.Health_Care_Period_Data.Health_Care_Coverage_Data[1]
		}

		public static bool TryGetOrganizationInfo( Worker_DataType worker, Associate associate )
		{
			if ( worker == null )
				return false;

			//worker.Organization_Data[0].Organization_Reference.
			//WorkerObjectType manager = worker.Organization_Data[0].Organization_Data.Organization_Support_Role_Data[0].Organization_Role_Data[0].Worker_Reference;
			//orginfo.ManagerId 
			WorkerObjectIDType manager = null;

			if ( worker.Management_Chain_Data != null )
				manager = worker.Management_Chain_Data.Worker_Supervisory_Management_Chain_Data[worker.Management_Chain_Data.Worker_Supervisory_Management_Chain_Data.Count() - 1].Manager_Reference.ID.Where( u => u.type == "Employee_ID" ).FirstOrDefault();


			//WorkerObjectIDType manager = worker.Organization_Data[0].Organization_Data.Organization_Support_Role_Data[0].Organization_Role_Data[0].Worker_Reference.ID.Where(u => u.type == "Employee_ID").FirstOrDefault();

			if ( manager != null )
			{
				associate.OperationalMatrixValues = new OperationalMatrixValues()
				{
					Manager = manager.Value,
					IsManagerEmployee = manager.type.Equals( "Employee_ID" )
				};
			}

			if ( worker.Organization_Data != null )
			{
				foreach ( var orgdata in worker.Organization_Data )
				{
					foreach ( var orgref in orgdata.Organization_Reference.ID )
					{
						if ( orgref.type == "Cost_Center_Reference_ID" )
						{
							if ( associate.OperationalMatrixValues == null )
								associate.OperationalMatrixValues = new OperationalMatrixValues();

							associate.OperationalMatrixValues.Department = orgdata.Organization_Data.Organization_Code;
							//orginfo.Department = orgref.Value;
						}
						if ( orgref.type == "Company_Reference_ID" )
						{
							if ( associate.OperationalMatrixValues == null )
								associate.OperationalMatrixValues = new OperationalMatrixValues();

							associate.OperationalMatrixValues.BusinessUnit = orgdata.Organization_Data.Organization_Code;
							//orginfo.Department = orgref.Value;
						}
					}

				}
			}

			if ( worker != null
				&& worker.Employment_Data != null
				&& worker.Employment_Data.Position_Data != null
				&& worker.Employment_Data.Position_Data.Business_Site_Summary_Data != null
				&& worker.Employment_Data.Position_Data.Business_Site_Summary_Data.Location_Reference != null
				&& worker.Employment_Data.Position_Data.Business_Site_Summary_Data.Location_Reference.ID != null )
			{
				LocationObjectIDType location = worker.Employment_Data.Position_Data.Business_Site_Summary_Data.Location_Reference.ID.FirstOrDefault( u => u.type == "Location_ID" );
				if ( location != null )
				{
					if ( associate.OperationalMatrixValues == null )
						associate.OperationalMatrixValues = new OperationalMatrixValues();

					//string locationId;
					associate.OperationalMatrixValues.Location = location.Value;
					//if (Int32.TryParse(location.Value, out locationId))
					//{
					//    orginfo.Location = locationId;
					//}
				}
			}

			return associate.OperationalMatrixValues != null;
		}

		public static bool TryGetEmploymentPositionInfo( Worker_DataType worker, Associate associate )
		{
			if ( worker.Employment_Data == null )
				return false;

			//positioninfo = new EmploymentPosition();
			if ( worker.Employment_Data.Position_Data != null )
			{
				associate.EmploymentPosition = new EmploymentPosition();

				if ( string.IsNullOrEmpty( worker.Employment_Data.Position_Data.Position_Title ) == false )
					associate.EmploymentPosition.Title = worker.Employment_Data.Position_Data.Position_Title;

				if ( worker.Employment_Data.Position_Data.Job_ExemptSpecified )
					associate.EmploymentPosition.ExemptJobLabor = worker.Employment_Data.Position_Data.Job_Exempt;

				if ( worker.Employment_Data.Position_Data.Work_Shift_Reference != null )
					associate.EmploymentPosition.Shift = worker.Employment_Data.Position_Data.Work_Shift_Reference.ID[1].Value;

				if ( worker.Employment_Data.Position_Data.Position_Time_Type_Reference != null )
					associate.EmploymentPosition.FullTimeEmployee = ( worker.Employment_Data.Position_Data.Position_Time_Type_Reference.Descriptor == "Full time" );

				if ( worker.Employment_Data.Position_Data.Job_Profile_Summary_Data != null 
					&& worker.Employment_Data.Position_Data.Job_Profile_Summary_Data.Job_Profile_Reference != null 
					&& worker.Employment_Data.Position_Data.Job_Profile_Summary_Data.Job_Profile_Reference.ID != null )
				{
					Job_ProfileObjectIDType jobprofile = worker.Employment_Data.Position_Data.Job_Profile_Summary_Data.Job_Profile_Reference.ID.FirstOrDefault( u => u.type == "Job_Profile_ID" );
					if ( jobprofile != null )
						associate.EmploymentPosition.JobCode = jobprofile.Value;
				}

				if ( worker.Employment_Data.Position_Data.Worker_Type_Reference != null )
				{
					var item = worker.Employment_Data.Position_Data.Worker_Type_Reference.ID.FirstOrDefault( x => x.Value == "Regular" );
					if ( item != null )
						associate.EmploymentPosition.IsEmployee = item.type.Equals( "Employee_Type_ID" );
				}
			}


			if ( worker.Employment_Data.Worker_Status_Data != null 
				&& worker.Employment_Data.Worker_Status_Data.Academic_Tenure_DateSpecified )
				associate.EmploymentPosition.TenureDate = worker.Employment_Data.Worker_Status_Data.Academic_Tenure_Date;

			//if (worker.Employment_Data.Position_Data.Scheduled_Weekly_HoursSpecified)
			//{
			//    positioninfo.ExemptHoursWeek = worker.Employment_Data.Position_Data.Scheduled_Weekly_Hours;
			//    SendTranslateTrace("worker.Employment_Data.Position_Data.Scheduled_Weekly_Hours", "EmploymentPosition.ExemptHoursWeek", worker.Employment_Data.Position_Data.Scheduled_Weekly_Hours.ToString(), positioninfo.ExemptHoursWeek.ToString());
			//}

			return associate.EmploymentPosition != null;
		}

		public static bool TryGetPayPlan( Worker_DataType worker, Associate associate )
		{
			if ( worker != null
				&& worker.Employment_Data != null
				&& worker.Employment_Data.Position_Data != null
				&& worker.Employment_Data.Position_Data.Scheduled_Weekly_HoursSpecified )
				associate.StandardPayPlan = new AssociatePayPlan() { StandardHours = worker.Employment_Data.Position_Data.Scheduled_Weekly_Hours };

			return associate.StandardPayPlan != null;
		}

		public static bool TryGetContactInfo( Worker_DataType worker, Associate associate )
		{
			if ( worker == null || worker.Personal_Data == null || worker.Personal_Data.Contact_Data == null )
				return false;


			//contactinfo = new ContactInfo();
			if ( worker.Personal_Data.Contact_Data.Address_Data != null )
			{
				associate.ContactInfo = new ContactInfo();
				associate.ContactInfo.PersonAddresses.Clear();

				if ( worker.Personal_Data.Contact_Data.Address_Data != null )
				{

					foreach ( AddressTypeEnum addressType in Enum.GetValues( typeof( AddressTypeEnum ) ) )
					{
						foreach ( Address_Information_DataType waddress in worker.Personal_Data.Contact_Data.Address_Data )
						{
							if ( waddress.Usage_Data != null && waddress.Usage_Data.Where( u => u.Type_Data.Where( c => c.Type_Reference.Descriptor == addressType.ToString() && c.Primary == true ).FirstOrDefault() != null ).FirstOrDefault() != null )
							{
								AddressInfo address = new AddressInfo();

								if ( waddress.Address_Line_Data != null )
								{
									var waddressLine1 = waddress.Address_Line_Data.Where( u => u.Type == "ADDRESS_LINE_1" ).FirstOrDefault();
									if ( waddressLine1 != null )
									{
										address.AddressLines.Add( waddressLine1.Value );
									}

									var waddressLine2 = waddress.Address_Line_Data.Where( u => u.Type == "ADDRESS_LINE_2" ).FirstOrDefault();
									if ( waddressLine2 != null )
									{
										address.AddressLines.Add( waddressLine2.Value );
									}

									var waddressLine3 = waddress.Address_Line_Data.Where( u => u.Type == "ADDRESS_LINE_3" ).FirstOrDefault();
									if ( waddressLine3 != null )
									{
										address.AddressLines.Add( waddressLine3.Value );
									}

									var waddressLine4 = waddress.Address_Line_Data.Where( u => u.Type == "ADDRESS_LINE_4" ).FirstOrDefault();
									if ( waddressLine4 != null )
									{
										address.AddressLines.Add( waddressLine4.Value );
									}
								}

								var wcountry = waddress.Country_Reference.ID.Where( u => u.type == "ISO_3166-1_Alpha-3_Code" ).FirstOrDefault();
								if ( wcountry != null )
								{
									address.Country = wcountry.Value;
								}
								// need a null check
								if ( waddress.Country_Region_Reference != null )
								{
									var wstate = waddress.Country_Region_Reference.ID.Where( u => u.type == "Country_Region_ID" ).FirstOrDefault();

									if ( wstate != null )
									{
										address.State = wstate.Value;
									}
								}
								address.City = waddress.Municipality;
								address.ZipCode = waddress.Postal_Code;
								address.AddressType = addressType;
								associate.ContactInfo.PersonAddresses.Add( address );
							}
						}
					}
				}

				if ( worker.Personal_Data.Contact_Data.Email_Address_Data != null )
				{
					associate.ContactInfo.EmailAddresses.Clear();
					List<EmailAddress> elist = new List<EmailAddress>();
					foreach ( EmailAddressTypeEnum emailAddressType in Enum.GetValues( typeof( EmailAddressTypeEnum ) ) )
					{
						foreach ( Email_Address_Information_DataType wemail in worker.Personal_Data.Contact_Data.Email_Address_Data )
						{
							if ( wemail.Usage_Data.Where( u => u.Type_Data.Where( c => c.Type_Reference.Descriptor == emailAddressType.ToString() && c.Primary == true ).FirstOrDefault() != null ).FirstOrDefault() != null )
							{
								EmailAddress email = new EmailAddress();
								email.Address = wemail.Email_Address;
								email.EmailAddressType = emailAddressType;
								elist.Add( email );
								//contactinfo.EmailAddresses.Add(email);
							}
						}
					}
					associate.ContactInfo.EmailAddresses = elist;

				}
				if ( worker.Personal_Data.Contact_Data.Phone_Data != null )
				{
					associate.ContactInfo.Phones.Clear();

					foreach ( PhoneTypeEnum phoneType in Enum.GetValues( typeof( PhoneTypeEnum ) ) )
					{
						foreach ( AddressTypeEnum addressType in Enum.GetValues( typeof( AddressTypeEnum ) ) )
						{
							foreach ( Phone_Information_DataType wphone in worker.Personal_Data.Contact_Data.Phone_Data )
							{
								if ( wphone.Phone_Device_Type_Reference.Descriptor.Equals( phoneType.ToString() ) )
								{
									if ( wphone.Usage_Data.Where( u => u.Type_Data.Where( c => c.Type_Reference.Descriptor == addressType.ToString() && c.Primary == true ).FirstOrDefault() != null ).FirstOrDefault() != null )
									{
										Phone phone = new Phone();

										phone.Number = wphone.Formatted_Phone;
										phone.PartialNumber = wphone.Phone_Number;
										phone.AreaCode = wphone.Area_Code;
										phone.PhoneType = phoneType;
										phone.AddressType = addressType;

										int PhoneExtension;
										if ( Int32.TryParse( wphone.Phone_Extension, out PhoneExtension ) )
										{
											phone.Extension = PhoneExtension;
										}
										associate.ContactInfo.Phones.Add( phone );
									}
								}
							}
						}
					}
				}

				if ( worker.Personal_Data.Contact_Data.Instant_Messenger_Data != null )
				{
					foreach ( Instant_Messenger_Information_DataType email in worker.Personal_Data.Contact_Data.Instant_Messenger_Data )
					{
					}
				}
			}

			return associate.ContactInfo != null;
		}

		public static bool TryGetPersonalInfo( Worker_DataType worker, Associate associate )
		{
			if ( worker.Personal_Data == null )
				return false;

			associate.PersonalInfo = new PersonalInfo();


			bool name = false, pref = false;
			name = TryGetLegalNameData( worker, associate );
			pref = TryGetPreferredNameData( worker, associate );

			if ( pref )
				SetAssociatePreferredNameData( associate.PersonalInfo.PreferredNameData, associate );
			else if ( name )
				SetAssociatePreferredNameData( associate.PersonalInfo.NameData, associate );
			else
				return false;

			//don't keep going if we don't even have a name....

			if ( worker.Personal_Data.Country_of_Birth_Reference != null
				&& worker.Personal_Data.Country_of_Birth_Reference.ID != null
				&& worker.Personal_Data.Country_of_Birth_Reference.ID.Length > 0 )
				associate.PersonalInfo.BirthCountry = worker.Personal_Data.Country_of_Birth_Reference.ID[0].Value;

			if ( worker.Personal_Data.Birth_DateSpecified )
				associate.PersonalInfo.DateOfBirth = worker.Personal_Data.Birth_Date;

			if ( worker.Personal_Data.Marital_Status_Reference != null )
				associate.PersonalInfo.MaritalStatus = worker.Personal_Data.Marital_Status_Reference.ID[1].Value;

			if ( worker.Personal_Data.Military_Service_Data != null )
				associate.PersonalInfo.MilitaryStatus = worker.Personal_Data.Military_Service_Data[0].Status_Reference.ID[1].Value;

			//personalinfo.Gender = MapGender(worker.Personal_Data.Gender_Reference.ID[1].Value);
			//personalinfo.EligibleToWork = worker.Personal_Data.
			//personalinfo.FulltimeStudent = worker.Personal_Data.
			//personalinfo.Language = worker.Personal_Data.
			//personalinfo.MilitaryStatus = worker.

			if ( worker.Qualification_Data != null && worker.Qualification_Data.Education != null )
			{
				foreach ( var level in worker.Qualification_Data.Education )
				{
					foreach ( var edudata in level.Education_Data )
					{
						if ( edudata.Is_Highest_Level_of_Education )
						{
							if ( edudata.Degree_Reference != null )
							{
								associate.PersonalInfo.HighestEducationLevel = edudata.Degree_Reference.Descriptor;
								return true;
							}
						}
					}
				}
			}

			return associate.PersonalInfo != null;
		}

		public static bool TryGetLegalNameData( Worker_DataType worker, Associate associate )
		{
			if ( worker == null
				|| worker.Personal_Data == null
				|| worker.Personal_Data.Name_Data == null
				|| worker.Personal_Data.Name_Data.Legal_Name_Data == null )
				return false;

			if ( associate.PersonalInfo == null )
				return false;

			associate.PersonalInfo.NameData = new PersonNameData()
			{
				FirstName = worker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.First_Name,
				LastName = worker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.Last_Name
			};

			if ( worker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.Middle_Name != null )
				associate.PersonalInfo.NameData.MiddleName = worker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.Middle_Name;
			//personalinfo.NameData.Prefix = worker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.Prefix_Data.Title_Reference.;
			// TODO map suffix and prefix

			return true;
		}

		public static bool TryGetPreferredNameData( Worker_DataType worker, Associate associate )
		{
			if ( worker == null
				|| worker.Personal_Data == null
				|| worker.Personal_Data.Name_Data == null
				|| worker.Personal_Data.Name_Data.Preferred_Name_Data == null )
				return false;

			if ( associate.PersonalInfo == null )
				return false;

			associate.PersonalInfo.PreferredNameData = new PersonNameData()
			{
				FirstName = worker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.First_Name,
				LastName = worker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.Last_Name
			};

			if ( worker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.Middle_Name != null )
				associate.PersonalInfo.PreferredNameData.MiddleName = worker.Personal_Data.Name_Data.Preferred_Name_Data.Name_Detail_Data.Middle_Name;


			//personalinfo.NameData.Prefix = worker.Personal_Data.Name_Data.Legal_Name_Data.Name_Detail_Data.Prefix_Data.Title_Reference.;
			// TODO map suffix and prefix

			return true;
		}

		public static bool TryGetEmploymentStatusInfo( Worker_DataType worker, Associate associate )
		{
			if ( worker == null
				|| worker.Employment_Data == null
				|| worker.Employment_Data.Worker_Status_Data == null )
				return false;


			//contactinfo.Status =  statusdata.Active ? "Employee" : "Non-Employee";

			associate.EmploymentStatus = new EmploymentStatus()
			{
				Active = worker.Employment_Data.Worker_Status_Data.Active,
				StatusDate = worker.Employment_Data.Worker_Status_Data.Active_Status_Date,
				HireDate = worker.Employment_Data.Worker_Status_Data.Original_Hire_Date,
				RehireDate = worker.Employment_Data.Worker_Status_Data.Hire_Date,
				LastDateWorked = worker.Employment_Data.Worker_Status_Data.Termination_Last_Day_of_Work
			};

			//statusinfo.ExpectedEndDate = statusdata.Termination_Last_Day_of_Work;

			//contactinfo.RehireDate = statusdata.

			if ( worker.Employment_Data.Worker_Status_Data.Terminated )
			{
				associate.EmploymentStatus.TerminationDate = worker.Employment_Data.Worker_Status_Data.Termination_Date;
				if ( worker.Employment_Data.Worker_Status_Data.Primary_Termination_Reason_Reference != null
					&& worker.Employment_Data.Worker_Status_Data.Primary_Termination_Reason_Reference.ID != null
					&& worker.Employment_Data.Worker_Status_Data.Primary_Termination_Reason_Reference.ID.Length > 0 )
					associate.EmploymentStatus.TerminationReason = worker.Employment_Data.Worker_Status_Data.Primary_Termination_Reason_Reference.ID[0].Value;
			}

			return true;
		}

		public static void SetAssociatePreferredNameData( PersonNameData namedata, Associate associate )
		{
			associate.FirstName = namedata.FirstName;
			associate.LastName = namedata.LastName;
			associate.MiddleName = namedata.MiddleName;
		}

		public Worker_DataType SetWorkdayFromAssociate( Associate associate )
		{
			Worker_DataType worker = new Worker_DataType();

			return worker;

		}

		public static void SetContactInfo( ContactInfo contactinfo, Worker_DataType worker )
		{

		}

		public static void SetPersonalInfo( PersonalInfo personalinfo, Worker_DataType worker )
		{

		}

		public static void SetPersonalInfo( EmploymentStatus contactinfo, Worker_DataType worker )
		{

		}

		public GenderTypeEnum MapGender( string gender )
		{
			switch ( gender )
			{
				case "Male":
					return GenderTypeEnum.Male;
				case "Female":
					return GenderTypeEnum.Female;
				default:
					return GenderTypeEnum.Unknown;
			}
		}



		#endregion
	}
}