﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JDA.ITG.Flow.Agent.Shared
{
	#region Enums

	public enum EmailAddressTypeEnum
	{
		Home = 0,
		Work
	}

	public enum AddressTypeEnum
	{
		Home = 0,
		Work
	}

	public enum PhoneTypeEnum
	{
		Mobile = 0,
		Telephone
	}

	public enum RoleTypeEnum
	{
		Employee = 0
	}

	public enum OfficeTypeEnum
	{
		JDA,
		Virtual,
		Home,
		DoNotDisclose
	}

	public enum GenderTypeEnum
	{
		Unknown = 0,
		Male = 1,
		Female = 2
	}

	public enum BenefitTypeEnum
	{
		HealthCare = 0
	}

  public enum IdTypeEnum
  {
    SSNCard = 0,
    DriversLicense,
    Passport
  }

	#endregion

	#region Associate Models

	public class Associate
	{
		public int Id { get; set; }
		public string EmployeeId { get; set; }
		public int OperationalMatrixId { get; set; }
		public int? ActiveDirectoryId { get; set; }
		public string Description { get; set; }
		public string SecurityClearance { get; set; }
		public string TaxLocation { get; set; }
		public string BenefitStatus { get; set; }
		public string UnionStatus { get; set; }
		public string UnionPosition { get; set; }
		public string Currency { get; set; }
		public Nullable<System.DateTime> UnionSeniorityDate { get; set; }
		public string LastUpdatedBy { get; set; }
		public Nullable<System.DateTime> LastUpdatedTime { get; set; }
		// certain fields are not mapped so they will not be part of the persisted data model
		public bool PersonalInfoSpecified { get; set; }
		public bool EmploymentStatusSpecified { get; set; }
		public bool ADInfoSpecified { get; set; }
		public bool ContactInfoSpecified { get; set; }
		public bool EmploymentPositionSpecified { get; set; }
		public bool TestHistorySpecified { get; set; }
		public bool OperationalMatrixSpecified { get; set; }
		public bool StandardPayPlanSpecified { get; set; }
		public bool TenroxSupplementalSpecified { get; set; }
		public string FirstName { get; set; }
		public string MiddleName { get; set; }
		public string LastName { get; set; }
		public string Prefix { get; set; }
		public string Suffix { get; set; }
		public string Region { get; set; }

		public OperationalMatrix OperationalMatrix { get; set; }
		public OperationalMatrixValues OperationalMatrixValues { get; set; }
		public EmploymentStatus EmploymentStatus { get; set; }
		public int? EmploymentStatusId { get; set; }
		public PersonalInfo PersonalInfo { get; set; }
		public int? PersonalInfoId { get; set; }
		public EmploymentPosition EmploymentPosition { get; set; }
		public int? EmploymentPositionId { get; set; }
		public ContactInfo ContactInfo { get; set; }
		public int? ContactInfoId { get; set; }
		public JDAUser JDAUser { get; set; }
		public int? JDAUserId { get; set; }
		public List<AssociateRole> AssociateRoles { get; set; }
		public AssociatePayPlan StandardPayPlan { get; set; }
		public ActiveDirectoryInfo AdInfo { get; set; }
		public TenroxSupplemental TenroxData { get; set; }
		public List<AssociatePayPlan> AssociatePayPlans { get; set; }
		public List<TestHistory> TestsTaken { get; set; }
	}

	public class PersonalInfo
	{
		public PersonalInfo()
		{
			NameData = new PersonNameData();
			PreferredNameData = new PersonNameData();
		}

		public int Id { get; set; }
		public string Status { get; set; }
		public Nullable<System.DateTime> StatusDate { get; set; }
		public GenderTypeEnum Gender { get; set; }
		public Nullable<System.DateTime> DateOfBirth { get; set; }
		public string BirthCountry { get; set; }
		public string MaritalStatus { get; set; }
		public string MilitaryStatus { get; set; }
		public Nullable<bool> FulltimeStudent { get; set; }
		public string Language { get; set; }
		public bool? EligibleToWork { get; set; }
		public string HighestEducationLevel { get; set; }
		public string LastUpdatedBy { get; set; }
		public DateTime? LastUpdatedTime { get; set; }
		public PersonNameData NameData { get; set; }
		public PersonNameData PreferredNameData { get; set; }
	}

	public class PersonNameData
	{
		public int Id { get; set; }
		public string FirstName { get; set; }
		public string MiddleName { get; set; }
		public string LastName { get; set; }
		public string Prefix { get; set; }
		public string Suffix { get; set; }
	}

  public class WorkPermit
  {
  }

	public class IdentificationInfo
	{
		public DateTime IssuedDate { get; set; }
		public DateTime ExpirationDate { get; set; }
		public String IdentificationNumber { get; set; }
		public String NameOnId { get; set; }
	}

	public class OperationalMatrix
	{
		public int Id { get; set; }
		public int BusinessUnitId { get; set; }
		public int OperatingUnitId { get; set; }
		public int LocationId { get; set; }
		public int DepartmentId { get; set; }
		public int CostCenterId { get; set; }
	}

	public class OperationalMatrixValues
	{
		public int Id { get; set; }
		public string BusinessUnit { get; set; }
		public string OperatingUnit { get; set; }
		public string Location { get; set; }
		public string Department { get; set; }
		public string TeamNumber { get; set; }
		public string CostCenter { get; set; }
		public string Manager { get; set; }
		public string ManagerEmailAddress { get; set; }
		public bool IsManagerEmployee { get; set; }
	}

	public class TenroxSupplemental
	{
		public string SecurityRoleCode { get; set; }
		public string ResourceTypeCode { get; set; }
		public decimal CostRate { get; set; }
		public decimal ForeCastRate { get; set; }
		public string ADPFileNo { get; set; }
	}

	public class BenefitStatus
	{
		public int Id { get; set; }
		public BenefitTypeEnum BenefitType { get; set; }
		public string BenefitStatusName { get; set; }
	}

	public class AddressInfo
	{
		public AddressInfo()
		{
			AddressLines = new List<string>();
		}

		public int Id { get; set; }
		public List<string> AddressLines { get; set; }
		public string City { get; set; }
		public string County { get; set; }
		public string State { get; set; }
		public string Country { get; set; }
		public string ZipCode { get; set; }
		public AddressTypeEnum AddressType { get; set; }

		public void AddAddressLine( string addressLine )
		{
			if ( !AddressLines.Contains( addressLine ) )
			{
				AddressLines.Add( addressLine );
			}
		}

		//MARKMG-16NOV12 Can also sort both lists and then compare
		public void SyncAddressLines( List<string> addressLines )
		{
			bool addressModified = false;

			if ( addressLines.Count != AddressLines.Count )
			{
				addressModified = true;
			}

			int matchCount = 0;
			foreach ( string addressline in addressLines )
			{
				if ( !AddressLines.Contains( addressline ) )
				{
					addressModified = true;
					//MARKMG-16NOV12 Add logging message
					break;
				}
				matchCount++;
			}

			if ( !addressModified & ( matchCount < AddressLines.Count ) )
			{
				addressModified = true;
				//MARKMG-16NOV12 Add logging message
			}
			if ( addressModified )
			{
				AddressLines.Clear();
				AddressLines.InsertRange( 0, addressLines );
			}
		}

		public void SendApiTrace()
		{

		}
	}

	public class ContactInfo
	{
		public ContactInfo()
		{
			EmailAddresses = new List<EmailAddress>();
			PersonAddresses = new List<AddressInfo>();
			Phones = new List<Phone>();
			InstantMessangerAccount = new List<InstantMessengerAccount>();
		}

		public int Id { get; set; }
		public List<EmailAddress> EmailAddresses { get; set; }
		public List<AddressInfo> PersonAddresses { get; set; }
		public List<Phone> Phones { get; set; }
		public List<InstantMessengerAccount> InstantMessangerAccount { get; set; }
	}

	public class EmailAddress
	{
		public int Id { get; set; }
		public string Address { get; set; }
		public EmailAddressTypeEnum EmailAddressType { get; set; }
	}

	public class InstantMessengerAccount
	{
		public int Id { get; set; }
	}

	public class Phone
	{
		public int Id { get; set; }
		public string Number { get; set; }
		public string AreaCode { get; set; }
		public string PartialNumber { get; set; }
		public Nullable<int> Extension { get; set; }
		public AddressTypeEnum AddressType { get; set; }
		public PhoneTypeEnum PhoneType { get; set; }
	}

	public class AssociatePayPlan
	{
		public int Id { get; set; }
		public string PayPlanLabel { get; set; }
		public string Description { get; set; }
		public string Status { get; set; }
		public Nullable<System.DateTime> StatusDate { get; set; }
		public string Currency { get; set; }
		public decimal StandardHours { get; set; }
		public string StandardHoursFrequency { get; set; }
		public string Tarriff { get; set; }
		public string TarriffArea { get; set; }
	}

	public class AssociateRole
	{
		public int Id { get; set; }
		public string Description { get; set; }
		public string TrackingCode { get; set; }
		public string PeopleManager { get; set; }
		public string ClassGroup { get; set; }
		public string ClassCode { get; set; }
		public Nullable<System.DateTime> ExpectedEndDate { get; set; }
		public RoleTypeEnum RoleType { get; set; }
		public Nullable<int> RoleTypeId { get; set; }
	}

	public class EmploymentPosition
	{
		public int Id { get; set; }
		public string Title { get; set; }
		public string SalaryGrade { get; set; }
		public bool FullTimeEmployee { get; set; }
		public string ManagerId { get; set; }
		public DateTime? TenureDate { get; set; }
		public bool? ExemptJobLabor { get; set; }
		public decimal? ExemptHoursWeek { get; set; }
		public string JobCode { get; set; }
		public string Shift { get; set; }
		public bool IsEmployee { get; set; }
	}

	public class EmploymentStatus
	{
		public int Id { get; set; }
		public bool Active { get; set; }
		public string Status { get; set; }
		public Nullable<System.DateTime> StatusDate { get; set; }
		public Nullable<System.DateTime> HireDate { get; set; }
		public Nullable<System.DateTime> TerminationDate { get; set; }
		public Nullable<System.DateTime> ExpectedEndDate { get; set; }
		public Nullable<System.DateTime> LastDateWorked { get; set; }
		public string TerminationReason { get; set; }
		public Nullable<System.DateTime> RehireDate { get; set; }
	}

	public class TestHistory
	{
		public int Id { get; set; }
		public string TestDesc { get; set; }
		public Nullable<System.DateTime> TestDate { get; set; }
		public double? TestScore { get; set; }
		public bool? Passed { get; set; }
	}

	public class ActiveDirectoryInfo
	{
		public bool IsProvisioned { get; set; }
		public string JdaAdManager { get; set; }
		public OfficeTypeEnum? OfficeType { get; set; }
		public OfficeTypeEnum? ADOfficeType { get; set; }
		public string MailNickname { get; set; }
		public string PER_STATUS { get; set; }
		public string EMPL_STATUS { get; set; }
		public string DepartmentNumber { get; set; }
		//TODO this is currently passthrough, it should find a better place
		public string l { get; set; }

	}

	public class JDAUser
	{
		public int Id { get; set; }
	}

	#endregion

	#region for another day

	#region ModelBase

	public abstract class ModelBase
	{
		public System.DateTime Date { get; set; }
	}

	#endregion

	#region abstract Property<T>

	public abstract class Property<T> where T : struct
	{
		#region declarations

		private object _value = null;

		#endregion

		#region Constructor

		public Property( T value )
		{
			this.Value = value;
		}

		#endregion

		#region Operators

		public static explicit operator T( Property<T> value )
		{
			return (T)value;
		}

		public static implicit operator Property<T>( T value )
		{
			return value;
		}

		#endregion

		#region Properties

		[Newtonsoft.Json.JsonProperty( "D" )]
		public DateTime Date { get; set; }

		[Newtonsoft.Json.JsonProperty( "V" )]
		public T Value 
		{
			get { return _value == null ? default( T ) : (T)_value; }
			set
			{
				//have to do this because you cannot do T == T or T == default(T)...
				object o = value;
				if ( o == null )
					_value = null;
				else
					_value = value;
			}
		}

		[Newtonsoft.Json.JsonIgnore]
		public bool HasValue
		{
			get { return _value != null; }
		}

		#endregion
	}

	#endregion
	
	#endregion
}
