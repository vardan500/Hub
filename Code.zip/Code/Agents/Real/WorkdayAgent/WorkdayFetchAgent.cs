﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow;
using JDA.ITG.Flow.Agent;

namespace WorkdayAgent
{
	class WorkdayFetchAgent : PublisherBase
	{
		public const long AGENTID = 1;

		public override long AgentId { get { return AGENTID; } }
		public override string AgentName { get { return "Workday Agent"; } }

		public override void Publish()
		{
			bool successful = false;
			AgentWork work = new AgentWork();
			Dictionary<string,DateTime> workersAndDates = null;
			List<JDA.ITG.Flow.Agent.Shared.Associate> associates = null;

			DateTime? lastRunTime = this.AgentDataGetAsDateTime( "LastRunTime" );

			//setup the last run time
			if ( lastRunTime.HasValue == false )
			{
				lastRunTime = DateTime.MinValue;
				if ( this.AgentDataSet( "LastRunTime", lastRunTime.Value ) == false )
				{
					//couldn't update last run time. Send an error and abort.
					this.LogError( "Unable to set agent data item 'LastRunTime'. Aborting run" );
				}
			}

			if( Workday.Processor.TryGetWork( this, DateTime.MinValue, DateTime.MaxValue, out workersAndDates ) )
			{
				if( Workday.Processor.TryGetAssociatesFromRAAS( this, workersAndDates, out associates ) )
				{
					//anything else we need to do...
				}
			}


			if ( associates != null && associates.Count > 0 )
			{
				foreach( var item in associates )
				{
					//create a container to send the associate in
					AgentWorkItem awi = new AgentWorkItem()
					{
						ObjectName = "Asssociate",
						ObjectKey = item.EmployeeId,
						Document = Serializer.Serialize( item )
					};

					//add to the AgentWork container
					work.Add( awi );
				}

				//send to the hub in batches of 20...
				successful = Send( work, 20 );
			}

			//only update the last run time if we successfully posted all the data to the hub
			if ( successful )
				this.AgentDataSet( "LastRunTime", DateTime.UtcNow );
		}


		public string GetVersion()
		{
			return this.AppSettingGet( "WDRequestVersion" );
		}
	}
}
