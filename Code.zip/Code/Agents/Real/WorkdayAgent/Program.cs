﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JDA.ITG.Flow;
using JDA.ITG.Flow.Agent;
using JDA.ITG.Flow.Agent.Service;
using JDA.ITG.Flow.Agent.Shared;
using JDA.ITG.DataAbstraction.Workday.WorkdayHumanResources;

namespace WorkdayAgent
{
	class Program
	{
		static void Main( string[] args )
		{
			//This is the  agent that will do the work in this exe
			JDA.ITG.Flow.AgentManager.Intialize( args, typeof( WorkdayFetchAgent ) );
		}
	}
}
