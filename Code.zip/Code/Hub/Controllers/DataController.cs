﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.Controllers
{
	[ControllerDisplay("Data")]
	[CoreAuthorize( Models.UserPermission.Configuration )]
	public class DataController : BaseController
	{
		const string ACTION_ADD = "add";
		const string ACTION_UPDATE = "set";
		const string ACTION_DELETE = "del";

		public ActionResult Index()
		{
			return View();
		}

		#region ObjectSummary

		[ActionDisplay("Data Summary")]
		public ActionResult ObjectSummary()
		{
			ModelObjectReportSummaryList model;
			Data.TryGetObjectSummary( out model );
			return View( model );
		}

		#endregion
		
		#region ObjectDetails

		[ActionDisplay("Data Details")]
		public ActionResult ObjectDetails()
		{
			this.ViewBag.Hide = true;
			this.ViewBag.IFrame = true;
			long agentId = 0;
			int objectId = 0;
			long.TryParse( Request.QueryString.Get( "agentId" ), out agentId );
			int.TryParse( Request.QueryString.Get( "objectId" ), out objectId );

			ModelDataLookup lookup = new ModelDataLookup() { AgentId = agentId, ObjectId = objectId, ObjectKey = string.Empty };
			ModelDataDetailsList model;
			Data.TryGetDataGetDetails( lookup, true, out model );
			return View( model );
		}

		//[HttpPost]
		//public ActionResult ObjectDetails( ModelDataLookup details )
		//{
		//	this.ViewBag.Hide = true;
		//	this.ViewBag.IFrame = true;

		//	ModelDataDetailsList model;
		//	Data.TryGetDataGetDetails( details, true, out model );
		//	//specifying the view because this is called by ClearError
		//	return View( "ObjectDetails", model );
		//}

		[HttpPost]
		public ActionResult ObjectDetails( ModelDataLookup model )
		{
			switch ( model.Action )
			{
				case "Clear Errors For Combination":
					if ( model != null )
						Data.TryClearErrors( model );
					break;
			}

			ModelDataDetailsList newModel = null;
			Data.TryGetDataGetDetails( model, true, out newModel );

			this.ViewBag.Hide = true;
			this.ViewBag.IFrame = true;
			return View( newModel );
		}


		#endregion

		#region ObjectErrors

		[ActionDisplay("Data Errors")]
		public ActionResult ObjectErrors()
		{
			this.ViewBag.Hide = true;
			this.ViewBag.IFrame = true;
			long agentId = 0;
			int objectId = 0;
			long.TryParse( Request.QueryString.Get( "agentId" ), out agentId );
			int.TryParse( Request.QueryString.Get( "objectId" ), out objectId );

			ModelDataErrorList model;
			Data.TryGetDataGetErrorsForObjectAndAgent( objectId, agentId, out model );
			return View( model );
		}


		#endregion
	}
}