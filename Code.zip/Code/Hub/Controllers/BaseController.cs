﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.Controllers
{
	public abstract class BaseController : Controller
	{
		#region declarations / constants

		public const string REDIRECT_ROOT = "/";

		static Dictionary<string, string> _controllerPageTitles = new Dictionary<string, string>();
		static Dictionary<string, Dictionary<string,string>> _controllerActionTitles = new Dictionary<string, Dictionary<string,string>>();

		#endregion

		#region static constructor

		static BaseController()
		{
			try
			{
				foreach ( Type controller in System.Reflection.Assembly.GetExecutingAssembly().GetTypes().Where( c => c.IsSubclassOf( typeof( BaseController ) ) && c.IsAbstract == false ) )
				{
					ControllerDisplayAttribute cda = controller.GetCustomAttributes( typeof( ControllerDisplayAttribute ), false ).FirstOrDefault() as ControllerDisplayAttribute;
					string cname = controller.Name.Replace( "Controller", "" ).ToLower();
					if ( _controllerPageTitles.ContainsKey( cname ) == false )
						_controllerPageTitles.Add( cname, cda.Display );

					foreach ( System.Reflection.MethodInfo method in controller.GetMethods() )
					{
						ActionDisplayAttribute ada = method.GetCustomAttributes( typeof( ActionDisplayAttribute ), false ).FirstOrDefault() as ActionDisplayAttribute;
						if ( ada != null )
						{
							if ( _controllerActionTitles.ContainsKey( cname ) == false )
								_controllerActionTitles.Add( cname, new Dictionary<string, string>() );

							string aname = method.Name.ToLower();
							if ( _controllerActionTitles[cname].ContainsKey( aname ) == false )
								_controllerActionTitles[cname].Add( aname, ada.Display );
						}
					}


				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Failed to load the controller page title or action display name from one or more controllers", "BaseController()" );
			}
		}

		#endregion

		#region View

		/// <summary>Catch method to ensure Errors from data calls get returned to the View</summary>
		/// <param name="model"></param>
		/// <returns>ViewResult</returns>
		protected new internal ViewResult View( object model )
		{
			if ( model != null && model.GetType().GetInterfaces().Contains( typeof( IModelBase ) ) )
			{
				IModelBase imb = (IModelBase)model;
				if ( string.IsNullOrEmpty( imb.Error ) == false )
					this.TempData["error"] = imb.Error;
			}
			return base.View( model );
		}

		#endregion

		#region OnException

		protected override void OnException( ExceptionContext filterContext )
		{
			Log.Exception( filterContext.Exception, "Exception in a controller or a page", "Controller: " + filterContext.Controller.GetType().Name + ". Route: " + filterContext.RouteData.ToString() );
			this.TempData["error"] = filterContext.Exception.Message + ", stack: " + filterContext.Exception.StackTrace ?? string.Empty;

			base.OnException( filterContext );
		}

		#endregion

		#region OnAuthorization

		protected override void OnAuthorization( AuthorizationContext filterContext )
		{
			if ( filterContext != null
				&& filterContext.HttpContext != null
				&& filterContext.HttpContext.User != null
				&& filterContext.HttpContext.User.Identity != null )
			{
				if ( SessionState.AuthenticatedUser == null )
				{
					System.Web.Security.FormsAuthentication.SignOut();
					Session.RemoveAll();

					if ( filterContext.ActionDescriptor.ActionName.ToLower() != "index" || filterContext.ActionDescriptor.ControllerDescriptor.ControllerName.ToLower() != "home" )
						filterContext.Result = new RedirectResult( REDIRECT_ROOT );
				}
			}
			else
			{
				filterContext.Result = Redirect( REDIRECT_ROOT );
				//filterContext.Result = new HttpUnauthorizedResult();
			}
		}

		#endregion

		#region GetPageTitleForController

		public static string GetPageTitleForController( string controller )
		{
			string value = null;
			_controllerPageTitles.TryGetValue( controller.ToLower(), out value );
			return value ?? string.Empty;
		}

		public static string GetActionDisplay( string controller, string action )
		{
			string value = null;
			Dictionary<string,string> next;
			if ( _controllerActionTitles.TryGetValue( controller.ToLower(), out next ) )
				next.TryGetValue( action.ToLower(), out value );
			
				return value ?? string.Empty;
		}

		#endregion
	}

}