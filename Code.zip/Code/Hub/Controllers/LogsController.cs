﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.Controllers
{
	[ControllerDisplay("Logs")]
	[CoreAuthorize( Models.UserPermission.Logs )]
	public class LogsController : BaseController
	{
		[ActionDisplay("Logs")]
		public ActionResult Index()
		{
			ModelLogList model = new ModelLogList() { From = DateTime.Today, To = DateTime.Today.AddDays( 1 ), Level = LoggingLevel.NONE };
			Data.TryGetLogs( model );
			return View( model );
		}

		#region ObjectSummary

		[HttpPost]
		public ActionResult Index( ModelLogList model )
		{
			switch ( model.Action )
			{
				case "Lookup":
					Data.TryGetLogs( model );
					break;
				case "Purge Logs":
					Data.TryDelLogs( model );
					break;
			}
			return View( model );
		}

		#endregion
	}
}