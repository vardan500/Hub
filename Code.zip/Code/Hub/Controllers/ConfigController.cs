﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.Controllers
{
	[ControllerDisplay("Configuration")]
	[CoreAuthorize( Models.UserPermission.Configuration )]
	public class ConfigController : BaseController
	{
		const string ACTION_ADD = "add";
		const string ACTION_UPDATE = "set";
		const string ACTION_DELETE = "del";

		public ActionResult Index()
		{
			return View();
		}

		#region Agents

		[ActionDisplay("Agent Listing")]
		public ActionResult Agents()
		{
			ModelAgentList model;
			Data.TryGetAgents( out model );
			return View( model );
		}

		[HttpPost]
		public ActionResult Agents( ModelAgentList model )
		{
			if ( model == null || model.Item == null || string.IsNullOrEmpty( model.Action ) )
				return HubConfig();

			string error = string.Empty;

			string action = model.Action.ToLower();
			switch ( action )
			{
				case ACTION_ADD:
				case ACTION_UPDATE:

					if ( model.Item.AgentId <= 0 )
					{
						error = "Agent Id must be greater than zero";
					}
					else if( model.Item.AgentId > 1 && IsPowerOfTwo( Convert.ToUInt64( model.Item.AgentId ) ) == false )
					{
						error = "Agent Id must be 1 or a power of 2 (bitflag)";
					}
					else if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Agent Name is required";
					}
					else if ( string.IsNullOrEmpty( model.Item.Description ) )
					{
						error = "Agent Description is required";
					}
					else if ( string.IsNullOrEmpty( model.ScheduleString ) )
					{
						error = "Agent Schedule is required";
					}
					else
					{
						bool ok = true;
						AgentSchedule schedule = null;
						try
						{
							schedule = Serializer.Deserialize<AgentSchedule>( model.ScheduleString );
						}
						catch
						{
							error = "Unable to load the Agent Schedule into a valid Schedule Container. Please ensure you the schedule is properly formatted";
							ok = false;
							break;
						}

						if ( ok )
						{
							if ( schedule.Intervals == null )
								schedule.Intervals = new List<TimeSpan>();

							switch ( schedule.Mode )
							{
								case AgentIntervalMode.CycleEveryNSeconds:
									if ( schedule.CycleEveryNSeconds <= 0 )
										model.Error = "Schedule's CycleEveryNSeconds must be > 0 if Mode = CycleEveryNSeconds";
									else
										ok = true;
									break;
								case AgentIntervalMode.DailyAtSpecificTimes:
									schedule.CycleEveryNSeconds = 0;
									break;
							}

							if ( ok )
							{
								if ( string.IsNullOrEmpty( schedule.DaysOfWeek ) || "0123456".Contains( schedule.DaysOfWeek ) == false )
								{
									error = "Agent Schedule's Days Of Week must be represented as '0123456' or a portion of that range";
									ok = false;
								}
							}

							if ( ok && action == ACTION_ADD )
							{
								bool exists;
								if ( Data.TryGetAgentExists( model.Item.AgentId, out exists ) )
								{
									if ( exists )
									{
										error = "An agent already exists with that Id. Please pick another Id";
										ok = false;
									}
								}
								else
								{
									error = "There was an error trying to confirm if the new agent's ID exists. Please check the logs";
									ok = false;
								}
							}

							if ( ok )
							{
								model.Item.Schedule = schedule;
								if ( Data.TrySetAgent( model.Item ) )
									model.Item = null;
							}
						}
					}
					break;

				case ACTION_DELETE:

					if ( model.Item.AgentId <= 0 )
					{
						error = "Agent Id must be greater than zero";
					}
					else
					{
						if ( Data.TryDelAgent( model.Item.AgentId ) )
							model.Item = null;
					}

					break;
			}

			ModelAgentList newModel;
			Data.TryGetAgents( out newModel );
			if ( model.Item != null )
				newModel.Item = model.Item;
			newModel.Error = error;
			return View( newModel );
		}

		static bool IsPowerOfTwo( ulong x )
		{
			return ( x != 0 ) && ( ( x & ( x - 1 ) ) == 0 );
		}

		#endregion

		#region Agent Config

		[ActionDisplay("Agent Config")]
		public ActionResult AgentConfig()
		{
			ModelAgentConfigList model;
			Data.TryGetAgentConfig( out model );
			return View( model );
		}

		[HttpPost]
		public ActionResult AgentConfig( ModelAgentConfigList model )
		{
			if ( model == null || model.Item == null || string.IsNullOrEmpty( model.Action ) )
				return HubConfig();

			string error = string.Empty;

			switch ( model.Action.ToLower() )
			{
				case ACTION_ADD:
				case ACTION_UPDATE:

					if ( model.Item.AgentId <= 0 )
					{
						error = "Missing Agent Id";
					}
					if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Name missing";
					}
					else if ( string.IsNullOrEmpty( model.Item.Value ) )
					{
						error = "Value missing";
					}
					else if ( string.IsNullOrEmpty( model.Item.Description ) )
					{
						error = "Description missing";
					}
					else
					{
						if ( Data.TrySetAgentConfig( model.Item ) )
							model.Item = null;
					}
					break;

				case ACTION_DELETE:

					if ( model.Item.AgentId <= 0 )
					{
						error = "Missing Agent Id";
					}
					if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Name missing";
					}
					else
					{
						if ( Data.TryDelAgentConfig( model.Item ) )
							model.Item = null;
					}
					break;

			}

			ModelAgentConfigList newModel;
			Data.TryGetAgentConfig( out newModel );
			if ( model.Item != null )
				newModel.Item = model.Item;
			newModel.Error = error;
			return View( newModel );
		}

		#endregion

		#region Hub

		[ActionDisplay("Hub Config")]
		public ActionResult HubConfig()
		{
			ModelHubConfigList model;
			Data.TryGetHubConfig( out model );
			return View( model );
		}

		[HttpPost]
		public ActionResult HubConfig( ModelHubConfigList model )
		{
			if ( model == null || model.Item == null || string.IsNullOrEmpty( model.Action ) )
				return HubConfig();

			string error = string.Empty;

			switch ( model.Action.ToLower() )
			{
				case ACTION_ADD:
				case ACTION_UPDATE:

					if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Missing Name";
					}
					else if ( string.IsNullOrEmpty( model.Item.Value ) )
					{
						error = "Missing Value";
					}
					else if ( string.IsNullOrEmpty( model.Item.Description ) )
					{
						error = "Missing Description";
					}
					else
					{
						if ( Data.TrySetHubConfig( model.Item ) )
							model.Item = null;
					}
					break;

				case ACTION_DELETE:
					if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Missing Name";
					}
					else
					{
						if ( Data.TryDelHubConfig( model.Item.Name ) )
							model.Item = null;
					}
					break;
			}

			ModelHubConfigList newModel;
			Data.TryGetHubConfig( out newModel );
			if ( model.Item != null )
				newModel.Item = model.Item;
			newModel.Error = error;
			return View( newModel );
		}

		#endregion

		#region Agent Volatile

		[ActionDisplay("Agent Data")]
		public ActionResult AgentData()
		{
			ModelAgentDataList model;
			Data.TryGetAgentData( out model );
			return View( model );
		}

		[HttpPost]
		public ActionResult AgentData( ModelAgentDataList model )
		{
			if ( model == null || model.Item == null || string.IsNullOrEmpty( model.Action ) )
				return HubConfig();

			string error = string.Empty;

			switch ( model.Action.ToLower() )
			{
				case ACTION_ADD:
				case ACTION_UPDATE:

					if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Missing Item.Name";
					}
					else
					{
						if ( Data.TrySetAgentData( model.Item ) )
							model.Item = null;
					}
					break;

				case ACTION_DELETE:

					if ( model.Item.AgentId <= 0 )
					{
						error = "Missing Agent Id";
					}
					else if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Missing Item.Name";
					}
					else
					{
						if ( Data.TryDelAgentData( model.Item ) )
							model.Item = null;
					}
					break;
			}

			ModelAgentDataList newModel;
			Data.TryGetAgentData( out newModel );
			if ( model.Item != null )
				newModel.Item = model.Item;
			newModel.Error = error;
			return View( newModel );
		}

		#endregion

		#region Agent Config

		[ActionDisplay("Agent Status")]
		public ActionResult AgentStatus()
		{
			ModelAgentStatusList model;
			Data.TryGetAgentStatus( out model );
			return View( model );
		}

		#endregion

		#region Object Definitions

		[ActionDisplay("Object Definitions")]
		public ActionResult ObjectDefinitions()
		{
			ModelObjectDefinitionList model;
			Data.TryGetObjectDefinitions( out model );
			return View( "ObjectDefinitions", model );
		}

		[HttpPost]
		public ActionResult ObjectDefinitions( ModelObjectDefinitionList model )
		{
			if ( model == null || model.Item == null || string.IsNullOrEmpty( model.Action ) )
				return ObjectDefinitions();

			string error = string.Empty;

			string action = model.Action.ToLower();
			switch ( action )
			{
				case ACTION_ADD:
				case ACTION_UPDATE:

					if ( model.Item.ObjectId <= 0 )
					{
						error = "ObjectId must be greater than zero";
					}
					else if ( string.IsNullOrEmpty( model.Item.Name ) )
					{
						error = "Object Name is required";
					}
					else if ( string.IsNullOrEmpty( model.Item.Description ) )
					{
						error = "Object Description is required";
					}
					else
					{
						bool exists = false;

						if ( action == ACTION_ADD )
						{
							if ( Data.TryGetObjectDefinitionExists( model.Item.ObjectId, model.Item.Name, out exists ) )
							{
								if ( exists )
									error = "An Object already exists with that Id. Please pick another Id";
							}
							else
								error = "There was an error trying to confirm if the new object's ID exists. Please check the logs";
						}

						if ( string.IsNullOrEmpty( error ) )
						{
							if ( Data.TrySetObjectDefinition( model.Item ) )
								model.Item = null;
						}
					}
					break;

				case ACTION_DELETE:

					if ( model.Item.ObjectId <= 0 )
					{
						error = "Object Id must be greater than zero";
					}
					else
					{
						if ( Data.TryDelObjectDefinition( model.Item ) )
							model.Item = null;
					}
					break;
			}

			ModelObjectDefinitionList newModel;
			Data.TryGetObjectDefinitions( out newModel );
			if ( model.Item != null )
				newModel.Item = model.Item;
			newModel.Error = error;
			return View( newModel );
		}

		#endregion

		#region ObjectSequence

		[HttpPost]
		public ActionResult ObjectSequence( ModelObjectAgentSequenceList model )
		{
			if ( model == null || model.Item == null || string.IsNullOrEmpty( model.Action ) )
				return ObjectDefinitions();

			string error = string.Empty;
			string action = model.Action.ToLower();

			if ( model.Item.ObjectId <= 0 )
			{
				error = "ObjectId must be greater than zero";
			}
			else if ( model.Item.AgentId <= 0 )
			{
				error = "AgentId must be greater than zero";
			}
			else if ( model.Item.AgentId == model.Item.ParentId )
			{
				error = "AgentId and ParentId cannot match";
			}
			else
			{
				switch ( action )
				{
					case ACTION_ADD:
					case ACTION_UPDATE:

						if ( model.Item.ParentId <= 0 )
						{
							error = "ParentId must be greater than zero";
						}
						else
						{
							if ( Data.TrySetObjectSequence( model.Item ) )
								model.Item = null;
						}
						break;

					case ACTION_DELETE:

						if ( Data.TryDelObjectSequence( model.Item ) )
							model.Item = null;
						break;
				}
			}

			return RedirectToAction( "ObjectDefinitions" );
		}

		#endregion

		#region ObjectPermission

		[HttpPost]
		public ActionResult ObjectPermission( ModelObjectAgentSequenceList model )
		{
			if ( model == null || model.Item == null || string.IsNullOrEmpty( model.Action ) )
				return ObjectDefinitions();

			string error = string.Empty;
			string action = model.Action.ToLower();

			if ( model.Item.ObjectId <= 0 )
			{
				error = "ObjectId must be greater than zero";
			}
			else if ( model.Item.AgentId <= 0 )
			{
				error = "AgentId must be greater than zero";
			}
			else
			{
				switch ( action )
				{
					case ACTION_ADD:
					case ACTION_UPDATE:

						if ( Data.TrySetObjectPermission( model.Item.ObjectId, model.Item.AgentId, false ) )
							model.Item = null;
						break;

					case ACTION_DELETE:

						if ( Data.TrySetObjectPermission( model.Item.ObjectId, model.Item.AgentId, true ) )
							model.Item = null;
						break;
				}
			}

			return RedirectToAction( "ObjectDefinitions" );
		}

		#endregion
	}
}