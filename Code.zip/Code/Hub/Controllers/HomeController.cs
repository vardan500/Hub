﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.Controllers
{
	[ControllerDisplay("Home")]
	public class HomeController : BaseController
	{
		#region Index

		[AllowAnonymous]
		public ActionResult Index()
		{
			this.ViewBag.Hide = SessionState.AuthenticatedUser == null;

			if ( this.RouteData.DataTokens.ContainsKey( "error" ) )
				this.TempData["error"] = this.RouteData.DataTokens["error"];

			return View();
		}

		[HttpPost]
		[AllowAnonymous]
		public ActionResult Index( LoginModel model )
		{
			UserPermission permissions = UserPermission.None;
			if ( string.IsNullOrEmpty( model.Username ) == false && string.IsNullOrEmpty( model.Password ) == false )
				model.Successful = Data.TryLogin( model, out permissions );


			if ( model.Successful )
			{
				SessionState.AuthenticatedUser = new BasicUser( model.Username, model.Password, permissions );
				return Redirect( REDIRECT_ROOT );
			}
			else
			{
				this.ViewBag.Hide = SessionState.AuthenticatedUser == null;
				return View( model );
			}
		}

		#endregion

		#region Logout

		[AllowAnonymous]
		public ActionResult Logout()
		{
			System.Web.Security.FormsAuthentication.SignOut();
			Session.RemoveAll();
			return Redirect( REDIRECT_ROOT );
		}

		#endregion

		#region Error Trap

		[AllowAnonymous]
		public ActionResult Error()
		{
			return View( "Shared/Error" );
		}

		#endregion
	}
}
