﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace JDA.ITG.Flow.Hub
{
	// Note: For instructions on enabling IIS6 or IIS7 classic mode, 
	// visit http://go.microsoft.com/?LinkId=9394801

	public class MvcApplication : System.Web.HttpApplication
	{
		protected void Application_Start()
		{
			AreaRegistration.RegisterAllAreas();

			WebApiConfig.Register( GlobalConfiguration.Configuration );
			FilterConfig.RegisterGlobalFilters( GlobalFilters.Filters );
			RouteConfig.RegisterRoutes( RouteTable.Routes );
			BundleConfig.RegisterBundles( BundleTable.Bundles );

			#region our stuff

			Config.Load();					//gotta have config
			Log.Initialize();				//start logging
			Versionator.Check();		//make sure the db is on the same version as the code
			HostManager.Startup(); //start the background processor

			#endregion

		}

		protected void Application_Error()
		{
			Exception exception = Server.GetLastError();
			HttpException httpException = exception as HttpException;

			string error = string.Empty;

			if ( httpException != null )
			{
				RouteData routeData = new RouteData();
				routeData.Values.Add( "controller", "Home" );
				if ( httpException != null )
				{
					if ( httpException.GetHttpCode() == 404 )
					{
						routeData.DataTokens.Add( "error", "The request page doesn't exist" ); 
						routeData.Values.Add( "action", "Index" );
					}
					else
					{
						error = string.Format( "Global.asax caught the following HttpException: {0}, stack: {1}", exception.Message, exception.StackTrace ?? string.Empty );
						routeData.Values.Add( "action", "Error" );
					}
				}
				else
				{
					error = string.Format( "Global.asax caught the following HttpException: {0}, stack: {1}", exception.Message, exception.StackTrace ?? string.Empty );
				}

				if ( string.IsNullOrEmpty( error ) == false )
					Log.Error( error );


				Server.ClearError();
				Response.Clear();
				IController errorController = new Controllers.HomeController();
				errorController.Execute( new RequestContext( new HttpContextWrapper( this.Context ), routeData ) );
			}

		}
	}
}