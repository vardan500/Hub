﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JDA.ITG.Flow.Hub.API.Commands;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.API
{
	/// <summary>
	/// Handles the routing of http requests to the appropriate command object and invoking the command's execution
	/// </summary>
	public static class CommandRouter
	{
		#region Command

		/// <summary>
		/// Parse the incoming command (HTTP body), create the Command object instance to process the request, and execute it
		/// </summary>
		/// <param name="context"></param>
		/// <param name="commandType">The command object type to activate and invoke</param>
		public static void Route( HttpContext context, Type commandType )
		{
			long agentId;

			string 
				responseString = string.Empty,
				deserializeErrors = string.Empty,
				requestString = GetBody( context );

			RequestBase request = Serializer.Deserialize<RequestBase>( requestString, out deserializeErrors );

			//if the incoming request didn't serialize properly, 
			if ( request == null )
			{
				context.Response.StatusCode = (int)System.Net.HttpStatusCode.PreconditionFailed;
				context.Response.StatusDescription = "Incoming request was not a valid JSON request: " + deserializeErrors;
			}
			else if ( Authenticate( request, out agentId ) == false )
			{
				context.Response.StatusCode = (int)System.Net.HttpStatusCode.Unauthorized;
				context.Response.StatusDescription = "Invalid Credentials";
			}
			else if ( AgentExists( agentId ) == false )
			{
				context.Response.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
				context.Response.StatusDescription = "The Agent was not found in configuration, though credentials for the Agent exist. Please inspect the agent table";
			}
			else
			{
				//create the command object to process the request
				ICommand command = (ICommand)Activator.CreateInstance( commandType );

				//execute it
				CommandOutcome outcome = command.Process( requestString, out responseString );

				//return it
				context.Response.AddHeader( "Content-Length", responseString.Length.ToString() );
				context.Response.Write( responseString );
			}
		}

		#endregion

		#region Helpers

		/// <summary>
		/// Provdes basic authentication support for agent requests
		/// </summary>
		/// <param name="request">The incoming command request</param>
		/// <param name="agentId">The ID of the calling Agent</param>
		/// <returns></returns>
		static bool Authenticate( RequestBase request, out long agentId )
		{
			agentId = 0;

			//while this is a bit more expensive than I'd like...
			if ( request == null || string.IsNullOrEmpty( request.Username ) || string.IsNullOrEmpty( request.Password ) )
				return false;


			AgentConfigRecord record;
			if ( Config.AgentConfig.TryGetValue( request.AgentId, out record ) == false )
				return false;

			if ( record.User != null )
				agentId = record.User.AgentId;
			else
				return false;

			return record.User.Enabled;
		}

		static bool AgentExists( long agentId )
		{
			AgentConfigRecord config = null;
			Config.AgentConfig.TryGetValue( agentId, out config );
			return config != null;
		}

		/// <summary>
		/// Helper method to extract the POST body from the HTTP request
		/// </summary>
		/// <param name="context"></param>
		/// <returns></returns>
		static string GetBody( HttpContext context )
		{
			string data = string.Empty;
			if ( context.Request.ContentLength > 0 )
			{
				using ( System.IO.StreamReader sr = new System.IO.StreamReader( context.Request.InputStream ) )
				{
					data = sr.ReadToEnd();
				}
			}
			return data;
		}

		#endregion
	}
}