﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JDA.ITG.Flow.Hub.API
{
	public interface IBasicUser : System.Security.Principal.IIdentity
	{

		#region Properties

		string UserName { get; set; }
		string Password { get; set; }
		long AgentId { get; set; }

		#endregion

	}

	[Serializable]
	public class BasicUser : MarshalByRefObject, IBasicUser
	{

		#region Constructor

		public BasicUser()
		{
		}

		public BasicUser( string username, string password, long agentId )
		{
			this.UserName = username;
			this.Password = password;
			this.AgentId = agentId;
		}

		#endregion

		#region Properties

		public string UserName { get; set; }
		public string Password { get; set; }
		public string AuthenticationType { get { return "Custom"; } }
		public bool IsAuthenticated { get { return UserName != null; } }
		public string Name { get { return UserName; } }
		public long AgentId { get; set; }


		#endregion

	}
}