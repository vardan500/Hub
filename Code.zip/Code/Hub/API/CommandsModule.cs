﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;

namespace JDA.ITG.Flow.Hub.API
{
	/// <summary>
	/// An IHttpModule that intercepts incoming http requests and routes them to the /API subsystem if certain conditions are met
	/// </summary>
	public class CommandsModule : IHttpModule
	{
		#region declarations

		private static char[] HEADER_DELIMITOR = ":".ToCharArray();
		private static char[] AUTH_DELIMITOR   = " ".ToCharArray();
		private static char[] URL_DELIMITOR    = "/".ToCharArray();

		#endregion

		#region Properties

		public HttpContext Context { get; private set; }

		#endregion

		#region IHttpModule Members

		void IHttpModule.Dispose() { }

		void IHttpModule.Init( HttpApplication context )
		{
			context.BeginRequest += new EventHandler( OnBeginRequest );
			context.Error += new EventHandler( ErrorIntercept );
		}

		/// <summary>Handles unexpected errors</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void ErrorIntercept( object sender, EventArgs e )
		{
			var ex = this.Context.Server.GetLastError();
			if ( ex == null )
				return;
			Log.Exception( ex, "Pipline exception", "CommandsModule.ErrorIntercept" );
		}


		/// <summary>
		/// The core logic for the module. Examines the inbound request to see if it has a specific HTTP HEade,r is a POST, 
		/// and if the path matches a URI for a known command
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnBeginRequest( Object sender, EventArgs e )
		{
			HttpApplication app = sender as HttpApplication;

			//make sure we have a context + request
			if ( app.Context == null || app.Context.Request == null )
				return;

			//We'll need the context for subcalls
			this.Context = app.Context;

			//if we're not configured properly, we can't service ANYTHING. So tell the caller and get out
			if ( CanAcceptRequests() == false )
				return;

			//grab the last part of the url (that's the /[command] that we're looking for)
			string request = ( this.Context.Request.Url.PathAndQuery.Split( URL_DELIMITOR, StringSplitOptions.RemoveEmptyEntries ).FirstOrDefault() ?? string.Empty ).ToLower();

			// if the http request doesn't contain this header, it's not from an Agent
			if ( this.Context.Request.Headers.AllKeys.Contains( "JDA.ITG.FLOW" ) == false )
			{
				return;
			}
			else if ( string.IsNullOrEmpty( request ) )
			{
				//and there was no request url 
				CommandsModule.SendNotFound( this.Context );
				return;
			}

			switch ( this.Context.Request.HttpMethod.ToUpper() )
			{
				case "POST":

					//make sure there is data in the request (the command json is there)
					if ( this.Context.Request.ContentLength == 0 )
					{
						this.Context.Response.StatusCode = (int)System.Net.HttpStatusCode.PreconditionFailed;
						this.Context.Response.StatusDescription = "Missing Request Body";
					}
					else
					{
						//each command (e.g. HeartbeatRequest) has a RequestAttribute on it, representing the path the command is associated with.
						//This attribute is present in both the Agent and Hub codebases, and allows the agent and hub to communicate using specific 
						//commands on specific URIs. If there is no request attribute on the command, the command will never run
						var reqAttr = RequestAttribute.Paths.SingleOrDefault( c => c.Path == request );

						if ( reqAttr != null )
						{
							//next, identify which "command implementation class" will process the Command Request,
							//e.g., HeartbeatCommand.cs is assigned to process HeartbeatRequest.cs.
							//The CommandAttribute does for Commands like the RequestAttribute does for Command Requests.
							var command = Commands.CommandAttribute.Commands.SingleOrDefault( c => c.RequestType == reqAttr.RequestType );

							if ( command != null )
							{
								//we found a command class that will process the request - send it to the command router
								CommandRouter.Route( this.Context, command.CommandType );
							}
							else
							{
								CommandsModule.SendNotFound( this.Context );
							}
						}
					}

					RemoveHeaders( this.Context );

					//this must be here to ensure it doesn't hit the MVC
					this.Context.Response.End();


					break;

				default:
					CommandsModule.SendMethodNotAllowed( this.Context );
					break;
			}
		}

		#endregion

		#region Helpers
		
		static void RemoveHeaders( HttpContext context )
		{
			try
			{
				context.Response.Headers.Remove( "X-Powered-By" );
				context.Response.Headers.Remove( "X-AspNet-Version" );
				context.Response.Headers.Remove( "Server" );
			}
			catch ( Exception )
			{
				//this usually fires when running on dev iis or iis express
			}
		}

		/// <summary>
		/// Sends the not found headers to the user
		/// </summary>
		public static void SendNotFound( HttpContext context )
		{
			//context.Response.Clear();
			context.Response.StatusCode = (int)System.Net.HttpStatusCode.NotFound;
			context.Response.StatusDescription = "Not Found";
			RemoveHeaders( context );
			context.Response.End();
		}

		public static void SendMethodNotAllowed( HttpContext context )
		{
			context.Response.Clear();
			context.Response.StatusCode = (int)System.Net.HttpStatusCode.MethodNotAllowed;
			context.Response.StatusDescription = "Method Not Allowed - POST required";
			RemoveHeaders( context );
			context.Response.End();
		}

		public static void SendNotAuthorized( HttpContext context )
		{
			//context.Response.Clear();
			context.Response.StatusCode = (int)System.Net.HttpStatusCode.Unauthorized;
			context.Response.StatusDescription = "Invalid Credentials";
			RemoveHeaders( context );
			context.Response.End();
		}
		/// <summary>
		/// Make sure the service can accept request
		/// </summary>
		private bool CanAcceptRequests()
		{
			if ( Config.ProperlyConfigured == false )
			{
				this.Context.Response.Clear();
				this.Context.Response.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
				this.Context.Response.StatusDescription = "Server not configured properly. Please correct before continuing";
				this.Context.Response.Write( "Server not configured properly. Please correct before continuing" );
				this.Context.Response.Write( string.Join( Environment.NewLine, Config.ConfigurationErrors ) );
				this.Context.Response.Flush();
			}
			return true;
		}

		#endregion

	}
}