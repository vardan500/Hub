﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	internal interface ICommand
	{
		bool CanDoMultiple { get; }
		CommandOutcome Process( string requestString, out string responseString );
	}

	#region CommandAttribute

	[AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false )]
	internal class CommandAttribute : Attribute
	{
		internal readonly static List<CommandAttribute> Commands = new List<CommandAttribute>();

		static CommandAttribute()
		{
			var types = System.Reflection.Assembly.GetAssembly( typeof( ICommand ) ).GetTypes().Where( c => c.GetInterfaces().Contains( typeof( ICommand ) ) );
				
			foreach ( Type type in types )
			{
				CommandAttribute attr = (CommandAttribute)type.GetCustomAttributes( typeof( CommandAttribute ), false ).FirstOrDefault();
				if ( attr == null )
					continue;

				attr.CommandType = type;

				CommandAttribute.Commands.Add( attr );
			}
		}

		internal CommandAttribute( Type requestType )
		{
			this.RequestType = requestType;
		}

		internal Type RequestType { get; set; }
		internal Type CommandType { get; set; }

		static internal Type GetCommandForRequest<T>() where T : RequestBase
		{
			return CommandAttribute.Commands.FirstOrDefault( c => c.RequestType == typeof( T ) ).CommandType;
		}
	}

	#endregion

	#region CommandBase

	internal abstract class CommandBase<RQ,RS> : ICommand where RS : ResponseBase, new()
	{
		#region variables

		//keeps track of commands to prevent multiple calls at the same time for a command/agent combination
		static ConcurrentDictionary<long, bool> _runningCommands = new ConcurrentDictionary<long, bool>();

		#endregion

		#region Properties

		public virtual bool CanDoMultiple { get { return false; } }

		#endregion

		protected abstract void Process( RQ request, CommandOutcome outcome, out RS response );

		public CommandOutcome Process( string requestString, out string responseString )
		{
			responseString = string.Empty;
			CommandOutcome outcome = new CommandOutcome( this.GetType() );
			RS response = default( RS );

			//this check is done earlier, but just being safe
			if ( string.IsNullOrEmpty( requestString ) )
			{
				outcome.Set(
					CommandError.InvalidParameters,
					"Command '{0}': requestString is null or empty. Cannot process a command without an incoming request body",
					this.GetType().FullName );
			}
			else
			{
				//The request we'll build from the incoming request body
				RQ request = default( RQ );

				try
				{
					//let's build the request
					request = Serializer.Deserialize<RQ>( requestString );
				}
				catch ( Exception ex )
				{
					outcome.Set( CommandError.JsonSerializationError, "Message = {0}, Stack = {1}", ex.Message, ex.StackTrace ?? string.Empty );
				}

				if ( request == null )
				{
					outcome.Set(
						CommandError.JsonSerializationError,
						"Command '{0}': Unable to deserialize data in the request. Target type: '{1}', Data: '{2}'",
						this.GetType().FullName,
						typeof( RQ ).FullName,
						requestString );
				}
				else
				{
					long agentId = ( request as RequestBase ).AgentId;
					bool run = true;

					if ( this.CanDoMultiple == false )
						run = DoCommand( agentId );

					if ( run )
					{
						//invoke the command
						try
						{
							//execute the comand
							Process( request, outcome, out response );

							//sanity check - must have a response
							if ( response == null )
								outcome.Set( CommandError.NullCommandResponse, "The command didn't return a response... Big no-no!" );
						}
						catch ( Exception ex )
						{
							outcome.Set(
								CommandError.UnhandledCommandException,
								"The command didn't properly handle an exception condition. Message = {0}, Stack = {1}",
								ex.Message,
								ex.StackTrace ?? string.Empty );
						}
						finally
						{
							if ( this.CanDoMultiple == false )
								ReleaseCommand( agentId );
						}
					}
					else
					{
					}

				}
			}

			//Before we exit, we can log the outcome of a command call here ( to a database table, last 1000 in-memory list, etc, etc...)

			outcome.SaveErrorToLogs();

			//make SURE we have a response
			if ( response == null )
				response = new RS() { Error = outcome.Error, Message = outcome.Message };

			responseString = Serializer.Serialize( response );

			return outcome;
		}

		#region Helpers

		internal static bool DoCommand( long agentId )
		{
			if ( agentId == 0 )
				return true;

			return _runningCommands.TryAdd( agentId, true );
		}

		internal static void ReleaseCommand( long agentId )
		{
			bool b;
			_runningCommands.TryRemove( agentId, out b );
		}

		#endregion

		#region Encryption / Decryption

		public bool TryEncrypt( string unencrypted, out string encrypted )
		{
			if ( string.IsNullOrEmpty( unencrypted ) == false )
			{
				encrypted = Crypto.DBCrypto.Encryption( unencrypted );
				return true;
			}
			else
			{
				encrypted = unencrypted;
				return false;
			}
		}

		public bool TryDecrypt( string encrypted, out string unencrypted )
		{
			if ( string.IsNullOrEmpty( encrypted ) == false )
			{
				unencrypted = Crypto.DBCrypto.Decryption( encrypted );
				return true;
			}
			else
			{
				unencrypted = encrypted;
				return false;
			}
		}

		#endregion
	}

	#endregion

}