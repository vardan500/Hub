﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	[Command( typeof( WorkGetRequest ) )]
	internal class WorkGetCommand : CommandBase<WorkGetRequest, WorkGetResponse>
	{
		#region private variables

		const int MIN_ROWS = 1;
		const int MAX_ROWS = 100;
		const int FALLBACK = 10;

		#endregion

		#region Process

		protected override void Process( WorkGetRequest request, CommandOutcome outcome, out WorkGetResponse response )
		{
			response = new WorkGetResponse(){ Work = new AgentWork() };

			AgentConfigRecord acr;
			if( Config.AgentConfig.TryGetValue( request.AgentId, out acr ) )
			{
				if ( acr.Enabled == false )
				{
					return;
					//Log.Debug( () => "GetWorkCommand is disabled by config value 'Command.GetWork.Enabled' != true. Change the config value in sql to true to enable getting work" );
				}
			}

			Exception ex = null;
			int rows = FALLBACK;
			AgentConfigRecord config;

			if ( Config.AgentConfig.TryGetValue( request.AgentId, out config ) )
			{
				string str;
				if ( config.Settings != null && config.Settings.TryGetValue( Config.CONFIG_WORK_ROWS, out str ) )
				{
					if ( int.TryParse( str, out rows ) )
					{
						if ( rows < MIN_ROWS || rows > MAX_ROWS )
						{
							rows = FALLBACK;
							Log.Error(
								string.Format(
									"GetWorkCommand.Process's WorkRows for AgentId {0} is out the allowwed range of {1}-{2}, value = {3}. Defaulting to {4}",
									request.AgentId,
									MIN_ROWS,
									MAX_ROWS,
									rows,
									FALLBACK
									) );
						}
					}
					else
					{
						rows = FALLBACK;
						Log.Error(
							string.Format(
								"GetWorkCommand.Process's WorkRows for AgentId {0} is not a valid integer, value = {1}. Defaulting to {2}",
								request.AgentId,
								str,
								FALLBACK
								) );
					}
				}
			}

			using ( SqlConnection conn = new SqlConnection( Config.AppConnectionString ) )
			{
				try
				{
					conn.Open();

					using ( SqlCommand cmd = new SqlCommand( "DataGetWork", conn ) )
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.Add( new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = request.AgentId } );
						cmd.Parameters.Add( new SqlParameter( "rows", SqlDbType.Int ) { Value = rows } );

						using ( SqlDataReader reader = cmd.ExecuteReader() )
						{
							while ( reader.Read() )
							{
								int col = 0;
								string name = reader.GetString( col++ );
								string key = reader.GetString( col++ );
								bool encrypted = reader.GetBoolean( col++ );
								DateTime date = reader.GetDateTime( col++ );
								string json = reader.GetString( col++ );

								if ( string.IsNullOrEmpty( json ) == false )
								{
									if ( encrypted )
									{
										json = Crypto.DBCrypto.Decryption( json );
										json = Crypto.Compression.DecompressFromBase64( json );
									}

									try
									{
										response.Work.Add( new AgentWorkItem()
										{
											ObjectName = name,
											ObjectKey = key,
											Document = json ?? string.Empty
										} );
									}
									catch ( Exception e )
									{
										ex = e;
										break;
									}
								}
							}
						}
					}

				}
				catch ( Exception e )
				{
					ex = e;
				}
				finally
				{
					if ( conn.State != ConnectionState.Closed )
						conn.Close();
				}

				if ( ex != null )
				{
					Log.Exception( ex, "Error processing updated work", "GetWorkCommand.Process", request );
					response.Error = CommandError.SystemError;
					response.Message = "Unhandled exception thrown processing work. Please check the logs for method GetWorkCommand.Process";
					outcome.Set( CommandError.SystemError, response.Message );
				}
			}
		}

		#endregion

	}
}