﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	[Command( typeof( TestRequest ) )]
	internal class TestCommand : CommandBase<TestRequest, TestResponse>
	{
		protected override void Process( TestRequest request, CommandOutcome outcome, out TestResponse response )
		{
			response = new TestResponse() { Success = true };
		}
	}
}