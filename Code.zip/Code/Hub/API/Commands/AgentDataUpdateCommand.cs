﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	[Command( typeof( AgentDataUpdateRequest ) )]
	internal class AgentDataUpdateCommand : CommandBase<AgentDataUpdateRequest, AgentDataUpdateResponse>
	{
		protected override void Process( AgentDataUpdateRequest request, CommandOutcome outcome, out AgentDataUpdateResponse response )
		{
			response = new AgentDataUpdateResponse();

			Exception ex = null;

			using ( SqlConnection conn = new SqlConnection( Config.AppConnectionString ) )
			{
				try
				{
					conn.Open();

					#region Save new or updated inbound data

					if ( request.Items != null && request.Items.Count > 0 )
					{
						foreach( var item in request.Items.Where( c=> string.IsNullOrEmpty( c.Value ) == false ) )
						{
							using ( SqlCommand cmd = new SqlCommand( "AgentDataSet", conn ) )
							{
								cmd.CommandType = CommandType.StoredProcedure;
								cmd.Parameters.Add( new SqlParameter( "agentId", SqlDbType.BigInt ) );
								cmd.Parameters.Add( new SqlParameter( "name", SqlDbType.VarChar, 50 ) );
								cmd.Parameters.Add( new SqlParameter( "value", SqlDbType.VarChar, -1 ) );
								cmd.Parameters.Add( new SqlParameter( "encrypted", SqlDbType.Bit ) );
								cmd.Parameters.Add( new SqlParameter( "ttl", SqlDbType.Int ) );

								try
								{
									string value = item.Value ?? string.Empty;

									bool encrypted = false;
									if ( Config.EncryptData && string.IsNullOrEmpty( value ) == false )
									{
										encrypted = true;
										value = Crypto.Compression.CompressToBase64( value );
										value = Crypto.DBCrypto.Encryption( value );
									}

									cmd.Parameters[0].Value = request.AgentId;
									cmd.Parameters[1].Value = item.Key.ToUpper();
									cmd.Parameters[2].Value = value;
									cmd.Parameters[3].Value = encrypted;
									cmd.Parameters[4].Value = 0; //hard-coded for now. can refactor later
									cmd.ExecuteNonQuery();
								}
								catch ( Exception e )
								{
									ex = e;
									break;
								}
							}
						}

						foreach( var item in request.Items.Where( c=> string.IsNullOrEmpty( c.Value ) ) )
						{
							using ( SqlCommand cmd = new SqlCommand( "AgentDataDel", conn ) )
							{
								try
								{
								cmd.CommandType = CommandType.StoredProcedure;
								cmd.Parameters.Add( new SqlParameter( "agentId", SqlDbType.BigInt ){ Value = request.AgentId } );
								cmd.Parameters.Add( new SqlParameter( "name", SqlDbType.VarChar, 50 ){ Value = item.Key.ToUpper() } );
								cmd.ExecuteNonQuery();
								}
								catch ( Exception e )
								{
									ex = e;
									break;
								}
							}
						}
					}

					#endregion
					
				}
				catch ( Exception e )
				{
					ex = e;
				}
				finally
				{
					if ( conn.State != ConnectionState.Closed )
						conn.Close();
				}

				if ( ex != null )
				{
					Log.Exception( ex, "Error processing updated work", "UpdateAgentDataCommand.Process", request );
					response.Error = CommandError.SystemError;
					response.Message = "Unhandled exception thrown processing work. Please check the logs for method UpdateAgentDataCommand.Process";
					outcome.Set( CommandError.SystemError, response.Message );
				}
			}
		}
	}
}