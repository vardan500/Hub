﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	[Command( typeof( HeartbeatRequest ) )]
	internal class HeartbeatCommand : CommandBase<HeartbeatRequest, HeartbeatResponse>
	{
		protected override void Process( HeartbeatRequest request, CommandOutcome outcome, out HeartbeatResponse response )
		{
			response = new HeartbeatResponse();

			AgentConfigRecord config;
			if ( Config.AgentConfig.TryGetValue( request.AgentId, out config ) == false )
			{
				response.Error = CommandError.SystemError;
				response.Message = "Missing configuration for the Agent";
				return;
			}

			response.Enabled = config.Enabled;
			response.Schedule = config.Schedule;
			response.Settings = config.Settings;

			if ( request.AgentId <= 0 )
				return;

			if ( Models.Data.TryAgentCheckIn( request ) == false )
			{
				response.Error = CommandError.SystemError;
				response.Message = "Exception thrown running heartbeat. Please check the logs for method HeartbeatCommand.Process";
				outcome.Set( CommandError.SystemError, response.Message );
			}
		}
	}
}