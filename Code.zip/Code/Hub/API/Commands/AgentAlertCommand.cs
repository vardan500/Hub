﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	/// <summary>
	/// Supports
	/// </summary>
	[Command( typeof( AgentAlertRequest ) )]
	internal class AgentAlertCommand : CommandBase<AgentAlertRequest, ResponseBase>
	{
		protected override void Process( AgentAlertRequest request, CommandOutcome outcome, out ResponseBase response )
		{
			response = new ResponseBase();

			AgentConfigRecord config;
			if ( Config.AgentConfig.TryGetValue( request.AgentId, out config ) == false )
			{
				response.Error = CommandError.SystemError;
				response.Message = "Missing configuration for the Agent";
				return;
			}

			if ( request.AgentId <= 0 )
				return;

			switch ( request.Alert )
			{
				case AgentAlert.None:
					//ok then, why are we here??
					break;

				case AgentAlert.ErrorPostingUpdatedWork:

					//change the database status and in-memory status
					if ( Config.DisableAgent( request.AgentId ) == false )
					{
						response.Error = CommandError.SystemError;
						response.Message = "Unable to update the agent status. Please check the Data logs";
						outcome.Set( CommandError.SystemError, response.Message );
						return;
					}
					break;
			}


		}
	}
}