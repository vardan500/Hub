﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	[Command( typeof( AgentDataGetRequest ) )]
	internal class AgentDataGetCommand : CommandBase<AgentDataGetRequest, AgentDataGetResponse>
	{
		#region Process

		protected override void Process( AgentDataGetRequest request, CommandOutcome outcome, out AgentDataGetResponse response )
		{
			response = new AgentDataGetResponse() { Items = new AgentData() };

			Exception ex = null;

			DataTable tbl = new DataTable();
			tbl.Columns.Add( "key", typeof(string) );
			if ( request.Keys == null || request.Keys.Count == 0 )
			{
				response.Error = CommandError.InvalidParameters;
				response.Message = "Missing a list of keys to retrieve agent data for";
			}

			foreach ( var item in request.Keys )
				tbl.Rows.Add( item );

			using ( SqlConnection conn = new SqlConnection( Config.AppConnectionString ) )
			{
				try
				{
					conn.Open();

					using ( SqlCommand cmd = new SqlCommand( "AgentDataGet", conn ) )
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.Add( new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = request.AgentId } );
						cmd.Parameters.Add( new SqlParameter( "keys", SqlDbType.Structured ) { Value = tbl } );

						using ( SqlDataReader reader = cmd.ExecuteReader() )
						{
							while ( reader.Read() )
							{
								string name = reader.GetString( 0 ).ToUpper();
								string value = reader.GetString( 1 );
								bool encrypted = reader.GetBoolean( 2 );
								if ( encrypted )
								{
									value = Crypto.DBCrypto.Decryption( value );
									value = Crypto.Compression.DecompressFromBase64( value );
								}
								response.Items.Add( name, value );
							}
						}
					}

				}
				catch ( Exception e )
				{
					ex = e;
				}
				finally
				{
					if ( conn.State != ConnectionState.Closed )
						conn.Close();
				}

				if ( ex != null )
				{
					Log.Exception( ex, "Error processing updated work", "GetVolatileCommand.Process", request );
					response.Error = CommandError.SystemError;
					response.Message = "Unhandled exception thrown processing work. Please check the logs for method GetVolatileCommand.Process";
					outcome.Set( CommandError.SystemError, response.Message );
				}
			}
		}

		#endregion

	}
}