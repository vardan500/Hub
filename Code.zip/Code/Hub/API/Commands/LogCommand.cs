﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	[Command( typeof( LogRequest ) )]
	internal class LogCommand : CommandBase<LogRequest, ResponseBase>
	{
		public override bool CanDoMultiple { get { return true; } }

		protected override void Process( LogRequest request, CommandOutcome outcome, out ResponseBase response )
		{
			try
			{
				if ( request.Logs == null || request.Logs.Count == 0 )
				{
					response = new ResponseBase();
					return;
				}

				Exception ex = null;

				using ( SqlCommand cmd = new SqlCommand( "INSERT INTO logs VALUES( @d, @l, @m, @er, @ex, @ie, @st ); ", new SqlConnection( Config.LogConnectionString ) ) )
				{
					cmd.Parameters.Add( new SqlParameter( "d", SqlDbType.DateTime2 ) );
					cmd.Parameters.Add( new SqlParameter( "l", SqlDbType.Int ) );
					cmd.Parameters.Add( new SqlParameter( "m", SqlDbType.VarChar, 255 ) );
					cmd.Parameters.Add( new SqlParameter( "er", SqlDbType.VarChar, -1 ) );
					cmd.Parameters.Add( new SqlParameter( "ex", SqlDbType.VarChar, -1 ) );
					cmd.Parameters.Add( new SqlParameter( "ie", SqlDbType.VarChar, -1 ) );
					cmd.Parameters.Add( new SqlParameter( "st", SqlDbType.VarChar, -1 ) );

					try
					{
						cmd.Connection.Open();

						foreach ( var item in request.Logs )
						{
							cmd.Parameters[0].Value = item.Date;
							cmd.Parameters[1].Value = item.Level;
							cmd.Parameters[2].Value = item.Method ?? string.Empty;
							cmd.Parameters[3].Value = item.Error ?? string.Empty;
							cmd.Parameters[4].Value = item.Exception ?? string.Empty;
							cmd.Parameters[5].Value = item.InnerException ?? string.Empty;
							cmd.Parameters[6].Value = item.StackTrace ?? string.Empty;
							cmd.ExecuteNonQuery();
						}
					}
					catch ( Exception e )
					{
						ex = e;
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}
				}
			}
			catch { }
			
			response = new ResponseBase();

		}
	}
}