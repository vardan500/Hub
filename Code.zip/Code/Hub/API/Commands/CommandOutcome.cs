﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	/// <summary>
	/// Wrapper class to provide details of command execution, etc.
	/// </summary>
	internal class CommandOutcome
	{
		#region private variables

		//never return a null error message
		string _message = null;
		string _command = null;
		DateTime _started = DateTime.UtcNow;
		DateTime _finished = DateTime.UtcNow;

		#endregion

		#region Constructor

		public CommandOutcome( Type command )
		{
			if ( command == null )
				throw new InvalidOperationException( "Cannot create CommandOutcome without a valid Command Type passed in" );

			_command = command.Name;
		}

		#endregion

		#region Properties

		public CommandError Error { get; private set; }

		public string Message { get { return _message ?? string.Empty; } }

		public string Command { get { return _command; } }

		public double Duration { get { return Math.Round( _finished.Subtract( _started ).TotalSeconds, 3 ); } }

		#endregion

		#region Set overloads

		public void Set( CommandError error, string message = null )
		{
			this.Error = error;
			this._message = message ?? string.Empty;
			this._finished = DateTime.UtcNow;
		}

		public void Set( CommandError error, string message, params object[] args )
		{
			this.Error = error;
			this._finished = DateTime.UtcNow;

			try
			{
				this._message = string.Format( message, args );
			}
			catch ( Exception ex )
			{
				this._message = message;
				try
				{
					System.Text.StringBuilder sb = new System.Text.StringBuilder();
					sb.AppendLine( "The parameter string was improperly formatted: " );
					sb.AppendLine( "Original message: " + message ?? string.Empty );
					sb.AppendLine( "Parameters: " + string.Join( ",", args.Select( c => c.ToString() ) ) );
					sb.AppendLine( "Exception: " + ex.Message );
					sb.AppendLine( "Stack: " + ex.StackTrace ?? string.Empty );
					Log.Error( sb.ToString() );
				}
				catch
				{
					// if it fails here... oh well 
				}
			}
		}

		public void SaveErrorToLogs()
		{
			if ( this.Error != CommandError.None && this.Error != CommandError.None && string.IsNullOrEmpty( this.Message ) == false )
			{
				try
				{
					Log.Error( string.Format( "Command: {0}, Duration: {1}, Error: {2}", this.Command, this.Duration, this.Message ) );
				}
				catch { }
			}
		}

		#endregion

	}
}