﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub.API.Commands
{
	[Command( typeof( WorkUpdateRequest ) )]
	internal class WorkUpdateCommand : CommandBase<WorkUpdateRequest, WorkUpdateResponse>
	{
		protected override void Process( WorkUpdateRequest request, CommandOutcome outcome, out WorkUpdateResponse response )
		{
			response = new WorkUpdateResponse();

			bool	hasNew = false, hasWorked = false;

			if(request.Work == null)
				return;

			foreach( var item in request.Work )
			{
				if( string.IsNullOrEmpty( item.Document ) == false )
					hasNew = true;
				else
					hasWorked = true;
			}
			
			if ( hasNew == false && hasWorked == false )
			{
				return;
			}
			else if ( hasNew )
			{
				//verify the agent in question can submit this data
				string[] names = request.Work.Select( c => c.ObjectName ).Distinct().ToArray();
				foreach ( string name in names )
				{
					//make sure the agent is allowed to submit this item
					if ( Config.AgentCanSubmitObject( request.AgentId, name ) == false )
					{
						//set 
						response.Error = CommandError.AgentNotPermittedToSubmitObjectName;
						response.Message = string.Format( "Agent '{0}' does not have permission to submit object '{1}' (or object definition does not exist", request.AgentId, name );
						//log the error, 
						Log.Error( response.Message );
						//disable the agent (because it's coded to send stuff it isn't allowed to right now)
						Config.DisableAgent( request.AgentId );
						return;
					}
				}
			}

			Exception ex = null;

			using ( SqlConnection conn = new SqlConnection( Config.AppConnectionString ) )
			{
				try
				{
					conn.Open();

					#region Save new or updated inbound data

					if ( request.Work != null && request.Work.Exists( c=> string.IsNullOrEmpty( c.Document ) == false ) )
					{
						using ( SqlCommand cmd = new SqlCommand( "DataSet", conn ) )
						{
							cmd.CommandType = CommandType.StoredProcedure;
							cmd.Parameters.Add( new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = request.AgentId } );
							cmd.Parameters.Add( new SqlParameter( "objectName", SqlDbType.VarChar, 50 ) );
							cmd.Parameters.Add( new SqlParameter( "objectKey", SqlDbType.VarChar, 50 ) );
							cmd.Parameters.Add( new SqlParameter( "value", SqlDbType.VarChar, -1 ) );
							cmd.Parameters.Add( new SqlParameter( "encrypted", SqlDbType.Bit ) );
							cmd.Parameters.Add( new SqlParameter( "created", SqlDbType.Bit ) { Direction = ParameterDirection.Output } );

							try
							{
								foreach ( var item in request.Work.Where( c=> string.IsNullOrEmpty( c.Document ) == false ) )
								{
									if ( string.IsNullOrEmpty( item.ObjectKey ) == false && string.IsNullOrEmpty( item.Document ) == false )
									{
										string json = item.Document;
										//force encryption if we're doing a release build

										bool encrypted = false;
										if ( Config.EncryptData )
										{
											encrypted = true;
											json = Crypto.Compression.CompressToBase64( json );
											json = Crypto.DBCrypto.Encryption( json );
										}

										cmd.Parameters[1].Value = item.ObjectName;
										cmd.Parameters[2].Value = item.ObjectKey;
										cmd.Parameters[3].Value = json;
										cmd.Parameters[4].Value = encrypted;
										cmd.ExecuteNonQuery();
										if ( ( (bool)cmd.Parameters[5].Value ) == false )
										{
											//unable to insert the data. sql returned 0. abort and return an error
											response.Error = CommandError.SystemError;
											response.Message = "Unable to insert the data. Stored Procedure returned '0' for created. Please test this stored procedure";
											outcome.Set( CommandError.SystemError, response.Message );

											//Disable the Agent RIGHT NOW
											Models.Data.TryDisableAgent( request.AgentId );
											AgentConfigRecord acr;
											if ( Config.AgentConfig.TryGetValue( request.AgentId, out acr ) )
												acr.Enabled = false;

											return;
										}
									}
								}
							}
							catch ( Exception e )
							{
								ex = e;
							}
						}
					}

					#endregion
					
					#region update existing data as worked

					if ( request.Work != null && request.Work.Exists( c=> string.IsNullOrEmpty( c.Document ) ) )
					{
						using ( SqlCommand cmd = new SqlCommand( "DataWorkedByAgent", conn ) )
						{
							cmd.CommandType = CommandType.StoredProcedure;
							cmd.Parameters.Add( new SqlParameter( "agentId", SqlDbType.BigInt ) );
							cmd.Parameters.Add( new SqlParameter( "objectName", SqlDbType.VarChar, 50 ) );
							cmd.Parameters.Add( new SqlParameter( "objectKey", SqlDbType.VarChar, 50 ) );
							cmd.Parameters.Add( new SqlParameter( "success", SqlDbType.Bit ) );
							cmd.Parameters.Add( new SqlParameter( "error", SqlDbType.VarChar, -1 ) );
							cmd.Parameters[0].Value = request.AgentId;

							try
							{
								foreach ( var item in request.Work.Where( c=> c.Document == null ) )
								{
									if ( string.IsNullOrEmpty( item.ObjectName ) == false && string.IsNullOrEmpty( item.ObjectKey ) == false )
									{
										cmd.Parameters[1].Value = item.ObjectName;
										cmd.Parameters[2].Value = item.ObjectKey;
										cmd.Parameters[3].Value = item.Successful;
										cmd.Parameters[4].Value = item.Error ?? string.Empty;
										cmd.ExecuteNonQuery();
									}
								}
							}
							catch ( Exception e )
							{
								ex = e;
							}
						}
					}

					#endregion

				}
				catch ( Exception e )
				{
					ex = e;
				}
				finally
				{
					if ( conn.State != ConnectionState.Closed )
						conn.Close();
				}

				if ( ex != null )
				{
					Log.Exception( ex, "Error processing updated work", "UpdateWorkCommand.Process", request );
					response.Error = CommandError.SystemError;
					response.Message = "Unhandled exception thrown processing work. Please check the logs for method UpdateWorkCommand.Process";
					outcome.Set( CommandError.SystemError, response.Message );
				}
			}
		}
	}
}