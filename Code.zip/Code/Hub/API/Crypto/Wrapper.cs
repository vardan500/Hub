﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace JDA.ITG.Flow.Hub.API.Crypto
{
	class Wrapper
	{
		#region variables

		//the default is here as a fallback only
		private static byte[] _dbSeedV1 = null;
		private CipherV1 cipherDBV1 = null;

		#endregion

		#region constructor

		static Wrapper()
		{
			//DO NOT read this from the Config.GetAppSetting. That would allow someone to overwrite the encryption
			//by putting this in the database. This value must be set on the local server is the goal is to separate responsibilities.
			string configBytes = System.Configuration.ConfigurationManager.AppSettings.Get( "Encryption.Seed" );
			if ( string.IsNullOrEmpty( configBytes ) == false )
			{
				byte[] bytes = null;
				try
				{
					bytes = configBytes.Split( ",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries ).Select( c => Convert.ToByte( c ) ).ToArray();
				}
				catch
				{
				}

				if ( bytes != null && bytes.Length == 16 )
					_dbSeedV1 = bytes;
				else
					_dbSeedV1 = new byte[] { 21, 56, 40, 8, 51, 77, 96, 15, 79, 42, 11, 76, 32, 78, 63, 89, 84, 26, 38, 105, 33, 28, 123, 02 }; //default customized for JDA

				//an attempt to obfuscate the seed a little to avoid production staff from trying to take the seed and run...
				for ( int i = 0; i < _dbSeedV1.Length; i++ )
				{
					if ( i % 2 > 0 )
					{
						if ( _dbSeedV1[i] < 254 )
						{
							_dbSeedV1[i]++;
						}
						else
						{
							_dbSeedV1[i] = Convert.ToByte( Convert.ToInt32( _dbSeedV1[i] ) - ( 10 + i ) );
						}
					}
					else
					{
						if ( _dbSeedV1[i] > 1 )
						{
							_dbSeedV1[i]--;
						}
						else
						{
							_dbSeedV1[i] = Convert.ToByte( Convert.ToInt32( _dbSeedV1[i] ) + ( 8 + i ) );
						}
					}
				}



			}
		}

		#endregion

		#region Initialize

		private void InitializeDB()
		{
			if( cipherDBV1 == null )
				cipherDBV1 = new CipherV1( _dbSeedV1 );
		}


		#endregion

		#region Password

		public string PasswordHash( string password )
		{
			return Hash.CreateHash( password );
		}

		public bool PasswordVerify( string password, string goodHash )
		{
			return Hash.ValidatePassword( password, goodHash );
		}

		#endregion

		#region DB

		public string EncryptDB( string data )
		{
			InitializeDB();

			return( cipherDBV1.Encryption( data ) );
		}

		public byte[] EncryptDB( byte[] data )
		{
			InitializeDB();

			return( cipherDBV1.Encryption( data ) );
		}

		public string DecryptDB( string data )
		{
			InitializeDB();

			return( cipherDBV1.Decryption( data ) );
		}

		public byte[] DecryptDB( byte[] data )
		{
			InitializeDB();

			return( cipherDBV1.Decryption( data ) );
		}

		public List<string> EncryptDB( List<string> datas )
		{
			InitializeDB();

			return( cipherDBV1.Encryption( datas ) );
		}

		public List<string> DecryptDB( List<string> datas )
		{
			InitializeDB();

			return( cipherDBV1.Decryption( datas ) );
		}

		#endregion


	}
}
