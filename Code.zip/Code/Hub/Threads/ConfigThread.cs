﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Management;
using System.Management.Instrumentation;
using JDA.ITG.Flow;

namespace JDA.ITG.Flow.Hub
{
	internal class WorkThread : IServiceObject
	{

		#region Data Members

		private static DateTime _lastFetchAt        = DateTime.MinValue;

		private Thread _processorThread = null;
		private object _lock            = new object();

		#endregion

		#region Start/Shutdown

		public void Start()
		{
			Log.Info( () => "Manager starting" );

			//Startup the main process
			_processorThread = new Thread( new ThreadStart( Process ) );
			_processorThread.Start();
		}

		public void Shutdown()
		{
			Log.Info( () => "Manager stopping" );

			//We have a thread
			if ( _processorThread != null )
			{
				//Set quit event (not sure what good it does calling that here...)
				QuitEvent.Set();
			}

			//We have a thread
			if ( _processorThread != null )
			{
				//Wait for thread
				_processorThread.Join( 20 * 1000 );
			}
		}

		#endregion

		#region Main Processing

		private void Process()
		{
			try
			{
				WaitHandle[] handles = { QuitEvent.Get() };
				bool bContinue = true;

				Log.Info( () => "Manager thread started" );

				do
				{
					switch ( WaitHandle.WaitAny( handles, Config.ConfigRefreshInterval * 1000, false ) )
					{
						case 0:
							bContinue = false;
							break;

						default:
							Cycle();
							break;

					} //end of switch

				} while ( bContinue );
			}
			catch ( ThreadAbortException )
			{
			}
			catch ( Exception e )
			{
				Log.Exception( e, "Process Failed", "Manager.Process" );
			}

			Log.Info( () => "Manager thread stopped" );
		}

		#endregion

		#region Cycle

		private void Cycle()
		{
			Config.Reload();
		}

		#endregion

	}
}
