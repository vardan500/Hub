﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace JDA.ITG.Flow.Hub
{
	public static class ExtensionMethods
	{

		public static MvcHtmlString ListFor<TModel, TProperty>( this HtmlHelper<TModel> helper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null )
		{
			Dictionary<TProperty, string> dictionary = new Dictionary<TProperty, string>();
			foreach ( var v in Enum.GetValues( typeof( TProperty ) ) )
				dictionary.Add( (TProperty)v, v.ToString().Replace( "_", " " ) );

			dictionary = dictionary.OrderBy( c => c.Key ).ToDictionary( c => c.Key, c => c.Value );

			TProperty value = (TProperty)expression.Compile().Invoke( helper.ViewData.Model );
			var selectListItems = new SelectList( dictionary, "Key", "Value", value );
			return helper.DropDownListFor( expression, selectListItems, htmlAttributes );
		}

		public static MvcHtmlString ListOfAgents( this HtmlHelper helper, string name, long agentId, object htmlAttributes = null )
		{
			//this isn't the most efficient way to do this. ideally we'd fetch all the data in one call
			//or cache it... But, doing it this way for expediency. Performance comes after success

			Dictionary<long, string> dictionary = new Dictionary<long, string>();
			Models.ModelAgentList list;
			if ( Models.Data.TryGetAgents( out list ) )
			{
				if ( list != null && list.Items.Count > 0 )
				{
					foreach ( var item in list.Items.OrderBy( c => c.Name ) )
						dictionary.Add( item.AgentId, item.Name );
				}
			}

			var selectListItems = new SelectList( dictionary, "Key", "Value", agentId );
			return helper.DropDownList( name, selectListItems, htmlAttributes );
		}

		public static MvcHtmlString ListOfAgentsAndAll( this HtmlHelper helper, string name, long agentId, object htmlAttributes = null )
		{
			//this isn't the most efficient way to do this. ideally we'd fetch all the data in one call
			//or cache it... But, doing it this way for expediency. Performance comes after success

			Dictionary<long, string> dictionary = new Dictionary<long, string>();
			dictionary.Add( 0, "All" );

			Models.ModelAgentList list;
			if ( Models.Data.TryGetAgents( out list ) )
			{
				if ( list != null && list.Items.Count > 0 )
				{
					foreach ( var item in list.Items.OrderBy( c => c.Name ) )
						dictionary.Add( item.AgentId, item.Name );
				}
			}

			var selectListItems = new SelectList( dictionary, "Key", "Value", agentId );
			return helper.DropDownList( name, selectListItems, htmlAttributes );
		}

		public static MvcHtmlString ListOfObjectsAndAll( this HtmlHelper helper, string name, int objectId, object htmlAttributes = null )
		{
			//this isn't the most efficient way to do this. ideally we'd fetch all the data in one call
			//or cache it... But, doing it this way for expediency. Performance comes after success

			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			dictionary.Add( 0, "All" );

			Models.ModelObjectDefinitionList list;
			if ( Models.Data.TryGetObjectDefinitions( out list ) )
			{
				if ( list != null && list.Items.Count > 0 )
				{
					foreach ( var item in list.Items.OrderBy( c => c.Name ) )
						dictionary.Add( item.ObjectId, item.Name );
				}
			}

			var selectListItems = new SelectList( dictionary, "Key", "Value", objectId );
			return helper.DropDownList( name, selectListItems, htmlAttributes );
		}

	}
}