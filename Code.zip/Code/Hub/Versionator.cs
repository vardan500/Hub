﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using JDA.ITG.Flow.Hub.API;

namespace JDA.ITG.Flow.Hub
{
	#region Versionator

	public class Versionator
	{
		const int VERSION = 1;

		delegate bool VersionCheck( SqlCommand cmd, int currentVersion, out int newVersion );

		//the list of version methods to process
		static List<VersionCheck> Versions = new List<VersionCheck>(){
			//Version_1
		};

		public static void Check()
		{
			//don't bother if we don't have a connection string
			if ( string.IsNullOrEmpty( Config.AppConnectionString ) )
				return;

			try
			{
				using ( SqlCommand cmd = new SqlCommand( "", new SqlConnection( Config.AppConnectionString ) ) )
				{
					int version = 0;

					try
					{
						cmd.Connection.Open();

						cmd.CommandText = "select COUNT(1) from dbo.sysobjects where xtype = 'U' and name = 'dbversion'";
						cmd.CommandType = CommandType.Text;
						//first make sure we have a version table
						if ( ((int)cmd.ExecuteScalar()) == 0 )
						{
							cmd.CommandText = "CREATE TABLE [dbo].[dbversion]( [ID] [int] NOT NULL, [Version] [int] NOT NULL, CONSTRAINT [PK_dbversion] PRIMARY KEY CLUSTERED ( [ID] ASC ) );";
							cmd.ExecuteNonQuery();
							cmd.CommandText = "INSERT INTO [dbversion] VALUES( 1, 0 );";
							cmd.ExecuteNonQuery();
							version = 0;
						}
						else
						{
							cmd.CommandText = "SELECT [Version] from dbversion WHERE ID = 1";
							using ( SqlDataReader reader = cmd.ExecuteReader() )
							{
								if ( reader.Read() )
								{
									version = reader.GetInt32( 0 );
								}
							}
						}

						Upgrade( version, cmd );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Failed to run the Versionator upgrade", "Run" );
			}
		}

		static void Upgrade( int version, SqlCommand cmd )
		{
			if ( version == VERSION )
				return;

			int latestVersion = version;

			foreach ( var item in Versions )
			{
				int newVersion = 0;
				if ( item( cmd, newVersion, out newVersion ) == false )
					return;

				latestVersion = newVersion;
			}

			if ( latestVersion > version )
			{
				cmd.CommandText = "UPDATE dbversion SET Version = @v WHERE ID = 1";
				cmd.Parameters.Add( new SqlParameter( "v", SqlDbType.Int ) { Value = latestVersion } );
				cmd.ExecuteNonQuery();
			}

		}

		////Make sure the VERSION constant is >= 1 for this to run
		//static bool Version_1( SqlCommand cmd, int currentVersion, out int newVersion )
		//{
		//	newVersion = 1;
		//	if ( currentVersion >= newVersion )
		//		return true;

		//	try
		//	{
		//		cmd.CommandText = "ALTER TABLE dbo.siteUsers ADD ACL bigint NOT NULL CONSTRAINT DF_siteUsers_ACL DEFAULT 0;";
		//		cmd.ExecuteNonQuery();
		//		cmd.CommandText = "UPDATE siteUsers SET ACL = 511;";
		//		cmd.ExecuteNonQuery();
		//		cmd.CommandText = "ALTER TABLE dbo.siteUsers DROP CONSTRAINT DF_siteUsers_ACL;";
		//		cmd.ExecuteNonQuery();
		//		return true;
		//	}
		//	catch ( Exception ex )
		//	{
		//		Log.Exception( ex, "Failed to run the Versionator upgrade", "Version_1" );
		//		return false;
		//	}
		//}

	}

	#endregion
}