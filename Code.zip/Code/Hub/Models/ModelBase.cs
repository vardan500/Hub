﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JDA.ITG.Flow.Hub.Models
{
	public interface IModelBase
	{
		string Action { get; set; }
		string Error { get; set; }
	}

	public abstract class ModelBase<T> : IModelBase where T : new()
	{
		public ModelBase()
		{
			this.Item = new T();
			this.Items = new List<T>();
		}

		public void Add( T item )
		{
			this.Items.Add( item );
		}

		/// <summary>The results to a View</summary>
		public List<T> Items { get; set; }

		/// <summary>Convenient way to do something to a specific item in to a controller (the form can be coded for "Item.[Property Name]")</summary>
		public T Item { get; set; }

		/// <summary>If there is a post to take some CRUD action to the controller, do it here</summary>
		public string Action { get; set; }

		public string Error { get; set; }
	}
}