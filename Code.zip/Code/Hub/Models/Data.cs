﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace JDA.ITG.Flow.Hub.Models
{
	internal static class Data
	{
		#region Method: TryGetHubConfigComplex

		public static bool TryGetHubConfigComplex( 
			out Dictionary<string, string> hubConfig, 
			out Dictionary<long, AgentConfigRecord> agents, 
			out Dictionary<int, ModelObjectDefinition> objects,
			List<string> errors )
		{
			hubConfig = new Dictionary<string, string>();
			agents = new Dictionary<long, AgentConfigRecord>();
			objects = new Dictionary<int, ModelObjectDefinition>();

			using ( System.Data.SqlClient.SqlCommand cmd = new SqlCommand( "HubConfigLoad", new System.Data.SqlClient.SqlConnection( Config.AppConnectionString ) ) )
			{
				cmd.CommandType = CommandType.StoredProcedure;

				try
				{
					cmd.Connection.Open();

					using ( System.Data.SqlClient.SqlDataReader reader = cmd.ExecuteReader() )
					{
						#region Step #1 -> Load Hub Configuration

						long agentId = 0;

						while ( reader.Read() )
						{
							hubConfig.Add( reader.GetString( 0 ), reader.GetString( 1 ) );
						}

						#endregion

						#region Step #2 -> Load Agents

						if ( reader.NextResult() )
						{
							while ( reader.Read() )
							{
								agentId = reader.GetInt64( 0 );
								AgentConfigRecord acr = Models.Loaders.CreateAgentConfigRecord( reader );
								AgentConfigRecord existing;
								if ( agents.TryGetValue( agentId, out existing ) == false )
								{
									agents.Add( agentId, acr );
								}
								else
								{
									existing.Description = acr.Description;
									existing.Enabled = acr.Enabled;
									existing.Name = acr.Name;
									existing.Schedule = acr.Schedule;
								}
							}
						}

						if ( agents.ContainsKey( 0 ) == false )
						{
							//this agent exists to allow each agent EXE access to the default settings for all agents
							agents.Add( 0, new AgentConfigRecord()
							{
								AgentId = 0,
								Description = "Default Agent Config",
								Enabled = true,
								Name = "DefaultAgent",
								Schedule = null
							} );
						}

						#endregion

						#region Step #3 -> Load Agent Configuration

						if ( reader.NextResult() )
						{
							while ( reader.Read() )
							{
								long aid = reader.GetInt64( 0 );
								string key = reader.GetString( 1 );
								string val = reader.GetString( 2 );

								if ( aid == 0 )
								{
									//add the setting to each agent's setting (these are defaults)
									foreach ( var item in agents.Values )
										item.Settings.Add( key, val );
								}
								else
								{
									Models.AgentConfigRecord acr;
									if ( agents.TryGetValue( aid, out acr ) )
									{
										//overwrite the setting if already there (it's there because there was 
										//a record with that name but for agentId 0 (default), otherwise add it
										if ( acr.Settings.ContainsKey( key ) )
											acr.Settings[key] = val;
										else
											acr.Settings.Add( key, val );
									}
								}
							}
						}

						#endregion

						#region Step #4 -> Load Agent Users

						if ( reader.NextResult() )
						{
							while ( reader.Read() )
							{
								agentId = reader.GetInt64( 0 );
								AgentConfigRecord acr;
								if ( agents.TryGetValue( agentId, out acr ) )
									acr.User = Loaders.CreateAgentUserRecord( reader );
							}
						}

						#endregion

						#region Step #5 -> Load Object Definitions

						if ( reader.NextResult() )
						{
							while ( reader.Read() )
							{
								int objectId = reader.GetInt32( 0 );
								ModelObjectDefinition mod = Loaders.CreateModelObjectDefinition( reader );
								if ( objects.ContainsKey( objectId ) == false )
									objects.Add( objectId, mod );
								else
									objects[objectId] = mod;
							}
						}

						#endregion

					}
				}
				catch ( Exception ex )
				{
					errors.Add( "Exception while attempting to retrieve the configuration settings: " + ex.Message + ":" + ( ex.StackTrace ?? string.Empty ) );
					return false;
				}
				finally
				{
					if ( cmd.Connection.State != ConnectionState.Closed )
						cmd.Connection.Close();
				}
			}

			return errors.Count == 0;
		}

		#endregion

		#region Method: TryLogin

		public static bool TryLogin( LoginModel model, out UserPermission permissions )
		{
			bool result = false;
			permissions = UserPermission.None;

			try
			{
				using ( SqlCommand cmd = new SqlCommand( "AuthLogin", new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.CommandType = System.Data.CommandType.StoredProcedure;
					cmd.Parameters.Add( new SqlParameter( "u", System.Data.SqlDbType.VarChar, 255 ) { Value = model.Username } );
					cmd.Parameters.Add( new SqlParameter( "p", System.Data.SqlDbType.VarChar, 255 ) { Value = model.Password } );

					try
					{
						cmd.Connection.Open();
						using(SqlDataReader reader = cmd.ExecuteReader())
						{
							if ( reader.Read() )
							{
								permissions = (UserPermission)reader.GetInt64( 0 );
								result = true;
							}
						}
					}
					catch ( Exception ex )
					{
						Log.Exception( ex, "Attempting to query sql", "Login" );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Attempting to query sql", "Login" );
			}

			return result;
		}

		#endregion

		#region Method: TryGetAgents

		public static bool TryGetAgents( out ModelAgentList results )
		{
			results = null;
			return TryGetData<ModelAgentList, AgentConfigRecord>( "AgentGetAll", Loaders.CreateAgentConfigRecord, out results );
		}

		#endregion

		#region Method: TryGetAgentExists

		public static bool TryGetAgentExists( long agentId, out bool exists )
		{
			bool ok = false;
			exists = false;

			try
			{
				using ( SqlCommand cmd = new SqlCommand( "AgentExists", new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.Parameters.Add( new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = agentId } );
					cmd.CommandType = CommandType.StoredProcedure;
					try
					{
						cmd.Connection.Open();
						exists = ( (int)cmd.ExecuteScalar() ) > 0;
						ok = true;
					}
					catch ( Exception ex )
					{
						Log.Exception( ex, "Attempting to query sql", "TryGetAgentExists" );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Attempting to query sql", "TryGetAgentExists" );
			}

			return ok;
		}

		#endregion

		#region Method: TrySetAgent

		public static bool TrySetAgent( AgentConfigRecord agent )
		{
			return TrySetData( "AgentSet",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = agent.AgentId },
					new SqlParameter( "name", SqlDbType.VarChar, 255 ) { Value = agent.Name },
					new SqlParameter( "description", SqlDbType.VarChar, 255 ) { Value = agent.Description ?? string.Empty },
					new SqlParameter( "enabled", SqlDbType.Bit ) { Value = agent.Enabled },
					new SqlParameter( "schedule", SqlDbType.VarChar, -1 ) { Value = Serializer.Serialize( agent.Schedule ) }
				} );
		}

		#endregion

		#region Method: TryDisableAgent

		public static bool TryDisableAgent( long agentId )
		{
			return TrySetData( "AgentDisable",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = agentId },
				} );
		}

		#endregion

		#region Method: TryDelAgent

		public static bool TryDelAgent( long agentId )
		{
			return TrySetData( "AgentDel",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = agentId },
				} );
		}

		#endregion

		#region Method: TryGetAgentConfig

		public static bool TryGetAgentConfig( out ModelAgentConfigList results )
		{
			results = null;
			return TryGetData<ModelAgentConfigList, ModelAgentConfig>( "AgentConfigGetAll", Loaders.CreateModelAgentConfig, out results );
		}

		#endregion

		#region Method: TryGetAgentConfigForAgentId

		public static bool TryGetAgentConfigForAgentId( long agentId, out ModelAgentConfigList results )
		{
			results = null;
			var sqlparams = new SqlParameter[] { new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = agentId } };
			return TryGetData<ModelAgentConfigList, ModelAgentConfig>( "AgentConfigGetForAgentId", sqlparams, Loaders.CreateModelAgentConfig, out results );
		}

		#endregion

		#region Method: TrySetAgentConfig

		public static bool TrySetAgentConfig( ModelAgentConfig config )
		{
			return TrySetData( "AgentConfigSet",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = config.AgentId },
					new SqlParameter( "name", SqlDbType.VarChar, 255 ) { Value = config.Name },
					new SqlParameter( "value", SqlDbType.VarChar, -1 ) { Value = config.Value ?? string.Empty },
					new SqlParameter( "desc", SqlDbType.VarChar, 255 ) { Value = config.Name ?? string.Empty }
				} );
		}

		#endregion

		#region Method: TryDelAgentConfig

		public static bool TryDelAgentConfig( ModelAgentConfig config )
		{
			return TrySetData( "AgentConfigDel",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = config.AgentId },
					new SqlParameter( "name", SqlDbType.VarChar, 255 ) { Value = config.Name },
				} );
		}

		#endregion

		#region Method: TryGetAgentData

		public static bool TryGetAgentData( out ModelAgentDataList results )
		{
			results = null;
			return TryGetData<ModelAgentDataList, ModelAgentData>( "AgentDataGetAll", Loaders.CreateModelAgentData, out results );
		}

		#endregion

		#region Method: TryAgentDataGetForAgentId

		public static bool TryAgentDataGetForAgentId( long agentId, out ModelAgentDataList results )
		{
			results = null;
			var sqlparams = new SqlParameter[] { new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = agentId } };
			return TryGetData<ModelAgentDataList, ModelAgentData>( "AgentDataGetAll", sqlparams, Loaders.CreateModelAgentData, out results );
		}

		#endregion

		#region Method: TrySetAgentVolatile

		public static bool TrySetAgentData( ModelAgentData config )
		{
			return TrySetData( "AgentDataSet",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = config.AgentId },
					new SqlParameter( "name", SqlDbType.VarChar, 255 ) { Value = config.Name },
					new SqlParameter( "value", SqlDbType.VarChar, -1 ) { Value = config.Value ?? string.Empty },
					new SqlParameter( "ttl", SqlDbType.Int ) { Value = config.TTL }
				} );
		}

		#endregion

		#region Method: TryDelAgentData

		public static bool TryDelAgentData( ModelAgentData config )
		{
			return TrySetData( "AgentDataDel",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = config.AgentId },
					new SqlParameter( "name", SqlDbType.VarChar, 255 ) { Value = config.Name }
				} );
		}

		#endregion

		#region Method: TryGetAgentStatus

		public static bool TryGetAgentStatus( out ModelAgentStatusList results )
		{
			results = null;
			return TryGetData<ModelAgentStatusList, ModelAgentStatus>( "AgentStatusGetAll", Loaders.CreateModelAgentStatus, out results );
		}

		#endregion

		#region Method: TryGetObjectDefinitions

		public static bool TryGetObjectDefinitions( out ModelObjectDefinitionList results )
		{
			results = new ModelObjectDefinitionList();

			List<ModelObjectAgentSequence> sequences = new List<ModelObjectAgentSequence>();
			try
			{
				using ( SqlCommand cmd = new SqlCommand( "DataObjectGetAll", new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.CommandType = CommandType.StoredProcedure;
					try
					{
						cmd.Connection.Open();
						using ( SqlDataReader reader = cmd.ExecuteReader() )
						{
							while ( reader.Read() )
							{
								results.Add( Loaders.CreateModelObjectDefinition( reader ) );

							}

							if ( reader.NextResult() )
							{
								while ( reader.Read() )
								{
									sequences.Add( Loaders.CreateModelObjectAgentSequence( reader ) );
								}
							}

							if ( reader.NextResult() )
							{
								while ( reader.Read() )
								{
									results.AgentNames.Add( reader.GetInt64( 0 ), reader.GetString( 1 ) );
								}
							}

						}
					}
					catch ( Exception ex )
					{
						Log.Exception( ex, "Attempting to call sql", "TryGetObjectDefinitions" );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}

					if ( results.Items.Count > 0 && sequences.Count > 0 )
					{
						foreach ( var item in results.Items )
						{
							item.AgentSequence = sequences.Where( c => c.ObjectId == item.ObjectId ).OrderBy( c=> c.AgentName ).ToList();
						}
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Attempting to call sql", "TryGetObjectDefinitions" );
			}

			return results != null;
		}

		#endregion

		#region Method: TryGetObjectDefinitionExists

		public static bool TryGetObjectDefinitionExists( int objectId, string name, out bool exists )
		{
			bool ok = false;
			exists = false;

			try
			{
				using ( SqlCommand cmd = new SqlCommand( "DataObjectExists", new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.Parameters.Add( new SqlParameter( "objectId", SqlDbType.Int ) { Value = objectId } );
					cmd.Parameters.Add( new SqlParameter( "name", SqlDbType.VarChar, 50 ) { Value = name } );
					cmd.CommandType = CommandType.StoredProcedure;
					try
					{
						cmd.Connection.Open();
						exists = ( (int)cmd.ExecuteScalar() ) > 0;
						ok = true;
					}
					catch ( Exception ex )
					{
						Log.Exception( ex, "Attempting to query sql", "TryGetObjectDefinitionExists" );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Attempting to query sql", "TryGetObjectDefinitionExists" );
			}

			return ok;
		}

		#endregion

		#region Method: TrySetObjectDefinition

		public static bool TrySetObjectDefinition( ModelObjectDefinition model )
		{
			return TrySetData( "DataObjectSet",
				new SqlParameter[]{ 
					new SqlParameter( "objectId", SqlDbType.Int ) { Value = model.ObjectId },
					new SqlParameter( "name", SqlDbType.VarChar, 50 ) { Value = model.Name },
					new SqlParameter( "description", SqlDbType.VarChar, 255 ) { Value = model.Description ?? string.Empty },
					new SqlParameter( "agents", SqlDbType.BigInt ) { Value = model.Agents }
				} );
		}

		#endregion

		#region Method: TryDelObjectDefinition

		public static bool TryDelObjectDefinition( ModelObjectDefinition model )
		{
			return TrySetData( "DataObjectDel",
				new SqlParameter[]{ 
					new SqlParameter( "objectId", SqlDbType.Int ) { Value = model.ObjectId }
				} );
		}

		#endregion

		#region Method: TrySetObjectSequence

		public static bool TrySetObjectSequence( ModelObjectAgentSequence model )
		{
			return TrySetData( "DataObjectSequenceSet",
				new SqlParameter[]{ 
					new SqlParameter( "objectId", SqlDbType.Int ) { Value = model.ObjectId },
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = model.AgentId },
					new SqlParameter( "parentId", SqlDbType.BigInt ) { Value = model.ParentId },
				} );
		}

		#endregion
		
		#region Method: TrySetObjectPermission

		public static bool TrySetObjectPermission( int objectId, long agentId, bool removeAgent )
		{
			return TrySetData( "DataObjectPermissionSet",
				new SqlParameter[]{ 
					new SqlParameter( "objectId", SqlDbType.Int ) { Value = objectId },
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = agentId },
					new SqlParameter( "removeAgent", SqlDbType.Bit ) { Value = removeAgent }
				} );
		}

		#endregion

		#region Method: TryDelObjectSequence

		public static bool TryDelObjectSequence( ModelObjectAgentSequence model )
		{
			return TrySetData( "DataObjectSequenceDel",
				new SqlParameter[]{ 
					new SqlParameter( "objectId", SqlDbType.Int ) { Value = model.ObjectId },
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = model.AgentId },
					new SqlParameter( "parentId", SqlDbType.BigInt ) { Value = model.ParentId },
				} );
		}

		#endregion

		#region Method: TryGetHubConfig

		public static bool TryGetHubConfig( out ModelHubConfigList results )
		{
			results = null;
			return TryGetData<ModelHubConfigList, ModelHubConfig>( "HubConfigGetAll", Loaders.CreateModelHubConfig, out results );
		}

		#endregion

		#region Method: TrySetHubConfig

		public static bool TrySetHubConfig( ModelHubConfig config )
		{
			return TrySetData( "HubConfigSet",
				new SqlParameter[]{ 
					new SqlParameter( "name", SqlDbType.VarChar, 255 ) { Value = config.Name },
					new SqlParameter( "value", SqlDbType.VarChar, -1 ) { Value = config.Value ?? string.Empty },
					new SqlParameter( "desc", SqlDbType.VarChar, 255 ) { Value = config.Description ?? string.Empty }
				} );
		}

		#endregion

		#region Method: TryDelHubConfig

		public static bool TryDelHubConfig( string name )
		{
			return TrySetData( "HubConfigDel", new SqlParameter[]{ new SqlParameter( "name", SqlDbType.VarChar, 255 ) { Value = name } } );
		}

		#endregion

		#region Method: TryGetObjectSummary

		public static bool TryGetObjectSummary( out ModelObjectReportSummaryList results )
		{
			return TryGetData<ModelObjectReportSummaryList, ModelObjectReportSummary>( "DataGetObjectSummary", Loaders.CreateModelObjectReportSummary, out results );
		}

		#endregion

		#region Method: DataGetDetails

		public static bool TryGetDataGetDetails( ModelDataLookup model, bool incldueErrors, out ModelDataDetailsList results )
		{
			results = new ModelDataDetailsList() { Items = new List<ModelDataDetails>() };

			var sqlparams = new SqlParameter[]{ 
				new SqlParameter( "objectId", SqlDbType.Int ){ Value = model.ObjectId },
				new SqlParameter( "objectKey", SqlDbType.VarChar, 50 ){ Value = model.ObjectKey ?? string.Empty },
				new SqlParameter( "agentId", SqlDbType.BigInt ){ Value = model.AgentId },
				new SqlParameter( "includeErrors", SqlDbType.Bit ){ Value = incldueErrors }
			};

			try
			{
				Dictionary<string, ModelDataDetails> optimizer = new Dictionary<string, ModelDataDetails>();
				List<Tuple<int, string, long, DateTime, string>> errors = new List<Tuple<int, string, long, DateTime, string>>();

				using ( SqlCommand cmd = new SqlCommand( "DataGetDetails", new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.CommandType = CommandType.StoredProcedure;
					if ( sqlparams != null && sqlparams.Length > 0 )
						cmd.Parameters.AddRange( sqlparams );

					try
					{
						cmd.Connection.Open();
						using ( SqlDataReader reader = cmd.ExecuteReader() )
						{
							while ( reader.Read() )
							{
								var newItem = Loaders.CreateModelDataDetails( reader );
								//this is an optimizer to rip through a lot of data to add errors to the data details
								if ( incldueErrors )
									optimizer.Add( string.Format( "{0}:{1}", newItem.ObjectId, newItem.ObjectKey ), newItem );
								results.Items.Add( newItem );
							}

							if ( reader.NextResult() )
							{
								while ( reader.Read() )
								{
									results.ObjectNames.Add( reader.GetInt32( 0 ), reader.GetString( 1 ) );
								}
							}

							if ( reader.NextResult() )
							{
								while ( reader.Read() )
								{
									results.AgentNames.Add( reader.GetInt64( 0 ), reader.GetString( 1 ) );
								}
							}

							//data errors
							if ( incldueErrors && reader.NextResult() )
							{
								while ( reader.Read() )
								{
									errors.Add( new Tuple<int, string, long, DateTime, string>( reader.GetInt32( 0 ), reader.GetString( 1 ), reader.GetInt64( 2 ), reader.GetDateTime( 3 ), reader.GetString( 4 ) ) );
								}
							}
						}
					}
					catch ( Exception ex )
					{
						Log.Exception( ex, "Attempting to call sql", "TryGetDataGetErrorsForObjectAndAgent" );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}

					if ( results.Items.Count > 0 )
					{
						foreach ( var item in results.Items )
						{
							string name;
							if ( results.ObjectNames.TryGetValue( item.ObjectId, out name ) )
								item.ObjectName = name;
						}

						if ( errors.Count > 0 )
						{
							foreach ( var item in errors )
							{
								ModelDataDetails existing;
								if ( optimizer.TryGetValue( string.Format( "{0}:{1}", item.Item1, item.Item2 ), out existing ) )
								{
									ModelDataError err = new ModelDataError()
									{
										ObjectId = item.Item1,
										ObjectKey = item.Item2,
										AgentId = item.Item3,
										Updated = item.Item4,
										Error = item.Item5
									};

									string name;
									if ( results.ObjectNames.TryGetValue( err.ObjectId, out name ) )
										err.ObjectName = name;

									if ( results.AgentNames.TryGetValue( err.AgentId, out name ) )
										err.AgentName = name;

									existing.ErrorDetails.Add( err );
								}
							}
						}
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Attempting to call sql", "TryGetDataGetErrorsForObjectAndAgent" );
			}

			return results != null;
		}

		#endregion

		#region Method: DataGetErrorsForObjectAndAgent

		public static bool TryGetDataGetErrorsForObjectAndAgent( int objectId, long agentId, out ModelDataErrorList results )
		{
			results = new ModelDataErrorList() { Items = new List<ModelDataError>() };

			var sqlparams = new SqlParameter[]{ 
				new SqlParameter( "objectId", SqlDbType.Int ){ Value = objectId },
				new SqlParameter( "agentId", SqlDbType.BigInt ){ Value = agentId }
			};

			Dictionary<int, string> objectNames = new Dictionary<int, string>();
			Dictionary<long, string> agentNames = new Dictionary<long, string>();
			try
			{
				using ( SqlCommand cmd = new SqlCommand( "DataGetErrorsForObjectAndAgent", new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.CommandType = CommandType.StoredProcedure;
					if ( sqlparams != null && sqlparams.Length > 0 )
						cmd.Parameters.AddRange( sqlparams );

					try
					{
						cmd.Connection.Open();
						using ( SqlDataReader reader = cmd.ExecuteReader() )
						{
							while ( reader.Read() )
							{
								results.Add( Loaders.CreateModelDataError( reader ) );
							}

							if ( reader.NextResult() )
							{
								while ( reader.Read() )
								{
									objectNames.Add( reader.GetInt32( 0 ), reader.GetString( 1 ) );
								}
							}

							if ( reader.NextResult() )
							{
								while ( reader.Read() )
								{
									agentNames.Add( reader.GetInt64( 0 ), reader.GetString( 1 ) );
								}
							}
						}
					}
					catch ( Exception ex )
					{
						Log.Exception( ex, "Attempting to call sql", "TryGetDataGetErrorsForObjectAndAgent" );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}

					if ( results.Items.Count > 0 )
					{
						foreach ( var item in results.Items )
						{
							string name;
							if ( objectNames.TryGetValue( item.ObjectId, out name ) )
								item.ObjectName = name;

							if ( agentNames.TryGetValue( item.AgentId, out name ) )
								item.AgentName = name;
						}
					}
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Attempting to call sql", "TryGetDataGetErrorsForObjectAndAgent" );
			}

			return results != null;
		}

		#endregion

		#region Method: TryAgentCheckin()

		public static bool TryAgentCheckIn( HeartbeatRequest request )
		{
			return TrySetData( "AgentCheckin",
				new SqlParameter[]{ 
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = request.AgentId },
					new SqlParameter( "server", SqlDbType.VarChar, 50 ) { Value = request.ServerIp },
					new SqlParameter( "status", SqlDbType.Int ) { Value = (int)request.Status },
					new SqlParameter( "updated", SqlDbType.DateTime ) { Value = DateTime.UtcNow }
				} );

		}

		#endregion

		#region Method: TryGetModelObjectDefinitions

		public static bool TryGetModelObjectDefinitions( out ModelObjectDefinitionList results, bool includeSequences = false )
		{
			bool success = TryGetData<ModelObjectDefinitionList, ModelObjectDefinition>( "ObjectGetAll", Loaders.CreateModelObjectDefinition, out results );

			if ( includeSequences )
			{
				ModelObjectAgentSequenceList seq = null;
				if ( TryGetModelObjectDefinitions( out seq ) )
					if ( results.Items != null && seq != null && seq.Items != null )
						foreach ( var item in results.Items )
							item.AgentSequence = seq.Items.Where( c => c.ObjectId == item.ObjectId ).OrderBy( c => c.AgentName ).ThenBy( c => c.ParentId ).ToList();
			}

			return success;

		}

		#endregion

		#region Method: TryGetModelObjectDefinitions

		public static bool TryGetModelObjectDefinitions( out ModelObjectAgentSequenceList results )
		{
			return TryGetData<ModelObjectAgentSequenceList, ModelObjectAgentSequence>( "ObjectSequenceGetAll", Loaders.CreateModelObjectAgentSequence, out results );
		}

		#endregion

		#region Method: TryGetLogs

		public static bool TryGetLogs( ModelLogList model )
		{
			var sqlParams = new SqlParameter[]{ 
					new SqlParameter( "from", SqlDbType.DateTime2 ) { Value = model.From },
					new SqlParameter( "to", SqlDbType.DateTime2 ) { Value = model.To },
					new SqlParameter( "level", SqlDbType.Int ) { Value = (int)model.Level }
				};

			ModelLogList results;
			bool ok = TryGetData<ModelLogList, ModelLog>( "LogsGet", sqlParams, Loaders.CreateModelLog, out results );
			if ( results != null )
				model.Items = results.Items;
			return ok;
		}

		#endregion

		#region Method: TryDelLogs

		public static bool TryDelLogs( ModelLogList model )
		{
			var sqlParams = new SqlParameter[]{ 
					new SqlParameter( "from", SqlDbType.DateTime2 ) { Value = model.From },
					new SqlParameter( "to", SqlDbType.DateTime2 ) { Value = model.To },
					new SqlParameter( "level", SqlDbType.Int ) { Value = (int)model.Level }
				};

			return TrySetData( "LogsDel", sqlParams );
		}

		#endregion
		
		#region Method: TryClearErrors

		public static bool TryClearErrors( ModelDataLookup model )
		{
			var sqlParams = new SqlParameter[]{ 
					new SqlParameter( "objectId", SqlDbType.Int ) { Value = model.ObjectId },
					new SqlParameter( "objectKey", SqlDbType.VarChar, 50 ) { Value = model.ObjectKey ?? string.Empty },
					new SqlParameter( "agentId", SqlDbType.BigInt ) { Value = model.AgentId }
				};

			return TrySetData( "DataClearErrors", sqlParams );
		}

		#endregion


		#region Helper: TryGetData

		public static bool TryGetData<Li,Ty>( string storedProcedure, DataLoader<Ty> loader, out Li results ) where Li : ModelBase<Ty>, new() where Ty : new()
		{
			results = null;
			return TryGetData<Li, Ty>( storedProcedure, null, loader, out results );
		}

		public static bool TryGetData<Li,Ty>( string storedProcedure, IEnumerable<SqlParameter> parameters, DataLoader<Ty> loader, out Li results ) where Li : ModelBase<Ty>, new() where Ty : new()
		{
			results = null;

			try
			{
				using ( SqlCommand cmd = new SqlCommand( storedProcedure, new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.CommandType = CommandType.StoredProcedure;
					if ( parameters != null )
						cmd.Parameters.AddRange( parameters.ToArray() );
					try
					{
						cmd.Connection.Open();
						using ( SqlDataReader reader = cmd.ExecuteReader() )
						{
							while ( reader.Read() )
							{
								if ( results == null )
									results = new Li();

								results.Add( loader( reader ) );
							}
						}
					}
					catch ( Exception ex )
					{
						string method = new System.Diagnostics.StackTrace().GetFrame( 1 ).GetMethod().Name;
						Log.Exception( ex, "Attempting to query sql", method );
						return false;
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}
				}
			}
			catch ( Exception ex )
			{
				string method = new System.Diagnostics.StackTrace().GetFrame( 1 ).GetMethod().Name;
				Log.Exception( ex, "Attempting to query sql", method );
			}

			return results != null;
		}

		#endregion 

		#region Helper: TrySetData

		public static bool TrySetData( string storedProcedure, params SqlParameter[] parameters )
		{
			bool success = false;

			try
			{
				using ( SqlCommand cmd = new SqlCommand( storedProcedure, new SqlConnection( Config.AppConnectionString ) ) )
				{
					cmd.CommandType = CommandType.StoredProcedure;
					if ( parameters != null && parameters.Length > 0 )
						cmd.Parameters.AddRange( parameters );

					try
					{
						cmd.Connection.Open();
						cmd.ExecuteNonQuery();
						success = true;
					}
					catch ( Exception ex )
					{
						string method = new System.Diagnostics.StackTrace().GetFrame( 1 ).GetMethod().Name;
						Log.Exception( ex, "Attempting to call sql", method );
					}
					finally
					{
						if ( cmd.Connection.State != ConnectionState.Closed )
							cmd.Connection.Close();
					}
				}
			}
			catch ( Exception ex )
			{
				string method = new System.Diagnostics.StackTrace().GetFrame( 1 ).GetMethod().Name;
				Log.Exception( ex, "Attempting to call sql", method );
			}

			return success;
		}

		#endregion
	}
}