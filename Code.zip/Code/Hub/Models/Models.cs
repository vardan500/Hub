﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace JDA.ITG.Flow.Hub.Models
{
	#region LoginModel

	public class LoginModel
	{
		public string Username { get; set; }
		public string Password { get; set; }
		public bool Successful { get; set; }
	}

	#endregion

	#region AgentConfigRecord

	public class AgentConfigRecord
	{
		public AgentConfigRecord() { }
		public long AgentId { get; set; }
		public string Name { get; set; }
		public string Description { get; set; }
		public bool Enabled { get; set; }
		public AgentSchedule Schedule { get; set; }
		public AgentUserRecord User { get; set; }
		public readonly Dictionary<string, string> Settings = new Dictionary<string, string>();
	}

	#endregion

	#region AgentUserRecord

	public class AgentUserRecord
	{
		public long AgentId { get; set; }
		public string Username { get; set; }
		public string Password { get; set; }
		public bool Enabled { get; set; }
	}

	#endregion

	#region ModelAgentConfig

	public class ModelAgentConfig
	{
		public ModelAgentConfig() { }
		public long AgentId { get; set; }
		public string AgentName { get; set; }
		public string Name { get; set; }
		public string Value { get; set; }
		public string Description { get; set; }
	}

	#endregion

	#region ModelAgentStatus

	public class ModelAgentStatus
	{
		public ModelAgentStatus() { }
		public long AgentId { get; set; }
		public string AgentName { get; set; }
		public string Server { get; set; }
		public AgentStatus Status { get; set; }
		public DateTime Updated { get; set; }
	}

	#endregion

	#region ModelAgentData

	public class ModelAgentData
	{
		public ModelAgentData() { }
		public long AgentId { get; set; }
		public string AgentName { get; set; }
		public string Name { get; set; }
		public string Value { get; set; }
		public int TTL { get; set; }
		public DateTime Updated { get; set; }
	}

	#endregion

	#region ModelHubConfig

	public class ModelHubConfig
	{
		public ModelHubConfig() { }
		public string Name { get; set; }
		public string Value { get; set; }
		public string Description { get; set; }
	}

	#endregion

	#region ModelObjectSummary

	public class ModelObjectReportSummary
	{
		public ModelObjectReportSummary() { }
		public int ObjectId { get; set; }
		public string ObjectName { get; set; }
		public int Records { get; set; }
		public int Errors { get; set; }
		public DateTime LastObjectUpdated { get; set; }
	}

	#endregion

	#region ModelDataDetails

	public class ModelDataDetails
	{
		public ModelDataDetails() { }
		public int ObjectId { get; set; }
		public string ObjectName { get; set; }
		public string ObjectKey { get; set; }
		public long Agents { get; set; }
		public long Errors { get; set; }
		public DateTime Updated { get; set; }
		public readonly List<ModelDataError> ErrorDetails = new List<ModelDataError>();
	}

	#endregion

	#region ModelDataLookup

	public class ModelDataLookup
	{
		public ModelDataLookup() { }
		public int ObjectId { get; set; }
		public string ObjectKey { get; set; }
		public long AgentId { get; set; }
		public string Action { get; set; }
	}

	#endregion

	#region ModelDataError

	public class ModelDataError
	{
		public ModelDataError() { }
		public int ObjectId { get; set; }
		public string ObjectName { get; set; }
		public string ObjectKey { get; set; }
		public long AgentId { get; set; }
		public string AgentName { get; set; }
		public DateTime Updated { get; set; }
		public string Error { get; set; }
	}

	#endregion

	#region ModelObjectDefinition

	public class ModelObjectDefinition
	{
		public ModelObjectDefinition() { }
		public int ObjectId { get; set; }
		public string Name { get; set; }
		public string Description { get; set; }
		public long Agents { get; set; }
		public List<ModelObjectAgentSequence> AgentSequence { get; set; }
	}

	#endregion

	#region ModelObjectAgentSequence

	public class ModelObjectAgentSequence
	{
		public ModelObjectAgentSequence() { }
		public int ObjectId { get; set; }
		public long AgentId { get; set; }
		public long ParentId { get; set; }
		public string AgentName { get; set; }
		public string ParentName { get; set; }
	}

	#endregion

	#region ModelLog

	public class ModelLog
	{
		public ModelLog() { }
		public long Id { get; set; }
		public DateTime Date { get; set; }
		public LoggingLevel Level { get; set; }
		public string Method { get; set; }
		public string Error { get; set; }
		public string Exception { get; set; }
		public string InnerException { get; set; }
		public string StackTrace { get; set; }
	}

	#endregion


	public class ModelAgentConfigList : ModelBase<ModelAgentConfig> { }
	public class ModelAgentStatusList : ModelBase<ModelAgentStatus> { }
	public class ModelAgentDataList : ModelBase<ModelAgentData> { }
	public class ModelHubConfigList : ModelBase<ModelHubConfig> { }
	public class ModelObjectReportSummaryList : ModelBase<ModelObjectReportSummary> {	}
	public class ModelDataErrorList : ModelBase<ModelDataError> { }
	public class ModelObjectAgentSequenceList : ModelBase<ModelObjectAgentSequence> { }
	public class ModelAgentList : ModelBase<AgentConfigRecord> 
	{
		//using this to pass in the json'd schedule because it's a quick solution
		public string ScheduleString { get; set; }
	}
	public class ModelDataDetailsList : ModelBase<ModelDataDetails>
	{
		public readonly Dictionary<int, string> ObjectNames = new Dictionary<int, string>();
		public readonly Dictionary<long, string> AgentNames = new Dictionary<long, string>();
	}
	public class ModelObjectDefinitionList : ModelBase<ModelObjectDefinition> 
	{ 
		public readonly Dictionary<long, string> AgentNames = new Dictionary<long, string>();
	}
	public class ModelLogList : ModelBase<ModelLog> 
	{
		public DateTime From { get; set; }
		public DateTime To { get; set; }
		public LoggingLevel Level { get; set; }
	}
}