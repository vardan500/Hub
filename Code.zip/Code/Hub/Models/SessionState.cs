﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JDA.ITG.Flow.Hub.Models
{
	public static class SessionState
	{
		#region Session User

		public static BasicUser AuthenticatedUser
		{
			get
			{
				if ( System.Web.HttpContext.Current.Items["USER"] != null )
				{
					BasicUser user = (BasicUser)System.Web.HttpContext.Current.Items["USER"];
					if ( user == null )
					{
					}
					return user;
				}
				else
				{
					string json = System.Web.HttpContext.Current.Session["USER"] as string;
					if ( !string.IsNullOrEmpty( json ) )
					{
						BasicUser rs = Newtonsoft.Json.JsonConvert.DeserializeObject<BasicUser>( json );
						System.Web.HttpContext.Current.Items["USER"] = rs;
						return rs;
					}
					else
					{
						return null;
					}
				}
			}
			set 
			{
				string json = Newtonsoft.Json.JsonConvert.SerializeObject( value );
				System.Web.HttpContext.Current.Session["USER"] = json; 
			}
		}

		#endregion


	}

}