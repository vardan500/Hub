﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace JDA.ITG.Flow.Hub.Models
{
	public delegate T DataLoader<T>( SqlDataReader reader ) where T: new();

	internal static class Loaders
	{
		public static AgentUserRecord CreateAgentUserRecord( SqlDataReader reader )
		{
			return new AgentUserRecord()
			{
				AgentId = reader.GetInt64( 0 ),
				Username = reader.GetString( 1 ),
				Password = reader.GetString( 2 ),
				Enabled = reader.GetBoolean( 3 )
			};
		}

		public static AgentConfigRecord CreateAgentConfigRecord( SqlDataReader reader )
		{
			AgentConfigRecord rec = new AgentConfigRecord()
			{
				AgentId = reader.GetInt64( 0 ),
				Name = reader.GetString( 1 ),
				Description = reader.GetString( 2 ),
				Enabled = reader.GetBoolean( 3 )
			};

			string sched = reader.GetString( 4 );

			if ( string.IsNullOrEmpty( sched ) == false )
				rec.Schedule = Serializer.Deserialize<AgentSchedule>( sched );
			return rec;
		}

		public static ModelAgentConfig CreateModelAgentConfig( SqlDataReader reader )
		{
			return new ModelAgentConfig()
			{
				AgentId = reader.GetInt64( 0 ),
				AgentName = reader.GetString( 1 ),
				Name = reader.GetString( 2 ),
				Value = reader.GetString( 3 ),
				Description = reader.GetString( 4 ),
			};
		}

		public static ModelAgentData CreateModelAgentData( SqlDataReader reader )
		{
			return new ModelAgentData()
			{
				AgentId = reader.GetInt64( 0 ),
				AgentName = reader.GetString( 1 ),
				Name = reader.GetString( 2 ),
				Value = reader.GetString( 3 ),
				TTL = reader.GetInt32( 4 ),
				Updated = reader.GetDateTime( 5 )
			};
		}

		public static ModelAgentStatus CreateModelAgentStatus( SqlDataReader reader )
		{
			return new ModelAgentStatus()
			{
				AgentId = reader.GetInt64( 0 ),
				AgentName = reader.GetString( 1 ),
				Server = reader.GetString( 2 ),
				Status = (AgentStatus)reader.GetInt32( 3 ),
				Updated = reader.GetDateTime( 4 ),
			};
		}

		public static ModelHubConfig CreateModelHubConfig( SqlDataReader reader )
		{
			return new ModelHubConfig()
			{
				Name = reader.GetString( 0 ),
				Value = reader.GetString( 1 ),
				Description = reader.GetString( 2 )
			};
		}

		public static ModelObjectReportSummary CreateModelObjectReportSummary( SqlDataReader reader )
		{
			return new ModelObjectReportSummary()
			{
				ObjectId = reader.GetInt32( 0 ),
				ObjectName = reader.GetString( 1 ),
				Records = reader.GetInt32( 2 ),
				Errors = reader.GetInt32( 3 ),
				LastObjectUpdated = reader.GetDateTime( 4 )
			};
		}

		public static ModelDataDetails CreateModelDataDetails( SqlDataReader reader )
		{
			return new ModelDataDetails()
			{
				ObjectId = reader.GetInt32( 0 ),
				ObjectKey = reader.GetString( 1 ),
				Updated = reader.GetDateTime( 2 ),
				Agents = reader.GetInt64( 3 ),
				Errors = reader.GetInt64( 4 )
			};
		}

		public static ModelDataError CreateModelDataError( SqlDataReader reader )
		{
			return new ModelDataError()
			{
				ObjectId = reader.GetInt32( 0 ),
				ObjectKey = reader.GetString( 1 ),
				AgentId = reader.GetInt64( 2 ),
				Updated = reader.GetDateTime( 3 ),
				Error = reader.GetString( 4 )
			};
		}

		public static ModelObjectDefinition CreateModelObjectDefinition( SqlDataReader reader )
		{
			return new ModelObjectDefinition()
			{
				ObjectId = reader.GetInt32( 0 ),
				Name = reader.GetString( 1 ),
				Description = reader.GetString( 2 ),
				Agents = reader.GetInt64( 3 )
			};
		}

		public static ModelObjectAgentSequence CreateModelObjectAgentSequence( SqlDataReader reader )
		{
			return new ModelObjectAgentSequence()
			{
				ObjectId = reader.GetInt32( 0 ),
				AgentId = reader.GetInt64( 1 ),
				ParentId = reader.GetInt64( 2 ),
				AgentName = reader.IsDBNull( 3 ) == false ? reader.GetString( 3 ) : string.Empty,
				ParentName = reader.IsDBNull( 4 ) == false ? reader.GetString( 4 ) : string.Empty
			};
		}

		public static ModelLog CreateModelLog( SqlDataReader reader )
		{
			int i = 0;
			return new ModelLog()
			{
				Id = reader.GetInt64( i++ ),
				Date = reader.GetDateTime( i++ ),
				Level = (LoggingLevel)reader.GetInt32( i++ ),
				Method = reader.GetString( i++ ),
				Error = reader.GetString( i++ ),
				Exception = reader.GetString( i++ ),
				InnerException = reader.GetString( i++ ),
				StackTrace = reader.GetString( i++ )
			};
		}
	}
}