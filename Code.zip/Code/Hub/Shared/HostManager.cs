﻿/************************************************************************* 
* RONIN LLC
* Copyright (C) 2012 Matthew Aman
* 
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* 
*************************************************************************/

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
//using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace JDA.ITG.Flow
{
	public class HostManager
	{
		#region Data Members

		private static bool _OK = true;

		private static BlockingCollection<Thread>         _threads       = new BlockingCollection<Thread>();
		private static BlockingCollection<IServiceObject> _processes     = new BlockingCollection<IServiceObject>();

		#endregion

		#region Properties

		public static int ProcessCount { get{ return( _processes.Count );	}	}

		#endregion

		#region Delegates/Events

		protected delegate void StartupProcess();

		#endregion

		#region stupid

		public static void SSLCertificateBypass()
		{
			//Handle https
			System.Net.ServicePointManager.ServerCertificateValidationCallback +=
				delegate( object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate,
									System.Security.Cryptography.X509Certificates.X509Chain chain,
									System.Net.Security.SslPolicyErrors sslPolicyErrors ) { return true; };
		}

		#endregion

		#region Startup/Shutdown

		public static void Startup()
		{
			Log.Info( ()=> "HostManager startup" );

			StartupStep( StartupThreads );
		}

		public static void Shutdown()
		{
			Log.Info( ()=> "HostManager shutdown" );

			//Signal the global shutdown event.
			QuitEvent.Set();

			ShutdownStep( ShutdownThreads );
		}

		#endregion

		#region Startup Pipeline Methods

		private static void StartupThreads()
		{
			const string METHOD = "MX.Hosting.HostManager.StartupThreads";

			Type[] types = System.Reflection.Assembly.GetExecutingAssembly().GetTypes().ToArray();

			foreach ( Type t in types )
			{
			  if ( t.GetInterfaces().Count( c => c == typeof( IServiceObject ) ) > 0 )
			  {
					if ( t.IsAbstract || t.IsInterface )
					{
					}
					else
					{
						IServiceObject process = (IServiceObject)Activator.CreateInstance( t );
						_processes.Add( process );

						Thread thread = new Thread( new ThreadStart( process.Start ) )
															{
																Name = t.FullName,
																IsBackground = true
															};

						_threads.Add( thread );
					}
			  }
			}

			foreach ( Thread t in _threads )
			{
				try
				{
					t.Start();
				}
				catch ( Exception ex )
				{
					Log.Exception( ex, "Hosting startup thread failed", METHOD, "StartupThreads" );
				}
			} //end of for
		}

		protected static void StartupStep( StartupProcess process )
		{
			try
			{
				if ( _OK )
					process.Invoke();
			}
			catch ( Exception ex )
			{
				_OK = false;

				Log.Exception( ex, "Hosting startup step failed", "StartupStep", process );
			}
		}

		#endregion

		#region Shutdown Pipeline Methods

		private static void ShutdownThreads()
		{
			foreach ( IServiceObject process in _processes )
			{
				try
				{
					process.Shutdown();
				}
				catch { }
			} //end of for

			foreach ( Thread thread in _threads )
			{
				try
				{
					thread.Join( 10 * 1000 );
				}
				catch { }
			} //end of for
		}

		protected static void ShutdownStep( StartupProcess process )
		{
			try
			{
				process.Invoke();
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Hosting shutdown step failed", "ShutdownStep", process );
			}
		}

		#endregion
	}
}
