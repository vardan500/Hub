﻿using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using Newtonsoft.Json.Linq;
using JDA.ITG.Flow.Hub;

namespace JDA.ITG.Flow
{
	public static class Log
	{

		#region Data Members

		private static object _emergencyLock = new object();
		private static ConcurrentDictionary<string, AlertHistory> _alertHistory = new ConcurrentDictionary<string, AlertHistory>( StringComparer.CurrentCultureIgnoreCase );

		#endregion

		#region Properties

		private static bool EmergencyAlertFlag { get; set; }

		public static Exception InitializeException { get; private set; }
		public static Exception AdoException { get; private set; }
		public static string Application { get { return "HUB"; } }

		public static bool IsDebugEnabled { get { return Config.LoggingLevel >= LoggingLevel.DEBUG; } }
		public static bool IsInfoEnabled { get { return Config.LoggingLevel >= LoggingLevel.INFO; } }
		public static bool IsWarnEnabled { get { return Config.LoggingLevel >= LoggingLevel.WARN; } }
		public static bool IsExceptionEnabled { get { return Config.LoggingLevel >= LoggingLevel.EXCEPTION; } }
		public static bool IsErrorEnabled { get { return Config.LoggingLevel >= LoggingLevel.ERROR; } }

		private static ServiceStack.Logging.ILog LOG = null;

		#endregion

		#region Initialize

		public static void Initialize()
		{
			string path = System.Configuration.ConfigurationManager.AppSettings.Get( "log4net" );
			try
			{

				if ( string.IsNullOrEmpty( path ) == false && System.IO.File.Exists( path ) )
				{
					var factory = new ServiceStack.Logging.Log4Net.Log4NetFactory( path ); //Also runs log4net.Config.XmlConfigurator.Configure()
					LOG = factory.GetLogger( typeof( DefaultLog ) );
				}
			}
			catch
			{
				throw;
			}


			try
			{
				using ( SqlConnection conn = new SqlConnection( Config.LogConnectionString ) )
				{
					conn.Open();
					conn.Close();
				}
			}
			catch ( Exception ex )
			{
				if ( LOG != null )
				{
					LOG.Error( "Log.Initialize() Exception connecting to the logs database: " + ex.Message );
				}
			}
		}

		#endregion

		#region Exception

		public static void Exception( Exception e, string error, string method, params object[] parameters )
		{
			Exception( e, error, method );
		}

		private static void Exception( Exception e, string error, string method )
		{
			try
			{
				if ( IsExceptionEnabled )
				{
					LogEntry(
						LoggingLevel.ERROR,
						method,
						error,
						e.Message,
						e.InnerException != null ? e.InnerException.Message : string.Empty,
						e.StackTrace != null ? ( e.StackTrace ?? string.Empty ).Replace( System.Environment.NewLine, "" ) : string.Empty );
				}
			}
			catch { }
		}

		#endregion

		#region Error

		public static void Error( Func<string> invokeError, Func<string> invokeMethod )
		{
			try
			{
				if ( IsErrorEnabled )
				{
					LogEntry(
						LoggingLevel.ERROR,
						invokeMethod(),
						invokeError() );
				}
			}
			catch { }
		}

		public static void Error( Func<string> invokeMsg )
		{
			Error( invokeMsg, null );
		}

		public static void Error( string error )
		{
			try
			{
				if ( IsErrorEnabled )
				{
					LogEntry(
						LoggingLevel.ERROR,
						string.Empty,
						error );
				}
			}
			catch { }
		}

		#endregion

		#region Debug

		public static void Debug( Func<string> invocation )
		{
			try
			{
				if ( IsDebugEnabled )
				{
					LogEntry(
						LoggingLevel.DEBUG,
						string.Empty,
						invocation() );
				}
			}
			catch { }
		}

		public static void Debug( string msg )
		{
			try
			{
				if ( IsDebugEnabled )
				{
					LogEntry(
						LoggingLevel.DEBUG,
						string.Empty,
						msg,
						string.Empty,
						string.Empty,
						string.Empty );
				}
			}
			catch { }
		}

		#endregion

		#region Info

		public static void Info( Func<string> invocation )
		{
			try
			{
				if ( IsInfoEnabled )
				{
					LogEntry(
						LoggingLevel.INFO,
						string.Empty,
						invocation() );
				}
			}
			catch { }
		}

		#endregion

		#region Warn

		public static void Warn( Func<string> invocation )
		{
			try
			{
				if ( IsWarnEnabled )
				{
					LogEntry(
						LoggingLevel.ERROR,
						string.Empty,
						invocation() );
				}
			}
			catch { }
		}

		#endregion

		#region EmergencyAlert

		/*
		 * CRITICAL UNDERSTANDING OF THE Emergency Alert errors
		 * Since the emergency alert message is called when there are ADO errors we have to setup
		 * a thread context flag while we are processing the emergency alert.  
		 * (EmergencyAlertFlag) is the property that maintains this information.  We are using the
		 * Log4Net ThreadContext container to maintain this information
		 */

		public static void EmergencyAlert( string format, params object[] arguments )
		{
			EmergencyAlert( true, format, arguments );
		}

		public static void EmergencyAlert( bool logError, string format, params object[] arguments )
		{
			const string METHOD = "Shared.Log.EmergencyAlert";

			try
			{
				string msg = format;
				AlertHistory oldAlert = null;

				lock ( _emergencyLock )
				{
					//If this thread already in an emergency alert, then get out
					if ( EmergencyAlertFlag )
					{
						//We shouldn't ever see this.
						return;
					}

					//Flag we are in the emergency alert method
					EmergencyAlertFlag = true;
				}

				//Parse arguments
				if ( arguments != null && arguments.Length > 0 )
				{
					try
					{
						msg = string.Format( format, arguments );
					}
					catch
					{
						msg = "Error parsing format. format: " + format + ", Args: " + string.Join( " -- ", arguments );
					}
				}

				//Always log as error so we capture the alert also.
				if ( logError )
					Log.Error( () => string.Format( "Emergency Alert: {0}", msg ) );

				if(Config.SmtpInfo == null || Config.SmtpInfo.Enabled == false )
					return;

				EmailRequest email = null;
				//SMSRequest   sms   = null;

				//Build the email request
				email = new EmailRequest()
				{
					Recipient = Config.SmtpInfo.Recipients,
					Subject = "System Error",
					Body = msg,
					Format = EmailFormatType.TEXT
				};

				//If we have data.
				if ( email != null )
				{
					//We have a delay setup
					if ( Config.SmtpInfo.Delay > 0 )
					{
						//--------------------------
						//First check to see if this exact alert has been fired recently
						if ( _alertHistory.TryGetValue( msg, out oldAlert ) )
						{
							lock ( oldAlert )
							{
								//If expired, then update time
								if ( oldAlert.Sent.AddSeconds( Config.SmtpInfo.Delay ) <= DateTime.UtcNow )
									oldAlert.Sent = DateTime.UtcNow;
								//Otherwise get out, since we sent this one recently.
								else
									return;
							}
						}
						else
						{
							oldAlert = new AlertHistory() { Sent = DateTime.UtcNow };
							_alertHistory.AddOrUpdate( msg, oldAlert, ( k, v ) => oldAlert );
						}
					}

					//Invoke the event
					System.Net.Mail.MailMessage mailMsg = new MailMessage()
					{
						Subject = "Online Payments ACH - Emergency Alert",
						Body = msg,
						SubjectEncoding = System.Text.Encoding.UTF8,
						BodyEncoding = System.Text.Encoding.UTF8,
						From = new MailAddress( Config.SmtpInfo.From, Config.SmtpInfo.From, System.Text.Encoding.UTF8 ),
						IsBodyHtml = false,
						Sender = new MailAddress( Config.SmtpInfo.From ),
					};

					mailMsg.To.Add( Config.SmtpInfo.Recipients );

					System.Net.Mail.SmtpClient client = new SmtpClient()
					{
						Credentials = new System.Net.NetworkCredential( Config.SmtpInfo.Username, Config.SmtpInfo.Password ),
						EnableSsl = Config.SmtpInfo.UseSSL,
						Host = Config.SmtpInfo.Host,
						Port = Config.SmtpInfo.Port,
						Timeout = Config.SmtpInfo.Timeout * 1000,
					};

					try
					{
						client.Send( mailMsg );
					}
					catch ( Exception ex )
					{
						_alertHistory.TryRemove( msg, out oldAlert );
						Error( "Failure transmitting mail via SMTP: " + ex.Message + ": " + ( ex.StackTrace ?? string.Empty ) );
					}

				}
			}
			catch ( Exception ex )
			{
				if ( logError )
					Log.Exception( ex, "Sending email failed", METHOD, format, arguments );
			}
			finally
			{
				//Flag we are out of the emergency alert method
				EmergencyAlertFlag = false;
			}
		}

		public static void SendEmail( string subject, string body, bool isHtml = false )
		{
			//Invoke the event
			System.Net.Mail.MailMessage mailMsg = new MailMessage()
			{
				Subject = subject,
				Body = body,
				SubjectEncoding = System.Text.Encoding.UTF8,
				BodyEncoding = System.Text.Encoding.UTF8,
				From = new MailAddress( Config.SmtpInfo.From, Config.SmtpInfo.From, System.Text.Encoding.UTF8 ),
				IsBodyHtml = isHtml,
				Sender = new MailAddress( Config.SmtpInfo.From ),
			};

			mailMsg.To.Add( Config.SmtpInfo.Recipients );

			System.Net.Mail.SmtpClient client = new SmtpClient()
			{
				Credentials = new System.Net.NetworkCredential( Config.SmtpInfo.Username, Config.SmtpInfo.Password ),
				EnableSsl = Config.SmtpInfo.UseSSL,
				Host = Config.SmtpInfo.Host,
				Port = Config.SmtpInfo.Port,
				Timeout = Config.SmtpInfo.Timeout * 1000,
			};

			try
			{
				client.Send( mailMsg );
			}
			catch ( Exception ex )
			{
				Error( "Failure transmitting mail via SMTP: " + ex.Message + ": " + ( ex.StackTrace ?? string.Empty ) );
			}
		}

		#endregion

		#region LogEntry

		public static void LogEntry( LoggingLevel level, string method, string error, string exception = null, string innerException = null, string stackTrace = null )
		{
			if ( string.IsNullOrEmpty( error ) )
				return;

			Exception ex = null;

			using ( SqlCommand cmd = new SqlCommand( "INSERT INTO logs VALUES( @d, @l, @m, @er, @ex, @ie, @st ); ", new SqlConnection( Config.LogConnectionString ) ) )
			{
				cmd.Parameters.Add( new SqlParameter( "d", SqlDbType.DateTime2 ) { Value = DateTime.Now } );
				cmd.Parameters.Add( new SqlParameter( "l", SqlDbType.Int ) { Value = (int)level } );
				cmd.Parameters.Add( new SqlParameter( "m", SqlDbType.VarChar, 255 ) { Value = method ?? string.Empty } );
				cmd.Parameters.Add( new SqlParameter( "er", SqlDbType.VarChar, -1 ) { Value = error ?? string.Empty } );
				cmd.Parameters.Add( new SqlParameter( "ex", SqlDbType.VarChar, -1 ) { Value = exception ?? string.Empty } );
				cmd.Parameters.Add( new SqlParameter( "ie", SqlDbType.VarChar, -1 ) { Value = innerException ?? string.Empty } );
				cmd.Parameters.Add( new SqlParameter( "st", SqlDbType.VarChar, -1 ) { Value = stackTrace ?? string.Empty } );

				try
				{
					cmd.Connection.Open();
					cmd.ExecuteNonQuery();
				}
				catch ( Exception e )
				{
					ex = e;
				}
				finally
				{
					if ( cmd.Connection.State != ConnectionState.Closed )
						cmd.Clone();
				}
			}
		}

		#endregion
	}
}