﻿Notes:

================================== Introduction ==================================

The Hub is a simple web site. It's entirely self-contained and requires a standard setup on an IIS. It's built in .NET 4.5.

The site uses a custom HttpModule (found at /API/CommandsModule.cs). This module looks for specific API calls that are defined
in the classes that support them. 

Each Command class supports an API data exchange with an Agent. A Command defines what URI it supports, the json data it sends in and out, etc. 

The flow looks like the following


IIS --> Startup --> Global.asax 
													|
													+------	Load Config
													| 				 |
													| 				 +------ Read AppSettings
													| 				 |
													| 				 +------ Connect to SQL
													| 				 |
													| 				 +------ Read AppSettings and Config from SQL
													| 
													+------	Load Logging
													| 				 |
													| 				 +------ Setup Log4Net
													| 				 |
													| 				 +------ Log to Hub with fallback to Log4Net
													| 				 
													+------	Check Version of site vs. version of database, upgrade database (if you decide to use this)
													| 				 |
													| 				 +------ Setup Log4Net
													| 				 
													+------	Startup the Host Manager
														 				 |
													  				 +------ Locate all classes implementing the IServiceObject interface
													  				 |
													  				 +------ Spawn background threads for each of these "workers", controlled through a global QuitEvent (found in /Shared/QuitEvent.cs)


Once Config has loaded successfully, the Hub will start receiving requests.



================================== Encryption ==================================

Encryption is supported in the Hub in the following ways:

1.	In the JDA_ITG_DATA_HUB database, there is a table named [data] with a column [json] that contains the data pulled from Workday and pushed to the various endpoints.

		That data will be automatically encrypted in a Release build. The 2 files that control this are:

		API/
				Commands/
									GetWorkCommand.cs 
									UpdateWorkCommand.cs

		They have an #if !DEBUG switch in them. If this is being pushed to a production environment, that's the safeway way to ensure it can't be turned off.

		The Encryption Seed can be found in API/Crypto/Wrapper.cs's static Constructor. It uses an <appSetting> called:

			Encryption.Seed

		That value should be customized for the production environment. To protect the data from the production staff who might use that seed to decrypt data,
		a separate algorithm is used in code to further manipulate the seed. If someone decompiles the web assembly, they'll be able to decrypt data, so the 
		only true safety valve is a C assembly or HSM installation on the server(s).


2.	Obviously this doesn't solve for production staff just doing the API calls to get the data, or data being in memory, etc. etc.. 
		Even with a single exe, the data still has to move into other systems, so encryption should really be just to protect data at rest, not defend against staff.



