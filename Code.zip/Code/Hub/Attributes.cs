﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JDA.ITG.Flow.Hub.Controllers;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub
{
	#region ControllerDisplayAttribute

	/// <summary>
	/// Provides an easy way to assign menu/nav display names to different controllers
	/// </summary>
	[AttributeUsage( AttributeTargets.Class )]
	public class ControllerDisplayAttribute : Attribute
	{
		public ControllerDisplayAttribute( string display )
		{
			this.Display = display;
		}

		public string Display { get; set; }
	}

	#endregion

	#region ActionDisplayAttribute

	/// <summary>
	/// Provides an easy way to assign menu/nav display names to different actions
	/// </summary>
	[AttributeUsage( AttributeTargets.Method )]
	public class ActionDisplayAttribute : Attribute
	{
		public ActionDisplayAttribute( string display )
		{
			this.Display = display;
		}

		public string Display { get; set; }
	}

	#endregion

	#region CoreAuthorize

	/// <summary>
	/// Provides controllers and actions with a way to verify if authentication is required, a user is present, and the user has
	/// the appropriate permissions to access the controller or action
	/// </summary>
	public class CoreAuthorize : AuthorizeAttribute
	{
		public UserPermission Permission { get; set; }

		public CoreAuthorize( UserPermission permission )
		{
			this.Permission = permission;
		}

		protected override void HandleUnauthorizedRequest( AuthorizationContext filterContext )
		{
			//log the unauthorized access?
			filterContext.Result = new RedirectResult( BaseController.REDIRECT_ROOT );
			//base.HandleUnauthorizedRequest( filterContext );
		}

		protected override bool AuthorizeCore( HttpContextBase httpContext )
		{
			if ( httpContext.User != null && httpContext.User.Identity != null && SessionState.AuthenticatedUser != null )
				return SessionState.AuthenticatedUser.HasPermission( this.Permission );

			return false;
		}
	}

	#endregion
}