﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using JDA.ITG.Flow.Hub.API;
using JDA.ITG.Flow.Hub.Models;

namespace JDA.ITG.Flow.Hub
{
	#region Config

	public static class Config
	{
		#region variables

		//these constants probably aren't needed as they're only used once (and I didn't do this for ALL the config)
		public const string CONFIG_WORK_ROWS = "WorkRows";
		public const string CONFIG_LOGGING_LEVEL = "LoggingLevel";
		public const string CONFIG_SMTP_INFO = "LoggingSMTP";

		//I hate the ToCharArray() implementation for string splitting. Optimized here
		public readonly static char[] COMMA_DELIMITER = ",".ToCharArray();

		//these (private) variables are exposed via internal variables below. These are wrapped by locks or volatiles
		//to ensure they are updated safely
		static volatile string _address = string.Empty;
		static volatile string _machine = string.Empty;
		static volatile LoggingLevel _loggingLevel = Flow.LoggingLevel.DEBUG;
		static volatile bool _properlyConfigured = false;
		static volatile int _emergencyAlertDelay = 90;
		static volatile SmtpConfig _smtpInfo = null;
		static volatile bool _encryptData = false;
		static volatile bool _serverUp = false;
		static volatile int _configRefreshInterval = 10;
		static DateTime _serverLastContactedAt = DateTime.MinValue;
		static object _serverLastContactedAtLock = new object();
		//hub-wide configuration settings loaded from the database, used by some of the variables above
		readonly static ConcurrentDictionary<string, string> _configurationValues = new ConcurrentDictionary<string, string>();

		#endregion
		
		#region properties

		/// <summary>List of errors trying to load configuration</summary>
		public static readonly List<string> ConfigurationErrors = new List<string>();

		/// <summary>Connection String to the database containing all the Hub's data needs</summary>
		public static string AppConnectionString { get; private set; }
		/// <summary>Connection String to the database containing all the Hub's logs</summary>
		public static string LogConnectionString { get; private set; }

		/// <summary>A dictionary of Objects known to the system and available for agents to use</summary>
		internal readonly static ConcurrentDictionary<int, ModelObjectDefinition> ObjectDefinitions = new ConcurrentDictionary<int, ModelObjectDefinition>();

		/// <summary>A dictionary of Agent's Ids and the last Status they reported</summary>
		internal readonly static ConcurrentDictionary<long, AgentStatus> AgentStatus = new ConcurrentDictionary<long, AgentStatus>();
	
		/// <summary>A dictionary of Agent's Ids and their details (schedule, settings)</summary>
		internal readonly static ConcurrentDictionary<long, AgentConfigRecord> AgentConfig = new ConcurrentDictionary<long, AgentConfigRecord>();

		/// <summary>How frequently duplicate alerts should be sent</summary>
		internal static int EmergencyAlertDelay { get { return _emergencyAlertDelay; } }

		/// <summary>Indicates if the Hub is operating/configured properly to reecive requests</summary>
		internal static bool ServerUp { get { return _serverUp; } }

		/// <summary>Indicates if data should be encrypted in the database</summary>
		internal static bool EncryptData { get { return _encryptData; } }

		/// <summary>Indicates if the Configuration on startup looks good</summary>
		internal static bool ProperlyConfigured { get { return _properlyConfigured; } }

		/// <summary>Used to track which machine this is running on</summary>
		internal static string IPAddress { get { return _address; } }

		/// <summary>Used to track which machine this is running on</summary>
		internal static string MachineName { get { return _machine; } }

		/// <summary>Contains information needed to send alerts via SMTP</summary>
		internal static SmtpConfig SmtpInfo { get { return _smtpInfo; } }

		/// <summary>What level of logging information to save to the database</summary>
		internal static LoggingLevel LoggingLevel { get { return _loggingLevel; } }
		
		/// <summary>The frequency to reload configuration settings, agents, etc. from the database</summary>
		internal static int ConfigRefreshInterval { get { return _configRefreshInterval; } }

		/// <summary>When the configuration was last successfully loaded from the server</summary>
		internal static DateTime ServerLastContactedAt 
		{
			get { lock ( _serverLastContactedAtLock ) { return _serverLastContactedAt; } }
			set { if ( value != null ) lock ( _serverLastContactedAtLock ) { _serverLastContactedAt = value; } }
		}

		#endregion

		#region Load

		/// <summary>
		/// Load configuration from web.config, then the database, and setup static variables
		/// </summary>
		public static void Load()
		{
			AssignMachineInfo();

			try
			{
				#region Logging Level

				string strLevel = System.Configuration.ConfigurationManager.AppSettings.Get( CONFIG_LOGGING_LEVEL );
				LoggingLevel level;
				if ( Enum.TryParse<LoggingLevel>( strLevel, out level ) )
					_loggingLevel = level;
				else
					ConfigurationErrors.Add( "LoggingLevel is not a value enum item, defaulting to DEBUG" );

				#endregion

				#region Connection Strings

				if ( ConfigurationManager.ConnectionStrings["appDB"] == null )
						ConfigurationErrors.Add( "appDB is missing" );
				else
				{
					AppConnectionString = ConfigurationManager.ConnectionStrings["appDB"].ConnectionString;
					if ( string.IsNullOrEmpty( AppConnectionString ) )
						ConfigurationErrors.Add( "appDB is missing" );
				}

				if ( ConfigurationManager.ConnectionStrings["logDB"] == null )
						ConfigurationErrors.Add( "logDB is missing" );
				else
				{
					LogConnectionString = ConfigurationManager.ConnectionStrings["logDB"].ConnectionString;
					if ( string.IsNullOrEmpty( LogConnectionString ) )
						ConfigurationErrors.Add( "logDB is missing" );
				}

				#endregion

				#region Test Connection Strings

				//make sure we a) have connnection strings and, b) they work (at least at startup)
				if ( string.IsNullOrEmpty( AppConnectionString ) == false )
				{
					try
					{
						using ( System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection( AppConnectionString ) )
						{
							conn.Open();
							conn.Close();
						}
					}
					catch ( Exception ex )
					{
						ConfigurationErrors.Add( "Exception while attempting to connect to the appDB: " + ex.Message + ":" + ( ex.StackTrace ?? string.Empty ) );
						return;
					}
				}

				//same for logging
				if ( string.IsNullOrEmpty( LogConnectionString ) == false )
				{

					try
					{
						using ( System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection( LogConnectionString ) )
						{
							conn.Open();
							conn.Close();
						}
					}
					catch ( Exception ex )
					{
						ConfigurationErrors.Add( "Exception while attempting to connect to the appDB: " + ex.Message + ":" + ( ex.StackTrace ?? string.Empty ) );
						return;
					}
				}

				#endregion

				//Reload pulls the data from the database. It also does the IP/Machine name checks, but since we JUST did the IP/Machine name, skip that part
				Reload( false );

			}
			catch { }

		}

		#endregion

		#region Reload

		/// <summary>
		/// Loads settings, agents, permissions, and objects from the database, updates the IP/Machine name values, and assigns static properties based on the loaded config 
		/// </summary>
		/// <param name="reassignMachineInfo"></param>
		public static void Reload( bool reassignMachineInfo = true )
		{
			if ( reassignMachineInfo )
				AssignMachineInfo();

			LoadConfigSettingsFromDB();
			AssignStaticPropertiesFromConfig();

			_properlyConfigured = ConfigurationErrors.Count == 0;

			if ( _properlyConfigured )
			{
				_serverUp = true;
				_serverLastContactedAt = DateTime.UtcNow;
			}
			else
			{
				_serverUp = false;
				Log.EmergencyAlert( "Server is misconfigured: " + string.Join( ",", ConfigurationErrors.ToArray() ) );
			}
		}

		#endregion

		#region Assign Machine Info

		static void AssignMachineInfo()
		{
			try
			{
				//in case something is changed without power cycling...
				_machine = System.Net.Dns.GetHostName().ToUpper();
				List<System.Net.IPAddress> list = System.Net.Dns.GetHostAddresses( MachineName ).ToList();
				list.RemoveAll( c => c.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork );

				var item = list.FirstOrDefault();

				if ( item == null )
					_address = "127.0.0.1";
				else
					_address = item.ToString();
			}
			catch { }
		}

		#endregion

		#region LoadConfigSettingsFromDB

		public static void LoadConfigSettingsFromDB()
		{
			Config.ConfigurationErrors.Clear();

			#region Load Configuration Settings

			Dictionary<string, string> hubConfig;
			Dictionary<long, AgentConfigRecord> agents;
			Dictionary<int, ModelObjectDefinition> objects;

			//call the database and get updated tables of settings, agents, objects, etc.
			if ( Models.Data.TryGetHubConfigComplex( out hubConfig, out agents, out objects, Config.ConfigurationErrors ) )
			{
				#region Replace Hub Configuration

				if ( hubConfig != null && hubConfig.Count > 0 )
					foreach ( var item in hubConfig )
						Config._configurationValues.AddOrUpdate( item.Key, item.Value, ( key, oldvalue ) => item.Value );

				#endregion

				#region Replace Agent Configuration

				if ( agents != null && agents.Count > 0 )
					foreach ( var item in agents )
						Config.AgentConfig.AddOrUpdate( item.Key, item.Value, ( key, oldvalue ) => item.Value );

				#endregion

				#region Replace Object Definitions

				if ( objects != null && objects.Count > 0 )
					foreach ( var item in objects )
						Config.ObjectDefinitions.AddOrUpdate( item.Key, item.Value, ( key, oldvalue ) => item.Value );

				#endregion
			}
			else
			{
				_serverUp = false;
			}

			#endregion
		}

		#endregion

		#region AssignStaticPropertiesFromConfig

		static void AssignStaticPropertiesFromConfig()
		{
			string str;

			#region reload local smtp info

			if ( _configurationValues.TryGetValue( CONFIG_SMTP_INFO, out str ) )
			{
				_smtpInfo = new SmtpConfig( str );
				if( string.IsNullOrEmpty( SmtpInfo.Error ) == false )
					ConfigurationErrors.Add( "LoggingSMTP connection string is invalid: " + SmtpInfo.Error );
			}

			#endregion

			#region Logging Level

			if ( _configurationValues.TryGetValue( CONFIG_LOGGING_LEVEL, out str ) )
			{
				LoggingLevel level;
				if ( Enum.TryParse<LoggingLevel>( str, out level ) )
					Config._loggingLevel = level;
				else
				{
					Config._loggingLevel = LoggingLevel.DEBUG;
					Log.Info( () => "LoggingLevel is not a value enum item, defaulting to DEBUG" );
				}
			}
			else
			{
				Config._loggingLevel = LoggingLevel.DEBUG;
				Log.Info( () => "LoggingLevel missing" );
			}

			#endregion

			#region ConfigRefreshInterval

			if ( _configurationValues.TryGetValue( "ConfigRefreshInterval", out str ) )
			{
				int interval;
				if ( int.TryParse( str, out interval ) )
				{
					if ( interval < 10 || interval > 120 )
						interval = 30;

					Config._configRefreshInterval = interval;

				}
			}
			else
			{
				Config._loggingLevel = LoggingLevel.DEBUG;
				Log.Info( () => "LoggingLevel missing" );
			}

			#endregion

			#region EncryptData

			if ( _configurationValues.TryGetValue( "EncryptData", out str ) )
			{
				bool encrypt;
				if ( bool.TryParse( str, out encrypt ) )
					Config._encryptData = encrypt;
			}
			else
			{
				Config._loggingLevel = LoggingLevel.DEBUG;
				Log.Info( () => "EncryptData missing" );
			}

			#endregion

		}

		#endregion

		#region GetAppSetting

		public static string GetAppSetting( string name )
		{
			string value = string.Empty;
			_configurationValues.TryGetValue( name, out value );
			return value;
		}

		public static Int32 GetAppSettingAsInt( string name, int defaultValue = 0 )
		{
			string value = string.Empty;
			_configurationValues.TryGetValue( name, out value );
			int i;
			if ( int.TryParse( value, out i ) )
				return i;
			else
				return defaultValue;
		}

		public static bool GetAppSettingAsBool( string name, bool defaultValue = false )
		{
			string value = string.Empty;
			_configurationValues.TryGetValue( name, out value );
			bool b;
			if ( bool.TryParse( value, out b ) )
				return b;
			else
				return defaultValue;
		}

		#endregion

		#region Permission Checks

		public static bool AgentCanSubmitObject( long agentId, string objectName )
		{
			ModelObjectDefinition item = Config.ObjectDefinitions.Values.SingleOrDefault( c => c.Name.Equals( objectName, StringComparison.CurrentCultureIgnoreCase ) );
			if ( item == null )
			{
				Log.Error( string.Format( "agentId {0} tried to submit nonexistent object name: {1}", agentId, objectName ) );
				return false;
			}
			else
				return ( item != null || ( item.Agents & agentId ) == agentId );
		}

		#endregion

		#region Updates

		public static bool DisableAgent( long agentId )
		{
			bool disabled = false;
			AgentConfigRecord agent;
			if ( Config.AgentConfig.TryGetValue( agentId, out agent ) )
			{
				agent.Enabled = false;
				disabled = true;
				if ( Data.TrySetAgent( agent ) == false )
				{
					Log.Error( string.Format( "Unable to update the agent status for agent '{0}'. Please check the Data logs", agentId ) );
				}
				else
					disabled = true;

				//now, check it again just to make sure it ddn't get updated behind us..
				if ( Config.AgentConfig.TryGetValue( agentId, out agent ) )
					if ( agent.Enabled )
						agent.Enabled = false;
			}
			else
				disabled = true;

			return disabled == true;
		}

		#endregion
	}

	#endregion

	#region SmtpConfig

	public class SmtpConfig
	{
		static char[] SC = ";".ToCharArray();
		static char[] EQ = "=".ToCharArray();

		public SmtpConfig( string settings )
		{
			try
			{
				if ( string.IsNullOrEmpty( settings ) == false )
				{
					string[] kvp = settings.Split( SC );
					foreach ( string s in kvp )
					{
						string[] item = s.Split( EQ );
						string key = item.FirstOrDefault();
						string value = item.LastOrDefault();

						if ( string.IsNullOrEmpty( key ) || string.IsNullOrEmpty( value ) )
							continue;

						switch ( key.ToLower() )
						{
							case "username":
								this.Username = value;
								break;

							case "password":
								this.Password = value;
								break;

							case "from":
								this.From = value;
								break;

							case "recipients":
								this.Recipients = value;
								break;

							case "host":
								this.Host = value;
								break;

							case "enabled":
								this.Enabled = value.ToLower() == "true";
								break;

							case "usessl":
								this.UseSSL = value.ToLower() == "true";
								break;

							case "delay":
								{
									int i = 0;
									if ( int.TryParse( value, out i ) )
										this.Delay = i;
									else
										this.Delay = 90;
									break;
								}

							case "port":
								{
									int i = 0;
									if ( int.TryParse( value, out i ) )
										this.Port = i;
									else
										this.Port = 25;
									break;
								}

							case "timeout":
								{
									int i = 0;
									if ( int.TryParse( value, out i ) )
										this.Timeout = i;
									else
										this.Timeout = 90;
									break;
								}
						}
					}


					List<string> errors = new List<string>();

					//fallback in case this is screwed up. No logging will happen here..
					if ( this.Username == null )
						errors.Add( "Username missing" );
					if ( this.Password == null )
						errors.Add( "Password missing" );
					if ( this.Host == null )
						errors.Add( "Host missing" );
					if ( this.Port == 0 )
						errors.Add( "Port == 0" );
					if ( this.From == null )
						errors.Add( "From missing" );
					if ( this.Recipients == null )
						errors.Add( "Recipients missing" );

					this.Error = string.Join( ", ", errors );
					this.Enabled = string.IsNullOrEmpty( this.Error );
				}
			}
			catch ( Exception ex )
			{
				Log.Exception( ex, "Error parsing SmtpConfig", "SmtpConfig Constructor", settings );
			}
		}

		public string Error { get; set; }

		public bool Enabled { get; set; }
		public int Delay { get; set; }
		public string From { get; set; }
		public string Host { get; set; }
		public int Port { get; set; }
		public string Username { get; set; }
		public string Password { get; set; }
		public int Timeout { get; set; }
		public string Recipients { get; set; }
		public bool UseSSL { get; set; }
		public bool ConsumerEnabled { get; set; }
	}

	#endregion

}